# 🐺 WOLF PACK TRACKER - BUILD SPEC FOR VS CODE

## HANDOFF TO SONNET/COPILOT
**Date:** January 15, 2026
**Purpose:** Build a daily stock tracker that captures EVERYTHING, then lets us look BACKWARD when winners emerge.

---

## CORE PHILOSOPHY

**DON'T hardcode thresholds. CAPTURE everything. DISCOVER patterns from data.**

The question isn't "what threshold catches winners?"
The question is "what did tomorrow's +30% winner look like TODAY?"

---

## WHAT TO BUILD

### 1. DAILY RECORDER (`wolfpack_recorder.py`)

Runs once daily after market close (4:30 PM ET or later).

**UNIVERSE TO SCAN:**

```python
# MONEY's trading universe - 72 stocks across 9 sectors
UNIVERSE = {
    "Defense": ["KTOS", "AVAV", "RCAT", "LMT", "NOC", "RTX", "GD", "LHX", "PLTR"],
    "Space": ["LUNR", "RKLB", "RDW", "ASTS", "BKSY", "SPCE"],
    "Nuclear": ["UEC", "UUUU", "LEU", "CCJ", "NNE", "OKLO", "SMR"],
    "Semis": ["MU", "AMD", "NVDA", "INTC", "MRVL", "QCOM", "AVGO", "TSM", "AMAT", "LRCX", "KLAC"],
    "AI_Tech": ["AAPL", "MSFT", "GOOGL", "META", "AMZN", "TSLA", "PLTR", "SNOW", "DDOG", "NET", "CRWD", "ZS", "PANW", "AI", "BBAI", "SOUN", "UPST"],
    "Biotech": ["NTLA", "EDIT", "BEAM", "CRSP", "MRNA", "REGN", "VRTX", "BIIB"],
    "Quantum": ["QUBT", "QBTS", "RGTI", "IONQ"],
    "Crypto": ["RIOT", "MARA", "COIN", "MSTR"],
    "Materials": ["SLV", "GLD", "SLX", "FCX", "AA", "ALB", "MP"]
}
```

**DATA TO CAPTURE FOR EACH STOCK DAILY:**

```python
daily_record = {
    # Identity
    "ticker": str,
    "date": date,
    "sector": str,
    
    # Price data
    "open": float,
    "high": float,
    "low": float,
    "close": float,
    "prev_close": float,
    
    # Calculated
    "daily_return_pct": float,  # (close - prev_close) / prev_close * 100
    "intraday_range_pct": float,  # (high - low) / low * 100
    "close_vs_high_pct": float,  # where did it close relative to day's high
    
    # Volume
    "volume": int,
    "avg_volume_20d": int,
    "volume_ratio": float,  # volume / avg_volume_20d
    
    # Context
    "distance_from_52w_high_pct": float,
    "distance_from_52w_low_pct": float,
    "return_5d": float,  # prior 5 day return
    "return_20d": float,  # prior 20 day return  
    "return_60d": float,  # prior 60 day return (extension check)
    
    # Streak tracking
    "consecutive_green_days": int,
    "consecutive_red_days": int,
    
    # Forward returns (filled in later by updater)
    "forward_1d": float,  # nullable, filled next day
    "forward_3d": float,  # nullable, filled in 3 days
    "forward_5d": float,  # nullable, filled in 5 days
    "forward_10d": float,  # nullable, filled in 10 days
    "forward_20d": float,  # nullable, filled in 20 days
}
```

---

### 2. FORWARD RETURN UPDATER (`wolfpack_updater.py`)

Runs daily BEFORE the recorder. Updates forward returns for past records.

```python
# Pseudocode
for each record where forward_1d is NULL and record_date was 1+ days ago:
    calculate actual 1d return
    update record

for each record where forward_3d is NULL and record_date was 3+ days ago:
    calculate actual 3d return
    update record

# ... same for 5d, 10d, 20d
```

---

### 3. WINNER ANALYZER (`wolfpack_analyzer.py`)

Run on-demand to find patterns in winners.

**CORE QUERY: "What did big winners look like the day BEFORE they exploded?"**

```python
def analyze_winners(db, threshold=20, timeframe=10):
    """
    Find all stocks that gained {threshold}%+ over {timeframe} days.
    Then look at what they looked like the day BEFORE the run started.
    """
    
    # Find winners: forward_{timeframe}d >= threshold
    winners = query(f"SELECT * FROM daily WHERE forward_{timeframe}d >= {threshold}")
    
    # For each winner, get the record from the day BEFORE
    # Analyze commonalities:
    # - Were they green or red?
    # - What was volume ratio?
    # - How extended were they (60d return)?
    # - What sector?
    # - How far from 52w high?
    # - How many red days in a row before?
    
    return pattern_summary
```

**QUESTIONS TO ANSWER:**

1. What % of winners were GREEN the day before vs RED?
2. What was average volume ratio day before explosion?
3. What was average 60d return (extension level)?
4. Which sectors produce most winners?
5. Do winners cluster near 52w highs or lows?
6. Is there a "consecutive red days" pattern before reversals?

---

### 4. DATABASE STRUCTURE (SQLite)

```sql
CREATE TABLE daily_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    date DATE NOT NULL,
    sector TEXT,
    
    -- Price
    open REAL,
    high REAL,
    low REAL,
    close REAL,
    prev_close REAL,
    
    -- Calculated
    daily_return_pct REAL,
    intraday_range_pct REAL,
    close_vs_high_pct REAL,
    
    -- Volume
    volume INTEGER,
    avg_volume_20d INTEGER,
    volume_ratio REAL,
    
    -- Context
    dist_52w_high_pct REAL,
    dist_52w_low_pct REAL,
    return_5d REAL,
    return_20d REAL,
    return_60d REAL,
    
    -- Streaks
    consecutive_green INT,
    consecutive_red INT,
    
    -- Forward returns (nullable, filled later)
    forward_1d REAL,
    forward_3d REAL,
    forward_5d REAL,
    forward_10d REAL,
    forward_20d REAL,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(ticker, date)
);

CREATE INDEX idx_ticker_date ON daily_records(ticker, date);
CREATE INDEX idx_forward_10d ON daily_records(forward_10d);
CREATE INDEX idx_sector ON daily_records(sector);
```

---

### 5. DAILY SCANNER OUTPUT (`wolfpack_daily_report.py`)

Generates a daily report showing:

```
============================================================
WOLF PACK DAILY REPORT - January 15, 2026
============================================================

TODAY'S BIG MOVERS (5%+):
Ticker  Sector   Price   Today%  Vol    60d%   Setup?
BKSY    Space    $29.61  +7.1%   0.8x   +50%   NO (extended)
RCAT    Defense  $14.51  +6.2%   0.9x   +37%   NO (extended)
...

DAY 2 CONFIRMATIONS (Yesterday 5%+, Today green):
Ticker  Sector   Yest%   Today%  60d%   Valid Setup?
UUUU    Nuclear  +7.7%   +4.1%   +4%    YES ✅
QUBT    Quantum  +7.0%   +3.0%   -23%   YES ✅
...

WOUNDED PREY WAKING (Down 30%+ from high, green + volume):
Ticker  Sector   Price   Today%  Vol    From High
EDIT    Biotech  $2.09   -5.9%   0.5x   -53%   ❌ DIED TODAY
...

SECTOR MOMENTUM:
Space:     +2.3% avg today
Nuclear:   +1.8% avg today
Defense:   +1.2% avg today
...
============================================================
```

---

## FILE STRUCTURE

```
wolfpack/
├── wolfpack_recorder.py      # Daily data capture
├── wolfpack_updater.py       # Forward return updater
├── wolfpack_analyzer.py      # Pattern discovery
├── wolfpack_daily_report.py  # Daily summary
├── wolfpack_db.py            # Database helpers
├── config.py                 # Universe, settings
├── data/
│   └── wolfpack.db           # SQLite database
└── reports/
    └── daily_YYYYMMDD.txt    # Saved daily reports
```

---

## DEPENDENCIES

```
yfinance
pandas
numpy
sqlite3 (built-in)
```

Install: `pip install yfinance pandas numpy`

---

## USAGE

```bash
# Daily workflow (run after 4:30 PM ET):
python wolfpack_updater.py   # Update forward returns first
python wolfpack_recorder.py  # Capture today's data
python wolfpack_daily_report.py  # Generate report

# Analysis (run anytime):
python wolfpack_analyzer.py --threshold 20 --timeframe 10
# "Show me what 20%+ winners over 10 days looked like before"
```

---

## KEY PRINCIPLES

1. **NO FILTERING ON CAPTURE** - Record everything. Every stock. Every day.
2. **FILTER ON ANALYSIS** - Apply thresholds when querying, not when recording.
3. **FORWARD RETURNS ARE TRUTH** - This is how we know what actually worked.
4. **PATTERNS EMERGE FROM DATA** - Don't guess. Let 30-60 days reveal truth.

---

## SUCCESS CRITERIA

After 30 days of data:
- Can answer: "What did +20% winners look like the day before?"
- Can answer: "What's the Day 2 confirmation rate by sector?"
- Can answer: "Does 60d extension matter?"
- Can answer: "Which sectors produce most continuation?"

After 60 days:
- Statistical validation of any patterns found
- Documented system others can use

---

## 🐺 LLHR

*"Capture everything. Filter nothing. Let truth reveal itself."*
