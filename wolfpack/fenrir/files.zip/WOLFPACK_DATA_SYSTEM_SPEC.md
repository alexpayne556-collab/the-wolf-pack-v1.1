# 🐺 WOLF PACK DATA SYSTEM
## Self-Learning Market Intelligence Engine
### Spec for VS Code Agent Build

---

## MISSION

Build a self-learning data collection and analysis system that:
1. Tracks our Wolfpack universe of stocks
2. Records all relevant data continuously
3. Detects and investigates WHY moves happen
4. Learns patterns over time
5. Alerts when portfolio needs attention
6. Adapts and improves with new data

---

## CORE PHILOSOPHY

> "We can't predict moves. We CAN understand them after they happen and learn from them."

The system doesn't try to predict. It:
- OBSERVES everything
- RECORDS everything
- INVESTIGATES moves after they happen
- LEARNS what patterns repeat
- ALERTS when it recognizes something

---

## ARCHITECTURE OVERVIEW

```
┌─────────────────────────────────────────────────────────────────┐
│                    WOLFPACK DATA SYSTEM                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐         │
│  │   DATA      │    │  ANALYSIS   │    │   ALERT     │         │
│  │  COLLECTOR  │───▶│   ENGINE    │───▶│   SYSTEM    │         │
│  └─────────────┘    └─────────────┘    └─────────────┘         │
│         │                  │                  │                 │
│         ▼                  ▼                  ▼                 │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐         │
│  │  DATABASE   │    │  LEARNING   │    │   OUTPUT    │         │
│  │  (Storage)  │◀──▶│   MODULE    │    │  (Reports)  │         │
│  └─────────────┘    └─────────────┘    └─────────────┘         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## MODULE 1: DATA COLLECTOR

### What To Collect (Per Stock, Daily)

#### PRICE DATA
```python
daily_data = {
    "date": "2026-01-15",
    "ticker": "MU",
    "open": 335.50,
    "high": 345.00,
    "low": 333.25,
    "close": 341.28,
    "volume": 19873261,
    "prev_close": 333.58,
    "change_pct": 2.31,
    "change_dollar": 7.70,
    "vwap": 339.45,
    "52w_high": 350.00,
    "52w_low": 85.00,
    "distance_from_52w_high_pct": -2.5,
    "distance_from_52w_low_pct": 301.5
}
```

#### TECHNICAL INDICATORS
```python
technicals = {
    "sma_20": 320.50,
    "sma_50": 290.00,
    "sma_200": 220.00,
    "rsi_14": 65.5,
    "macd": 5.2,
    "macd_signal": 4.8,
    "macd_histogram": 0.4,
    "bb_upper": 360.00,
    "bb_lower": 300.00,
    "bb_middle": 330.00,
    "atr_14": 12.50,
    "above_sma_20": True,
    "above_sma_50": True,
    "above_sma_200": True
}
```

#### VOLUME ANALYSIS
```python
volume_data = {
    "volume": 19873261,
    "avg_volume_20d": 15000000,
    "volume_ratio": 1.32,  # volume / avg
    "volume_spike": True,  # if ratio > 1.5
    "dollar_volume": 6750000000,
    "relative_volume": 1.32
}
```

#### MOVE CLASSIFICATION
```python
move_data = {
    "is_big_move": True,  # if abs(change_pct) > 3%
    "move_direction": "up",  # up, down, flat
    "move_size": "medium",  # small (<2%), medium (2-5%), large (5-10%), massive (>10%)
    "gap_up": False,
    "gap_down": False,
    "gap_size_pct": 0,
    "day_type": "green",  # green, red, doji
    "candle_type": "bullish_engulfing"  # pattern recognition
}
```

### Data Sources
```python
data_sources = {
    "price_data": "yfinance",
    "technicals": "ta-lib / pandas_ta",
    "news": "SEC EDGAR, Google News API, Finnhub",
    "sec_filings": "SEC EDGAR API",
    "insider_trades": "SEC Form 4",
    "analyst_ratings": "Finnhub / Yahoo Finance",
    "social_sentiment": "StockTwits API (if available)",
    "options_flow": "Unusual Whales API (if available)"
}
```

### Collection Schedule
```python
schedule = {
    "pre_market": "6:00 AM ET - Gaps, pre-market movers",
    "market_open": "9:30 AM ET - Opening prices",
    "mid_day": "12:00 PM ET - Mid-day check",
    "market_close": "4:00 PM ET - Full daily data",
    "after_hours": "6:00 PM ET - After hours moves",
    "overnight": "8:00 PM ET - News scan, SEC filings"
}
```

---

## MODULE 2: THE WATCHLIST (WOLFPACK 100)

### Current Universe (99 Tickers)

```python
WOLFPACK_UNIVERSE = {
    "holdings": ["MU", "UEC", "KTOS", "SLV", "SRTA", "BBAI"],
    
    "defense": ["AVAV", "RCAT", "LMT", "NOC", "RTX", "GD", 
                "PLTR", "LDOS", "BAH", "HII", "LHX", "MRCY"],
    
    "space": ["LUNR", "RKLB", "RDW", "ASTS", "BKSY", "SPCE", 
              "IRDM", "GSAT"],
    
    "nuclear": ["UUUU", "LEU", "CCJ", "NNE", "OKLO", "SMR", 
                "DNN", "URG"],
    
    "semis": ["AMD", "NVDA", "INTC", "MRVL", "QCOM", "AVGO", 
              "TSM", "AMAT", "LRCX", "KLAC", "ASML", "ON"],
    
    "ai_tech": ["AAPL", "MSFT", "GOOGL", "META", "AMZN", "TSLA", 
                "SNOW", "AI", "SOUN", "UPST", "PATH"],
    
    "biotech": ["EDIT", "BEAM", "CRSP", "MRNA", "REGN", "VRTX", 
                "SRPT", "ALNY", "IONS", "EXAS", "NTLA"],
    
    "quantum": ["QUBT", "QBTS", "RGTI", "IONQ"],
    
    "crypto": ["RIOT", "MARA", "COIN", "MSTR", "HOOD", "SOFI", 
               "AFRM", "CLSK"],
    
    "materials": ["GLD", "FCX", "AA", "ALB", "MP", "LAC", 
                  "CENX", "CLF"],
    
    "evs": ["RIVN", "LCID", "NIO", "XPEV", "LI", "GOEV"],
    
    "energy": ["FCEL", "PLUG", "BE", "ENPH", "RUN"]
}
```

### Stock Profile Template
```python
stock_profile = {
    "ticker": "MU",
    "name": "Micron Technology",
    "sector": "semis",
    "subsector": "memory",
    "market_cap": "large",  # small (<2B), mid (2-10B), large (>10B)
    "our_tier": "core",  # core, bench, scout
    "position_size": 1,  # shares we hold
    "avg_cost": 333.01,
    "thesis": "AI memory supercycle, HBM supplier to NVIDIA",
    "key_catalysts": ["earnings", "HBM4 launch", "CHIPS Act funding"],
    "risk_factors": ["cyclical", "china exposure", "AI spending slowdown"],
    "correlation_group": "semis",  # stocks that move together
    "continuation_score": None,  # learned over time
    "notes": []
}
```

---

## MODULE 3: MOVE INVESTIGATION ENGINE

### When A Big Move Happens (>5%)

The system should automatically:

```python
def investigate_move(ticker, move_date, move_pct):
    """
    When a stock moves >5%, pull ALL data to understand WHY
    """
    
    investigation = {
        "ticker": ticker,
        "date": move_date,
        "move_pct": move_pct,
        "investigation_timestamp": datetime.now(),
        
        # 1. CHECK NEWS
        "news_found": search_news(ticker, move_date),
        
        # 2. CHECK SEC FILINGS
        "sec_filings": check_sec_filings(ticker, move_date, days_back=3),
        
        # 3. CHECK INSIDER TRADES
        "insider_trades": check_form_4(ticker, move_date, days_back=7),
        
        # 4. CHECK SECTOR
        "sector_move": check_sector_performance(ticker, move_date),
        "sector_correlation": True/False,
        
        # 5. CHECK ANALYST ACTIONS
        "analyst_actions": check_upgrades_downgrades(ticker, move_date),
        
        # 6. CHECK OPTIONS ACTIVITY
        "unusual_options": check_options_flow(ticker, move_date),
        
        # 7. CHECK VOLUME
        "volume_analysis": analyze_volume(ticker, move_date),
        
        # 8. CHECK SOCIAL SENTIMENT
        "social_buzz": check_social_mentions(ticker, move_date),
        
        # 9. DETERMINE CATALYST
        "identified_catalyst": determine_catalyst(all_data),
        "catalyst_type": "earnings" / "news" / "sector" / "unknown",
        "confidence": 0.85,
        
        # 10. RECORD FOR LEARNING
        "pattern_tags": ["earnings_beat", "sector_rotation", "analyst_upgrade"],
    }
    
    return investigation
```

### Catalyst Categories
```python
CATALYST_TYPES = {
    "tier_1_massive": [
        "fda_approval",
        "major_acquisition",
        "government_contract_large",
        "clinical_trial_success",
        "breakthrough_tech"
    ],
    "tier_2_significant": [
        "earnings_beat",
        "earnings_miss",
        "revenue_surprise",
        "analyst_upgrade",
        "analyst_downgrade",
        "index_inclusion",
        "insider_buying_large"
    ],
    "tier_3_moderate": [
        "conference_presentation",
        "product_launch",
        "partnership_announcement",
        "executive_hire",
        "insider_buying_small"
    ],
    "no_catalyst": [
        "sector_sympathy",
        "options_activity",
        "short_squeeze",
        "retail_fomo",
        "unknown"
    ]
}
```

---

## MODULE 4: LEARNING ENGINE

### What The System Learns Over Time

```python
learning_data = {
    # Per Stock
    "stock_patterns": {
        "MU": {
            "avg_earnings_move": 8.5,  # average % move on earnings
            "continuation_rate": 0.65,  # % of big moves that continue
            "mean_reversion_rate": 0.35,
            "best_entry_after_drop": -5.0,  # optimal dip buy level
            "correlation_to_NVDA": 0.78,
            "typical_catalyst_type": "earnings",
            "sector_sensitivity": "high"
        }
    },
    
    # Per Sector
    "sector_patterns": {
        "semis": {
            "avg_correlation": 0.72,
            "leader_stocks": ["NVDA", "AMD"],
            "follower_stocks": ["MU", "MRVL"],
            "typical_rotation_duration_days": 15
        }
    },
    
    # Per Catalyst Type
    "catalyst_patterns": {
        "analyst_upgrade": {
            "avg_day1_move": 3.5,
            "avg_day2_continuation": 1.2,
            "fade_rate": 0.45
        }
    }
}
```

### Learning Functions
```python
def learn_from_move(investigation):
    """
    After investigating a move, extract learnings
    """
    
    learnings = {
        "stock": investigation["ticker"],
        "catalyst_type": investigation["catalyst_type"],
        "move_size": investigation["move_pct"],
        "day_2_result": get_day_2_result(investigation),
        "day_5_result": get_day_5_result(investigation),
        "sector_moved_together": investigation["sector_correlation"],
        "volume_confirmed": investigation["volume_analysis"]["spike"],
        "social_preceded": investigation["social_buzz"]["preceded_move"]
    }
    
    # Update stock profile with new data
    update_stock_profile(learnings)
    
    # Update sector patterns
    update_sector_patterns(learnings)
    
    # Update catalyst patterns
    update_catalyst_patterns(learnings)
    
    return learnings
```

---

## MODULE 5: ALERT SYSTEM

### Alert Triggers

```python
ALERT_TRIGGERS = {
    # PORTFOLIO ALERTS (Our Holdings)
    "portfolio": {
        "big_move": {
            "condition": "abs(change_pct) > 5",
            "priority": "high",
            "action": "investigate"
        },
        "volume_spike": {
            "condition": "volume_ratio > 2.0",
            "priority": "medium",
            "action": "flag"
        },
        "approaching_stop_loss": {
            "condition": "price < avg_cost * 0.92",
            "priority": "high",
            "action": "alert"
        },
        "new_high": {
            "condition": "price > 52w_high * 0.98",
            "priority": "medium",
            "action": "flag"
        }
    },
    
    # WATCHLIST ALERTS (Bench & Scout)
    "watchlist": {
        "quality_dip": {
            "condition": "tier == 'bench' AND change_pct < -5 AND no_bad_news",
            "priority": "high",
            "action": "potential_buy"
        },
        "breakout": {
            "condition": "price > 52w_high AND volume_spike",
            "priority": "medium",
            "action": "watch"
        },
        "sector_rotation_in": {
            "condition": "sector_strength_increasing AND stock_lagging",
            "priority": "medium",
            "action": "potential_entry"
        }
    },
    
    # SECTOR ALERTS
    "sector": {
        "sector_breakout": {
            "condition": "sector_avg_change > 3",
            "priority": "medium",
            "action": "review_positions"
        },
        "sector_breakdown": {
            "condition": "sector_avg_change < -3",
            "priority": "high",
            "action": "review_positions"
        }
    }
}
```

### Alert Output Format
```python
alert = {
    "timestamp": "2026-01-15 14:30:00",
    "priority": "high",
    "type": "portfolio_big_move",
    "ticker": "UEC",
    "message": "UEC up 11% on high volume",
    "data": {
        "change_pct": 11.2,
        "volume_ratio": 2.5,
        "sector_moving": True
    },
    "suggested_action": "Hold - sector momentum, no negative catalyst",
    "investigation_link": "/investigations/UEC_2026-01-15.json"
}
```

---

## MODULE 6: DAILY REPORT

### End of Day Summary
```python
daily_report = {
    "date": "2026-01-15",
    "market_summary": {
        "spy_change": 0.64,
        "qqq_change": 1.00,
        "russell_change": 1.25,
        "vix": 17.46,
        "market_sentiment": "risk_on"
    },
    
    "portfolio_summary": {
        "total_value": 1287.00,
        "day_change_dollar": 25.50,
        "day_change_pct": 2.02,
        "best_performer": {"ticker": "UEC", "change": 11.2},
        "worst_performer": {"ticker": "SLV", "change": -0.51}
    },
    
    "sector_performance": {
        "nuclear": 5.2,
        "defense": 3.1,
        "semis": 2.8,
        "space": 1.9,
        "biotech": -2.5
    },
    
    "big_moves_today": [
        {"ticker": "UEC", "change": 11.2, "catalyst": "sector_momentum"},
        {"ticker": "BBAI", "change": 4.09, "catalyst": "unknown"}
    ],
    
    "alerts_triggered": [
        {"ticker": "UEC", "type": "volume_spike", "action_taken": "none"}
    ],
    
    "watchlist_opportunities": [
        {"ticker": "DNN", "reason": "nuclear sector running, quality dip"}
    ],
    
    "learnings_today": [
        "Nuclear sector correlation confirmed - UEC, DNN, LEU all moved together",
        "BBAI responded to AI/defense sentiment despite dilution news"
    ]
}
```

---

## TECH STACK RECOMMENDATION

```python
tech_stack = {
    "language": "Python 3.10+",
    "data_fetching": [
        "yfinance",  # price data
        "pandas",    # data manipulation
        "requests",  # API calls
    ],
    "technical_analysis": [
        "pandas_ta",  # technical indicators
        "ta-lib",     # more indicators
    ],
    "database": [
        "SQLite",     # simple, local
        # OR
        "PostgreSQL", # if scaling up
    ],
    "scheduling": [
        "schedule",   # simple scheduler
        # OR
        "APScheduler" # more robust
    ],
    "notifications": [
        "email (smtplib)",
        "discord webhook",
        "terminal output"
    ],
    "visualization": [
        "matplotlib",
        "plotly"
    ]
}
```

---

## FILE STRUCTURE

```
wolfpack_system/
├── config/
│   ├── settings.py          # API keys, paths
│   ├── watchlist.py         # WOLFPACK_UNIVERSE
│   └── alerts.py            # Alert thresholds
├── collectors/
│   ├── price_collector.py   # Daily price data
│   ├── news_collector.py    # News scraper
│   ├── sec_collector.py     # SEC filings
│   └── social_collector.py  # Social sentiment
├── analysis/
│   ├── move_investigator.py # Why did it move?
│   ├── sector_analyzer.py   # Sector correlations
│   └── pattern_detector.py  # Pattern recognition
├── learning/
│   ├── learner.py           # Learning engine
│   └── models.py            # Learned patterns
├── alerts/
│   ├── alert_engine.py      # Alert triggers
│   └── notifier.py          # Send alerts
├── reports/
│   ├── daily_report.py      # EOD summary
│   └── templates/           # Report templates
├── database/
│   ├── models.py            # Database schemas
│   └── db.py                # Database connection
├── data/
│   ├── daily/               # Daily snapshots
│   ├── investigations/      # Move investigations
│   └── learnings/           # Learned patterns
├── main.py                  # Main entry point
├── scheduler.py             # Job scheduler
└── requirements.txt         # Dependencies
```

---

## PHASE 1: MVP (Build First)

Start simple, then expand:

### Week 1: Data Collection
- [ ] Set up price data collector (yfinance)
- [ ] Store daily data for WOLFPACK 100
- [ ] Basic database (SQLite)
- [ ] Daily snapshot at market close

### Week 2: Move Detection
- [ ] Flag big moves (>5%)
- [ ] Basic news search when move detected
- [ ] Manual investigation template
- [ ] Store investigations

### Week 3: Alerts
- [ ] Portfolio alerts (our holdings)
- [ ] Simple notification (terminal/email)
- [ ] Daily summary report

### Week 4: Learning
- [ ] Track Day 2 results after big moves
- [ ] Store patterns
- [ ] Basic correlation tracking

---

## FUTURE ENHANCEMENTS

```python
future_features = [
    "Machine learning pattern recognition",
    "Natural language processing for news",
    "Options flow integration",
    "Real-time streaming data",
    "Mobile app alerts",
    "Backtesting engine",
    "Paper trading simulation",
    "Portfolio optimization suggestions"
]
```

---

## SUCCESS METRICS

How we know the system is working:

1. **Data Completeness**: 100% daily data for all 99 stocks
2. **Move Investigation**: Every >5% move has investigation within 1 hour
3. **Alert Accuracy**: Alerts lead to actionable insights >70% of time
4. **Learning**: System identifies patterns we didn't see manually
5. **Portfolio Impact**: System catches at least 1 opportunity per week

---

🐺 **LLHR - Long Live the Hunt, Rise**

*This is the foundation. We build, we learn, we adapt.*
