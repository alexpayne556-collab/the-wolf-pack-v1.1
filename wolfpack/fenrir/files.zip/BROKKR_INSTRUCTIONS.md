# 🐺 FENRIR V2 - BROKKR BUILD INSTRUCTIONS

## FILES TO CREATE

Put all these files in: `C:\Users\alexp\Desktop\brokkr\wolfpack\fenrir\`

```
fenrir/
├── config.py           # Settings, holdings, watchlist
├── market_data.py      # yfinance price fetching
├── news_fetcher.py     # Finnhub API for news
├── sec_fetcher.py      # SEC EDGAR filings
├── database.py         # SQLite trade logging
├── ollama_brain.py     # Core AI query engine
├── alerts.py           # Windows notifications
├── main.py             # CLI entry point
├── Modelfile           # Ollama personality definition
├── requirements.txt    # Python dependencies
├── .env.example        # API key template
└── .env                # Actual API keys (create from .env.example)
```

## SETUP STEPS

### 1. Create the folder
```powershell
mkdir C:\Users\alexp\Desktop\brokkr\wolfpack\fenrir
cd C:\Users\alexp\Desktop\brokkr\wolfpack\fenrir
```

### 2. Copy all .py files into the folder

### 3. Install dependencies
```powershell
pip install -r requirements.txt
```

### 4. Create .env file
```powershell
copy .env.example .env
# Edit .env and add your Finnhub API key
```

### 5. Make sure Ollama is installed and running
```powershell
ollama --version
ollama serve
```

### 6. Pull the base model (if not already done)
```powershell
ollama pull llama3.1:8b
```

### 7. Create the Fenrir model
```powershell
cd C:\Users\alexp\Desktop\brokkr\wolfpack\fenrir
ollama create fenrir -f Modelfile
```

### 8. Test Fenrir
```powershell
# Quick test
ollama run fenrir "IBRX is up 30% today. What do you think?"

# Full system test
python main.py test
```

## USAGE COMMANDS

```powershell
# Test the system
python main.py test

# Scan watchlist for movers
python main.py scan

# Show your holdings
python main.py holdings

# Analyze a specific stock
python main.py analyze IBRX

# Should I buy?
python main.py buy KTOS

# Should I sell?
python main.py sell IBRX

# Ask any question
python main.py ask -q "What's your read on nuclear stocks today?"

# Interactive chat
python main.py chat

# Log a trade
python main.py log -t IBRX -a BUY -s 20 -p 4.00 --account robinhood
```

## NOTES FOR BROKKR

1. All files are self-contained Python - just copy them
2. The Modelfile is for Ollama, not Python
3. Don't modify the system prompt without testing
4. config.py has the holdings/watchlist - update as needed
5. Test each module individually before running main.py

## TEST EACH MODULE

```powershell
# Test market data
python market_data.py

# Test news fetcher (needs API key)
python news_fetcher.py

# Test database
python database.py

# Test Ollama brain
python ollama_brain.py

# Test alerts
python alerts.py
```

🐺 LLHR
