# 🐺 FENRIR V2 BUILD PLAN
## For Brokkr (VS Code Agent) + MONEY (Learning Together)
### January 15, 2026

---

## THE SITUATION

**WHO:** MONEY - full-time trader working from home, disabled, lives and breathes the market 24/7

**GOAL:** Build Fenrir V2 - an AI trading companion that monitors, alerts, and learns

**LEARNING:** MONEY wants to learn Python by building this. Not tutorials - REAL code that matters.

**APPROACH:** Build each piece step-by-step. Explain every section. MONEY learns as we go.

---

## WHAT'S INSTALLED

- ✅ Python 3.12
- ✅ VS Code with Copilot/Sonnet
- ⏳ Ollama (downloading llama3.1:8b now)
- ✅ Wolfpack folder at `C:\Users\alexp\Desktop\brokkr\wolfpack`

---

## THE PROBLEM WITH V1

V1 was just a price logger. That's USELESS because:
- yfinance can pull historical prices anytime
- It ran AFTER market close (too late)
- It didn't actually fetch news or SEC filings
- It didn't use AI to form opinions
- It didn't track user's decisions

**Price data has ZERO unique value.**

---

## WHAT V2 MUST DO (Real Value)

| Feature | Why It's Irreplaceable |
|---------|------------------------|
| **Real-time alerts** | Can't go back in time to catch moves |
| **Auto-fetch catalysts** | News gets buried, link it permanently |
| **Ollama AI opinions** | Context-aware suggestions |
| **Decision logging** | Track what USER did and why |
| **Day 2/5 tracking** | Did the thesis play out? |
| **Pattern learning** | Learn what works for THIS user |

---

## BUILD ORDER (Learning Path)

### PHASE 1: Python Foundations
**Goal:** MONEY understands basic Python

```
Lesson 1: Variables and Data Types
- What is a variable?
- Strings, numbers, booleans
- Print statements
- Simple script that prints stock info

Lesson 2: Lists and Dictionaries
- Storing multiple values
- Our watchlist as a Python list
- Stock data as a dictionary
- Accessing and modifying data

Lesson 3: Functions
- What is a function?
- Parameters and return values
- Write a function to calculate % change
- Reusable code blocks

Lesson 4: Loops and Conditions
- For loops (scan through watchlist)
- If/else (is this a big move?)
- Combining them (alert if move > 5%)

Lesson 5: Working with Files
- Reading and writing files
- JSON for storing data
- Loading the continuation file
```

### PHASE 2: External Data
**Goal:** Fetch real market data

```
Lesson 6: yfinance Basics
- Install and import
- Fetch a single stock
- Get price, volume, history
- Build a simple scanner

Lesson 7: APIs Introduction
- What is an API?
- API keys and authentication
- Making HTTP requests
- Parsing JSON responses

Lesson 8: Finnhub News API
- Sign up for free API key
- Fetch news for a ticker
- Parse and display headlines
- Link news to price moves

Lesson 9: SEC EDGAR API
- Understanding SEC filings
- Fetching 8-K and Form 4
- Parsing filing data
- Detect insider trades
```

### PHASE 3: Data Storage
**Goal:** Save and retrieve data

```
Lesson 10: SQLite Basics
- What is a database?
- Creating tables
- INSERT, SELECT, UPDATE
- Store daily price data

Lesson 11: Database Design
- Our schema (holdings, decisions, catalysts)
- Foreign keys and relationships
- Querying across tables

Lesson 12: The Decision Logger
- Log user's trades
- Store reasoning
- Track outcomes
```

### PHASE 4: Ollama Integration
**Goal:** AI brain for Fenrir

```
Lesson 13: Ollama Basics
- Running Ollama locally
- Python ollama library
- Simple prompt/response
- Understanding context

Lesson 14: Fenrir's Personality
- System prompts
- Trading style context
- Opinion formation
- Natural language output

Lesson 15: Contextual Analysis
- Feed price + news + sector data
- Get AI opinion
- Display formatted alert
```

### PHASE 5: Real-Time System
**Goal:** Live monitoring during market hours

```
Lesson 16: Market Hours Detection
- Timezone handling
- Is market open?
- Pre-market and after-hours

Lesson 17: The Monitor Loop
- Continuous scanning
- Detecting moves
- Triggering investigations
- Alert cooldowns

Lesson 18: Desktop Notifications
- Windows notifications
- Sound alerts
- Discord webhook (optional)
```

### PHASE 6: Learning Engine
**Goal:** System learns from user's trades

```
Lesson 19: Pattern Tracking
- Win rate calculations
- By catalyst type
- By sector
- By entry conditions

Lesson 20: Feedback Loop
- Day 2 and Day 5 checks
- Update pattern database
- Adjust confidence scores
```

---

## HOW WE WORK TOGETHER

```
MONEY: "Let's build the price fetcher"

BROKKR: 
1. Explain WHAT it does (big picture)
2. Show the code with COMMENTS explaining each line
3. Let MONEY run it and see results
4. Answer questions
5. Let MONEY suggest modifications
6. Implement ideas together

MONEY: Runs code, asks "why does this line do X?"

BROKKR: Explains in plain English, no jargon

MONEY: "What if we also tracked Y?"

BROKKR: "Great idea, here's how we add that..."
```

---

## FILE STRUCTURE FOR V2

```
C:\Users\alexp\Desktop\brokkr\wolfpack\
├── fenrir_v2/
│   ├── __init__.py
│   ├── config.py           # Settings, API keys, watchlist
│   ├── database.py         # SQLite connection and queries
│   ├── price_fetcher.py    # yfinance wrapper
│   ├── news_fetcher.py     # Finnhub API
│   ├── sec_fetcher.py      # SEC EDGAR API
│   ├── ollama_brain.py     # Ollama integration
│   ├── monitor.py          # Real-time market monitor
│   ├── alerts.py           # Notification system
│   ├── decision_logger.py  # User trade logging
│   ├── pattern_learner.py  # Learning engine
│   └── main.py             # Entry point
├── data/
│   ├── wolfpack.db         # SQLite database
│   └── continuation.json   # Holdings and context
├── lessons/                 # Learning exercises
│   ├── lesson_01_variables.py
│   ├── lesson_02_lists.py
│   └── ...
└── requirements.txt
```

---

## CONTEXT FILES TO LOAD

These files contain everything about MONEY's trading style:

1. **WOLFPACK_CONTINUATION_JAN15_2026.md**
   - Current holdings with cost basis
   - Trading style definition
   - Quality criteria
   - Entry/exit rules
   - Fenrir personality guide

2. **FENRIR_V2_BUILD_SPEC.md**
   - Full architecture
   - Database schemas
   - Code examples
   - Ollama integration details

---

## CURRENT HOLDINGS (For Config)

```python
HOLDINGS = {
    'MU': {'shares': 1, 'avg_cost': 333.01, 'account': 'fidelity', 'tier': 'core'},
    'KTOS': {'shares': 3, 'avg_cost': 60.00, 'account': 'robinhood', 'tier': 'core'},
    'UEC': {'shares': 2, 'avg_cost': 17.00, 'account': 'fidelity', 'tier': 'core'},
    'SLV': {'shares': 1, 'avg_cost': 85.00, 'account': 'robinhood', 'tier': 'hedge'},
    'SRTA': {'shares': 10, 'avg_cost': 5.50, 'account': 'robinhood', 'tier': 'scout'},
    'BBAI': {'shares': 7.686, 'avg_cost': 6.50, 'account': 'fidelity', 'tier': 'screamer'},
}
```

---

## WATCHLIST (99 Stocks)

```python
WATCHLIST = {
    'holdings': ['MU', 'UEC', 'KTOS', 'SLV', 'SRTA', 'BBAI'],
    'defense': ['AVAV', 'RCAT', 'LMT', 'NOC', 'RTX', 'GD', 'PLTR', 'LDOS', 'BAH', 'HII', 'LHX', 'MRCY'],
    'space': ['LUNR', 'RKLB', 'RDW', 'ASTS', 'BKSY', 'SPCE', 'IRDM', 'GSAT'],
    'nuclear': ['UUUU', 'LEU', 'CCJ', 'NNE', 'OKLO', 'SMR', 'DNN', 'URG'],
    'semis': ['AMD', 'NVDA', 'INTC', 'MRVL', 'QCOM', 'AVGO', 'TSM', 'AMAT', 'LRCX', 'KLAC', 'ASML', 'ON'],
    'ai_tech': ['AAPL', 'MSFT', 'GOOGL', 'META', 'AMZN', 'TSLA', 'SNOW', 'AI', 'SOUN', 'UPST', 'PATH'],
    'biotech': ['EDIT', 'BEAM', 'CRSP', 'MRNA', 'REGN', 'VRTX', 'SRPT', 'ALNY', 'IONS', 'EXAS', 'NTLA'],
    'quantum': ['QUBT', 'QBTS', 'RGTI', 'IONQ'],
    'crypto': ['RIOT', 'MARA', 'COIN', 'MSTR', 'HOOD', 'SOFI', 'AFRM', 'CLSK'],
    'materials': ['GLD', 'FCX', 'AA', 'ALB', 'MP', 'LAC', 'CENX', 'CLF'],
    'evs': ['RIVN', 'LCID', 'NIO', 'XPEV', 'LI', 'GOEV'],
    'energy': ['FCEL', 'PLUG', 'BE', 'ENPH', 'RUN']
}
```

---

## FIRST SESSION GOAL

**Build Lesson 1-3 together:**
1. Create `config.py` with holdings and watchlist
2. Create `price_fetcher.py` - simple script to fetch one stock
3. MONEY runs it, sees MU's current price
4. Explain every line

**MONEY should end session able to:**
- Understand what variables are
- Read a basic Python script
- Run a script that fetches real stock data
- Modify the ticker and see different results

---

## IMPORTANT NOTES FOR BROKKR

1. **MONEY is learning** - Explain everything, assume no prior knowledge
2. **This is his full-time work** - He's serious, not casual
3. **He has ideas** - Listen for "what if we..." and implement them
4. **Keep it practical** - Every lesson should DO something with stocks
5. **Comment everything** - Every line should have a comment explaining it
6. **Test as we go** - Run code frequently, see results
7. **Build the REAL system** - Not toy examples, the actual Fenrir V2

---

## LET'S GO 🐺

Start with: "Hey MONEY, let's build your first Python script that fetches MU's current price."

---

*LLHR - Long Live the Hunt, Rise*
