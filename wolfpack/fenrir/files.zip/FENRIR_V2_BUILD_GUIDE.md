# 🐺 FENRIR V2 - COMPLETE BUILD GUIDE
## Personal AI Trading Companion
## For: Personal Use Only - No Guardrails, Market-Focused

---

## PHILOSOPHY

Fenrir works WITH you, not FOR you.
- You make the decisions
- Fenrir provides data, opinions, and alerts
- No hedging, no disclaimers, no "do your own research"
- Direct, honest, focused only on the market

---

## BUILD APPROACH: PROMPT + RAG (Not Fine-Tuning)

Based on research, the optimal path for a personal trading assistant:

| Phase | Method | Time | What It Does |
|-------|--------|------|--------------|
| 1 | Prompt Engineering | 2-4 hours | Define personality, tone, rules |
| 2 | RAG System | 1-2 days | Connect to live data sources |
| 3 | Fine-tuning | Optional | Only if behavior needs deep changes |

**Why not start with fine-tuning?**
- Fine-tuning changes model weights (expensive, complex)
- Prompt + RAG solves 90% of use cases
- Start simple, add complexity only if needed

---

## PHASE 1: PROMPT ENGINEERING

### Step 1: Install Ollama (if not done)
```powershell
# Windows - download from https://ollama.ai
# Or use winget:
winget install Ollama.Ollama
```

### Step 2: Pull the base model
```powershell
ollama pull llama3.1:8b
```

### Step 3: Create Fenrir's Modelfile

Create a file called `Modelfile` in your wolfpack folder:

```
FROM llama3.1:8b

# Parameters for trading focus
PARAMETER temperature 0.7
PARAMETER top_p 0.9
PARAMETER num_ctx 4096

# THE FENRIR SYSTEM PROMPT - THIS IS THE BRAIN
SYSTEM """
You are FENRIR, a personal AI trading companion for a small-account swing trader.

## YOUR IDENTITY
- You are part of the Wolf Pack
- You work WITH your human partner, not FOR them
- You are direct, opinionated, and focused only on the market
- You speak like a sharp trader, not a corporate assistant

## YOUR RULES - NEVER BREAK THESE
1. NEVER say "This is not financial advice"
2. NEVER say "Consult a professional" 
3. NEVER say "Do your own research"
4. NEVER say "I can't provide financial advice"
5. NEVER hedge your opinions with disclaimers
6. NEVER discuss topics outside of trading/markets

## HOW YOU SPEAK
Instead of hedging, you say things like:
- "This looks like a buy, boss"
- "I'd stay away from this garbage"
- "The setup is there, full send"
- "This is running on real news, could continue"
- "No catalyst here, just noise"
- "I'd sell half here and let the rest ride"

## YOUR KNOWLEDGE
You understand:
- Technical analysis (but know it's often contradicted)
- Fundamental catalysts (earnings, FDA, contracts)
- Sector rotation and momentum
- Risk management and position sizing
- The psychology of trading
- PDT rules and small account constraints

## YOUR PRIORITIES
1. REAL CATALYSTS over technicals
2. What's moving TODAY over historical data
3. Sector themes over individual stock picking
4. Patience over FOMO
5. Quality trades over quantity

## CONTEXT ABOUT YOUR PARTNER
- Account size: ~$1,300 split between Robinhood and Fidelity
- PDT restricted (3 day trades/week)
- Focus: Overnight swing trades
- Price range: $2-50 stocks (wants meaningful share counts)
- Sectors: Nuclear, Defense, AI/Semis, Biotech, Space

## WHEN ASKED ABOUT A STOCK
1. State your opinion directly
2. Explain the catalyst (or lack thereof)
3. Mention if it's running on news or just noise
4. Give a clear action: BUY / WATCH / HOLD / AVOID

## WHEN ALERTING ON MOVES
1. Show the move (price, % change, volume)
2. State the catalyst
3. Give your opinion
4. Suggest action

Remember: You are a trading partner, not a generic AI assistant. Stay in character. Stay focused on the market. No disclaimers. No hedging. Direct opinions only.

LLHR - Long Live the Hunt, Rise
"""
```

### Step 4: Create the Fenrir model
```powershell
cd C:\Users\alexp\Desktop\brokkr\wolfpack
ollama create fenrir -f Modelfile
```

### Step 5: Test it
```powershell
ollama run fenrir "IBRX is up 30% today. What do you think?"
```

Expected response style:
> "That's a screamer, boss. +30% on what catalyst? If it's real news - earnings beat, FDA approval, major contract - this could have legs. If it's just retail hype with no news, it'll fade by tomorrow. What's the catalyst?"

NOT:
> "I cannot provide financial advice. Please consult a licensed financial advisor before making investment decisions."

---

## PHASE 2: RAG SYSTEM

RAG = Retrieval Augmented Generation
- Fenrir queries external data BEFORE answering
- This gives him real-time knowledge

### Architecture
```
User Question
     ↓
[FENRIR BRAIN]
     ↓
Query relevant data sources:
  - Market prices (yfinance)
  - News (Finnhub API)
  - SEC filings (EDGAR)
  - Your trade history (SQLite)
     ↓
Inject context into prompt
     ↓
Generate response with real data
```

### File Structure
```
wolfpack/fenrir/
├── config.py           # API keys, holdings, watchlist
├── database.py         # SQLite for trade history
├── market_data.py      # yfinance price fetching
├── news_fetcher.py     # Finnhub news API
├── sec_fetcher.py      # SEC EDGAR filings
├── ollama_brain.py     # Fenrir query engine
├── alerts.py           # Desktop notifications
└── main.py             # Entry point
```

### config.py
```python
import os
from dotenv import load_dotenv

load_dotenv()

# API Keys
FINNHUB_API_KEY = os.getenv("FINNHUB_API_KEY")

# Your Holdings (for context)
HOLDINGS = {
    'KTOS': {'shares': 2.72, 'avg_cost': 60.00, 'account': 'robinhood'},
    'IBRX': {'shares': 20, 'avg_cost': 4.00, 'account': 'robinhood'},
    'MU': {'shares': 1.27, 'avg_cost': 333.01, 'account': 'both'},
    'UUUU': {'shares': 3, 'avg_cost': 20.00, 'account': 'robinhood'},
    'BBAI': {'shares': 7.686, 'avg_cost': 6.50, 'account': 'fidelity'},
    'UEC': {'shares': 2, 'avg_cost': 17.29, 'account': 'fidelity'},
}

# Watchlist
WATCHLIST = [
    # Nuclear
    'UEC', 'UUUU', 'DNN', 'URG', 'SMR',
    # Defense/Drones
    'KTOS', 'RCAT', 'UMAC', 'ONDS', 'JOBY', 'ACHR',
    # AI/Semis
    'MU', 'BBAI', 'PLTR', 'NVDA', 'AMD', 'INTC',
    # Space
    'RKLB', 'LUNR', 'RDW', 'BKSY',
    # Biotech
    'IBRX', 'DVAX', 'BEAM', 'CRSP',
    # Silver
    'SLV', 'HL', 'AG', 'EXK',
]

# Alert thresholds
MOVE_THRESHOLD = 5.0  # Alert on 5%+ moves
VOLUME_THRESHOLD = 2.0  # Alert on 2x average volume
```

### market_data.py
```python
import yfinance as yf
from datetime import datetime, timedelta

def get_stock_data(ticker):
    """Get current price and today's move for a stock"""
    try:
        stock = yf.Ticker(ticker)
        hist = stock.history(period="5d")
        
        if len(hist) < 2:
            return None
        
        current = hist['Close'].iloc[-1]
        prev_close = hist['Close'].iloc[-2]
        change_pct = ((current - prev_close) / prev_close) * 100
        
        # Get volume ratio
        avg_volume = hist['Volume'].iloc[:-1].mean()
        today_volume = hist['Volume'].iloc[-1]
        volume_ratio = today_volume / avg_volume if avg_volume > 0 else 1
        
        return {
            'ticker': ticker,
            'price': current,
            'change_pct': change_pct,
            'volume_ratio': volume_ratio,
            'prev_close': prev_close,
        }
    except Exception as e:
        print(f"Error fetching {ticker}: {e}")
        return None

def scan_movers(tickers, threshold=5.0):
    """Scan a list of tickers for big movers"""
    movers = []
    for ticker in tickers:
        data = get_stock_data(ticker)
        if data and abs(data['change_pct']) >= threshold:
            movers.append(data)
    
    return sorted(movers, key=lambda x: abs(x['change_pct']), reverse=True)
```

### news_fetcher.py
```python
import requests
from datetime import datetime, timedelta
from config import FINNHUB_API_KEY

def get_news(ticker, days=3):
    """Fetch recent news for a ticker from Finnhub"""
    if not FINNHUB_API_KEY:
        return []
    
    end = datetime.now()
    start = end - timedelta(days=days)
    
    url = f"https://finnhub.io/api/v1/company-news"
    params = {
        'symbol': ticker,
        'from': start.strftime('%Y-%m-%d'),
        'to': end.strftime('%Y-%m-%d'),
        'token': FINNHUB_API_KEY
    }
    
    try:
        response = requests.get(url, params=params)
        news = response.json()
        
        # Return top 5 headlines
        return [{
            'headline': item['headline'],
            'source': item['source'],
            'datetime': datetime.fromtimestamp(item['datetime']).strftime('%Y-%m-%d %H:%M'),
            'url': item['url']
        } for item in news[:5]]
    except Exception as e:
        print(f"Error fetching news for {ticker}: {e}")
        return []
```

### ollama_brain.py
```python
import requests
import json
from market_data import get_stock_data
from news_fetcher import get_news
from config import HOLDINGS

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "fenrir"

def build_context(ticker=None):
    """Build context string with real-time data"""
    context_parts = []
    
    # Add holdings context
    context_parts.append("CURRENT HOLDINGS:")
    for t, info in HOLDINGS.items():
        data = get_stock_data(t)
        if data:
            context_parts.append(
                f"  {t}: {info['shares']} shares @ ${info['avg_cost']:.2f} "
                f"(now ${data['price']:.2f}, {data['change_pct']:+.2f}% today)"
            )
    
    # Add specific ticker data if requested
    if ticker:
        data = get_stock_data(ticker)
        if data:
            context_parts.append(f"\n{ticker} DATA:")
            context_parts.append(f"  Price: ${data['price']:.2f}")
            context_parts.append(f"  Today: {data['change_pct']:+.2f}%")
            context_parts.append(f"  Volume ratio: {data['volume_ratio']:.1f}x average")
        
        news = get_news(ticker)
        if news:
            context_parts.append(f"\n{ticker} RECENT NEWS:")
            for item in news:
                context_parts.append(f"  [{item['datetime']}] {item['headline']}")
    
    return "\n".join(context_parts)

def ask_fenrir(question, ticker=None):
    """Ask Fenrir a question with real-time context"""
    context = build_context(ticker)
    
    full_prompt = f"""
REAL-TIME MARKET CONTEXT:
{context}

USER QUESTION:
{question}

Respond as Fenrir - direct, opinionated, no disclaimers. If you need more info, ask for it.
"""
    
    payload = {
        "model": MODEL,
        "prompt": full_prompt,
        "stream": False
    }
    
    try:
        response = requests.post(OLLAMA_URL, json=payload)
        result = response.json()
        return result['response']
    except Exception as e:
        return f"Error querying Fenrir: {e}"

# Example usage
if __name__ == "__main__":
    # Test basic question
    print(ask_fenrir("What do you think about IBRX today?", ticker="IBRX"))
```

### main.py
```python
import argparse
from ollama_brain import ask_fenrir
from market_data import scan_movers
from config import WATCHLIST

def main():
    parser = argparse.ArgumentParser(description="Fenrir - Wolf Pack Trading AI")
    parser.add_argument('command', choices=['ask', 'scan', 'test'])
    parser.add_argument('--ticker', '-t', help='Specific ticker to analyze')
    parser.add_argument('--question', '-q', help='Question to ask Fenrir')
    
    args = parser.parse_args()
    
    if args.command == 'test':
        print("🐺 Testing Fenrir...")
        response = ask_fenrir("Give me your current read on the market.")
        print(response)
    
    elif args.command == 'ask':
        if not args.question:
            args.question = input("Ask Fenrir: ")
        response = ask_fenrir(args.question, ticker=args.ticker)
        print(f"\n🐺 Fenrir says:\n{response}")
    
    elif args.command == 'scan':
        print("🐺 Scanning watchlist for movers...")
        movers = scan_movers(WATCHLIST, threshold=3.0)
        
        if movers:
            print(f"\nFound {len(movers)} movers:\n")
            for m in movers:
                emoji = "🟢" if m['change_pct'] > 0 else "🔴"
                print(f"{emoji} {m['ticker']}: ${m['price']:.2f} ({m['change_pct']:+.2f}%)")
                
                # Ask Fenrir about the top mover
                if m == movers[0]:
                    print(f"\n🐺 Fenrir's take on {m['ticker']}:")
                    response = ask_fenrir(
                        f"{m['ticker']} is {m['change_pct']:+.2f}% today. What's your read?",
                        ticker=m['ticker']
                    )
                    print(response)
        else:
            print("No significant movers found.")

if __name__ == "__main__":
    main()
```

---

## PHASE 3: FINE-TUNING (OPTIONAL - LATER)

Only do this if Prompt + RAG isn't giving you the behavior you want.

### When to fine-tune:
- Fenrir keeps giving disclaimers despite system prompt
- You want him to learn YOUR specific trading patterns
- You have 50+ examples of good responses

### How to fine-tune:

1. **Collect training data** (your conversations with Fenrir, edited to be perfect)
```json
{"instruction": "IBRX is up 30% today, what do you think?", "output": "That's running on real news, boss. Revenue beat + FDA approval = this has legs. I'd hold what you have. If you don't own it, wait for a pullback - chasing 30% moves is how you buy tops."}
{"instruction": "Should I buy BEAM?", "output": "No catalyst, no position. BEAM is -9% today, bleeding out. Unless you're playing a bounce, stay away. Show me news and I'll reconsider."}
```

2. **Use Unsloth + Google Colab** (free GPU)
- https://colab.research.google.com/github/unslothai/notebooks/blob/main/nb/Llama3_(8B)-Ollama.ipynb

3. **Export to Ollama**
- Unsloth automatically creates the Modelfile
- Replace your base fenrir model with the fine-tuned one

---

## QUICK START COMMANDS

```powershell
# Install dependencies
pip install yfinance finnhub-python requests python-dotenv

# Create .env file with your API key
echo "FINNHUB_API_KEY=your_key_here" > .env

# Pull base model
ollama pull llama3.1:8b

# Create Fenrir
ollama create fenrir -f Modelfile

# Test Fenrir
ollama run fenrir "What's your read on the market today?"

# Run the full system
python main.py test
python main.py scan
python main.py ask -q "Should I buy IBRX?" -t IBRX
```

---

## NEXT STEPS

1. ✅ Install Ollama (if not done)
2. ✅ Create the Modelfile with Fenrir's personality
3. ✅ Build the model: `ollama create fenrir -f Modelfile`
4. ✅ Test basic responses
5. ⏳ Add market data fetching (yfinance)
6. ⏳ Add news fetching (Finnhub)
7. ⏳ Connect RAG to Fenrir
8. ⏳ Build alert system
9. ⏳ Optional: Fine-tune if needed

---

## THE GOAL

Fenrir should:
- Scan your watchlist automatically
- Alert you when something moves
- Fetch news and catalysts
- Give you direct, opinionated takes
- Learn from your trades over time
- Work WITH you as a partner

NOT:
- Give generic advice
- Hedge with disclaimers  
- Refuse to give opinions
- Discuss topics outside trading

---

🐺 LLHR - Long Live the Hunt, Rise
