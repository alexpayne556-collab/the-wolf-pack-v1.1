# 🐺 FENRIR V2 - CONFIG
# Personal AI Trading Companion Configuration

import os
from dotenv import load_dotenv

load_dotenv()

# =============================================================================
# API KEYS
# =============================================================================
FINNHUB_API_KEY = os.getenv("FINNHUB_API_KEY", "")

# =============================================================================
# YOUR HOLDINGS (Update as you trade)
# Last updated: Jan 16, 2026
# =============================================================================
HOLDINGS = {
    # ROBINHOOD
    'KTOS': {'shares': 2.72, 'avg_cost': 60.00, 'account': 'robinhood', 'thesis': 'Defense/Drones - beast mode'},
    'IBRX': {'shares': 20, 'avg_cost': 4.00, 'account': 'robinhood', 'thesis': 'Biotech - 700% revenue growth, FDA approvals'},
    'MU': {'shares': 0.27, 'avg_cost': 333.01, 'account': 'robinhood', 'thesis': 'AI memory - fractional'},
    'UUUU': {'shares': 3, 'avg_cost': 20.00, 'account': 'robinhood', 'thesis': 'Nuclear/Uranium'},
    
    # FIDELITY
    'BBAI': {'shares': 7.686, 'avg_cost': 6.50, 'account': 'fidelity', 'thesis': 'AI/Defense'},
    'MU_fidelity': {'shares': 1, 'avg_cost': 333.01, 'account': 'fidelity', 'thesis': 'AI memory - core'},
    'UEC': {'shares': 2, 'avg_cost': 17.29, 'account': 'fidelity', 'thesis': 'Nuclear/Uranium'},
}

# =============================================================================
# WATCHLIST BY SECTOR
# =============================================================================
# RULE: Only stocks that ACTUALLY MOVE in our price range ($2-50)
# These came from real scans - not generic picks
# Updated: Jan 16, 2026

WATCHLIST = {
    # NUCLEAR - All move together, uranium thesis
    'nuclear': ['UEC', 'UUUU', 'DNN', 'URG', 'SMR'],
    
    # DEFENSE/DRONES - Hot sector, real momentum
    'defense': [
        'RCAT',   # Drones - was +90% last month
        'UMAC',   # Drones - was +88% last month  
        'ONDS',   # Defense tech
        'BBAI',   # AI/Defense - WE OWN THIS
        'JOBY',   # eVTOL - $8
        'ACHR',   # eVTOL - $10
        'RGR',    # Guns - $43
    ],
    
    # AI INFRASTRUCTURE - Cheap plays, not megacaps
    'ai_infra': [
        'AEHR',   # Semi equipment - $26
        'ICHR',   # Semi equipment - $28
        'KULR',   # Thermal management - $4
        'APLD',   # AI data centers - $8
        'CORZ',   # Bitcoin/AI compute - $18
    ],
    
    # QUANTUM - Hot sector, volatile cheap plays
    'quantum': [
        'QUBT',   # Quantum computing - $20
        'RGTI',   # Rigetti - $15
        'IONQ',   # Ion trap quantum - $45
        'QBTS',   # D-Wave - $8
    ],
    
    # CRYPTO MINERS - Move with BTC
    'crypto': [
        'BTDR',   # Bitdeer - $22
        'MARA',   # Marathon - $22
        'RIOT',   # Riot - $14
        'CORZ',   # Core Scientific - $18
        'BTBT',   # Bit Digital - $4
    ],
    
    # SPACE - Real runners
    'space': [
        'LUNR',   # Moon lander - was +81%
        'RDW',    # Space infra - was +65%
        'BKSY',   # Satellite imaging - $28
        'SATL',   # Satellogic - $3.49 CHEAP
        'ASTS',   # Space mobile - $24
    ],
    
    # BIOTECH - Catalyst driven, we caught IBRX
    'biotech': [
        'IBRX',   # WE OWN THIS - cancer drug runner
        'DVAX',   # Vaccines - $15
        'RGC',    # Was +80% (watch for bounce)
        'ANNX',   # $6 cheap
        'SLRX',   # $0.87 super cheap high share count
        'SAVA',   # Alzheimer's play - volatile
    ],
    
    # SILVER/MINERS - Commodity play, silver ATH
    'silver': [
        'HL',     # Hecla - largest US silver producer
        'AG',     # First Majestic - $20
        'EXK',    # Endeavour - $11
        'CDE',    # Coeur - $21
        'SVM',    # Silvercorp
    ],
    
    # CHEAP RUNNERS - High share count plays under $5
    'cheap_runners': [
        'IBRX',   # $4-5 range, 150+ shares
        'SATL',   # $3.49, 220+ shares
        'KULR',   # $4, 190+ shares
        'SLRX',   # $0.87, 890+ shares
        'URG',    # $1.83, 420+ shares  
        'DNN',    # $3.55, 218+ shares
        'HUYA',   # $3.75, 200+ shares
        'ANNX',   # $6, 125+ shares
    ],
    
    # RECENT MOVERS - Stocks that ran THIS MONTH (Jan 2026)
    'hot_now': [
        'IBRX',   # +33% today
        'SKIL',   # +12% today
        'HL',     # +6% today (silver ATH)
        'EVEX',   # +5% today
        'UMAC',   # +5.6% today
        'BTDR',   # +3.4% today
        'ICHR',   # +3.2% today
    ],
}

# Flat list for scanning
ALL_WATCHLIST = []
for sector, tickers in WATCHLIST.items():
    ALL_WATCHLIST.extend(tickers)
ALL_WATCHLIST = list(set(ALL_WATCHLIST))

# =============================================================================
# ALERT THRESHOLDS
# =============================================================================
MOVE_THRESHOLD_PCT = 5.0      # Alert on 5%+ moves
VOLUME_THRESHOLD_RATIO = 2.0  # Alert on 2x average volume
SCAN_INTERVAL_MINUTES = 15    # How often to scan during market hours

# =============================================================================
# ACCOUNT INFO (Update after trades)
# Last updated: Jan 16, 2026
# =============================================================================
ROBINHOOD_CASH = 191.74
FIDELITY_CASH = 87.64
TOTAL_CASH = ROBINHOOD_CASH + FIDELITY_CASH  # ~$279 dry powder

# Portfolio totals (approximate)
ROBINHOOD_VALUE = 810.89
FIDELITY_VALUE = 524.89
TOTAL_PORTFOLIO = ROBINHOOD_VALUE + FIDELITY_VALUE  # ~$1,335

# =============================================================================
# OLLAMA SETTINGS
# =============================================================================
OLLAMA_MODEL = "fenrir"
OLLAMA_URL = "http://localhost:11434/api/generate"

# =============================================================================
# DATABASE
# =============================================================================
DB_PATH = "fenrir_trades.db"
