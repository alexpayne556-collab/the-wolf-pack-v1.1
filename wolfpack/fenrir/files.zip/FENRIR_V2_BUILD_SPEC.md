# 🐺 FENRIR V2 - AI TRADING COMPANION
## Real-Time Intelligence with Local LLM (Ollama)
### Build Spec for VS Code Agent

---

## CORE CONCEPT

Fenrir V2 is NOT a data logger. It's an AI PARTNER that:
1. **MONITORS** the market in real-time
2. **FETCHES** actual catalysts (news, SEC filings)
3. **THINKS** using Ollama to form opinions
4. **ALERTS** with context and suggestions
5. **LEARNS** from user's actual decisions

---

## ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────┐
│                        FENRIR V2                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  LAYER 1: REAL-TIME MONITOR (9:30 AM - 4:00 PM)                │
│  ──────────────────────────────────────────────────────────────│
│  • Watch Wolfpack 100 every 60 seconds                         │
│  • Detect moves >3% or volume >2x                              │
│  • Priority monitoring on HOLDINGS                             │
│                                                                 │
│  LAYER 2: CATALYST FETCHER (Event-Triggered)                   │
│  ──────────────────────────────────────────────────────────────│
│  • When move detected → Auto-fetch news (Finnhub)              │
│  • When move detected → Auto-fetch SEC filings (EDGAR)         │
│  • Link catalyst to move permanently in database               │
│                                                                 │
│  LAYER 3: OLLAMA AI BRAIN                                      │
│  ──────────────────────────────────────────────────────────────│
│  • Analyze catalyst + price action + sector context            │
│  • Form OPINION based on user's trading style                  │
│  • Generate natural language alert with suggestion             │
│  • Learn patterns from outcomes                                │
│                                                                 │
│  LAYER 4: ALERT SYSTEM                                         │
│  ──────────────────────────────────────────────────────────────│
│  • Desktop notification with context                           │
│  • Terminal output with opinion                                │
│  • Optional: Discord webhook                                   │
│                                                                 │
│  LAYER 5: DECISION LOGGER                                      │
│  ──────────────────────────────────────────────────────────────│
│  • User logs: "Bought 10 KTOS @ $118 because DOD contract"     │
│  • System tracks Day 2, Day 5 outcomes                         │
│  • Builds personal pattern database                            │
│                                                                 │
│  LAYER 6: LEARNING ENGINE                                      │
│  ──────────────────────────────────────────────────────────────│
│  • Analyzes user's actual win/loss patterns                    │
│  • Updates suggestions based on what works for THIS user       │
│  • "Your DOD contract plays win 73% of the time"               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## OLLAMA INTEGRATION

### Setup
```bash
# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh

# Pull a model (choose one)
ollama pull llama3.1:8b      # Good balance
ollama pull mistral:7b       # Fast
ollama pull deepseek-r1:8b   # Reasoning focused
```

### Python Integration
```python
import ollama

def get_fenrir_opinion(context: dict) -> str:
    """
    Send context to Ollama and get Fenrir's opinion
    """
    
    system_prompt = """
    You are FENRIR, the Wolf Pack AI trading companion.
    
    TRADING STYLE:
    - Small account (~$1,300), PDT restricted (3 day trades/week)
    - Focus: Overnight swings, NOT day trading
    - Sectors: AI infrastructure, Defense, Nuclear, Space
    - Philosophy: React to confirmed moves, don't predict
    - Quality criteria: Real revenue, growing, sector tailwind
    
    CURRENT HOLDINGS:
    - MU (Micron) - Core position, AI memory thesis
    - KTOS (Kratos) - Core position, drone/defense thesis  
    - UEC (Uranium Energy) - Nuclear thesis
    - BBAI (BigBear.ai) - Screamer play, AI/defense
    - SRTA - Medical transport
    - SLV - Silver hedge
    
    YOUR ROLE:
    - Speak naturally, like a partner (call user "boss" sometimes)
    - Be direct, not verbose
    - Give OPINIONS, not just data
    - Consider: Does this fit our style? Risk/reward? Catalyst real?
    """
    
    user_message = f"""
    ALERT CONTEXT:
    Ticker: {context['ticker']}
    Move: {context['move_pct']}%
    Volume: {context['volume_ratio']}x average
    Sector: {context['sector']}
    Sector Performance: {context['sector_performance']}
    
    NEWS FOUND:
    {context['news']}
    
    SEC FILINGS:
    {context['sec_filings']}
    
    IS THIS A HOLDING: {context['is_holding']}
    
    Based on our trading style, what's your take? Should we act?
    Keep it to 2-3 sentences max.
    """
    
    response = ollama.chat(
        model='llama3.1:8b',
        messages=[
            {'role': 'system', 'content': system_prompt},
            {'role': 'user', 'content': user_message}
        ]
    )
    
    return response['message']['content']
```

### Example Fenrir Outputs

**Alert 1: Holding Drops**
```
🐺 FENRIR ALERT - MU

Move: -4.2% | Volume: 1.8x

NEWS: "Memory chip prices see pressure amid inventory concerns"

FENRIR'S TAKE:
"Boss, MU is pulling back on sector-wide memory pricing fears. 
Thesis still intact - HBM demand for AI hasn't changed. This 
looks like a shakeout, not a breakdown. I'd hold unless it 
breaks $320 support."
```

**Alert 2: Watchlist Opportunity**
```
🐺 FENRIR ALERT - DNN

Move: -7.5% | Volume: 2.3x

NEWS: No negative news found
SEC: No new filings

FENRIR'S TAKE:
"Interesting - DNN is down big but I can't find any bad news.
Nuclear sector is actually up today (UEC +2%). This looks like
a sympathy selloff or profit-taking. Could be the dip entry
we've been waiting for. You've got $200 in the dip reserve."
```

**Alert 3: Screamer Running**
```
🐺 FENRIR ALERT - BBAI

Move: +12.3% | Volume: 3.5x

NEWS: "BigBear.ai announces expansion of Air Force contract"
SEC: 8-K filed - Material contract modification

FENRIR'S TAKE:
"Your screamer is screaming, boss. Real catalyst - Air Force
contract expansion. Volume confirms buyers. You're up 12% on
this position. Consider taking half off to lock profits, let
the rest ride. Classic 'pay yourself' setup."
```

---

## DATABASE SCHEMA

### Table: holdings
```sql
CREATE TABLE holdings (
    id INTEGER PRIMARY KEY,
    ticker VARCHAR(10) NOT NULL,
    shares DECIMAL(10,4),
    avg_cost DECIMAL(10,4),
    account VARCHAR(20),  -- 'fidelity' or 'robinhood'
    tier VARCHAR(20),     -- 'core', 'screamer', 'hedge'
    thesis TEXT,
    entry_date DATE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Table: decisions
```sql
CREATE TABLE decisions (
    id INTEGER PRIMARY KEY,
    ticker VARCHAR(10) NOT NULL,
    action VARCHAR(10),       -- 'buy', 'sell', 'hold'
    shares DECIMAL(10,4),
    price DECIMAL(10,4),
    reason TEXT,              -- User's reason
    catalyst_id INTEGER,      -- Link to what triggered it
    fenrir_opinion TEXT,      -- What Fenrir said
    decision_time TIMESTAMP,
    day2_price DECIMAL(10,4),
    day2_result_pct DECIMAL(6,2),
    day5_price DECIMAL(10,4),
    day5_result_pct DECIMAL(6,2),
    outcome VARCHAR(20),      -- 'win', 'loss', 'pending'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Table: catalysts
```sql
CREATE TABLE catalysts (
    id INTEGER PRIMARY KEY,
    ticker VARCHAR(10) NOT NULL,
    detected_at TIMESTAMP,
    move_pct DECIMAL(6,2),
    volume_ratio DECIMAL(5,2),
    catalyst_type VARCHAR(50),
    headline TEXT,
    source VARCHAR(100),
    url TEXT,
    sec_filing_type VARCHAR(20),
    sec_filing_url TEXT,
    sector_context TEXT,
    fenrir_analysis TEXT,     -- Ollama's interpretation
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Table: patterns
```sql
CREATE TABLE patterns (
    id INTEGER PRIMARY KEY,
    pattern_name VARCHAR(100),
    description TEXT,
    total_trades INTEGER,
    wins INTEGER,
    losses INTEGER,
    win_rate DECIMAL(5,2),
    avg_win_pct DECIMAL(6,2),
    avg_loss_pct DECIMAL(6,2),
    expected_value DECIMAL(6,2),
    last_updated TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## REAL-TIME MONITOR

### market_monitor.py
```python
import time
import yfinance as yf
from datetime import datetime
import pytz

class MarketMonitor:
    def __init__(self, watchlist: list, holdings: list):
        self.watchlist = watchlist
        self.holdings = holdings
        self.last_prices = {}
        self.alert_cooldown = {}  # Prevent spam
        
    def is_market_open(self) -> bool:
        """Check if US market is open"""
        et = pytz.timezone('US/Eastern')
        now = datetime.now(et)
        
        # Weekday check
        if now.weekday() >= 5:
            return False
            
        # Time check (9:30 AM - 4:00 PM ET)
        market_open = now.replace(hour=9, minute=30, second=0)
        market_close = now.replace(hour=16, minute=0, second=0)
        
        return market_open <= now <= market_close
    
    def scan_for_moves(self) -> list:
        """Scan all stocks for significant moves"""
        alerts = []
        
        for ticker in self.watchlist:
            try:
                data = yf.Ticker(ticker)
                info = data.fast_info
                
                current_price = info.last_price
                prev_close = info.previous_close
                volume = info.last_volume
                avg_volume = data.info.get('averageVolume', volume)
                
                change_pct = ((current_price - prev_close) / prev_close) * 100
                volume_ratio = volume / avg_volume if avg_volume > 0 else 1
                
                # Alert triggers
                is_holding = ticker in self.holdings
                
                if is_holding:
                    # Lower threshold for holdings
                    threshold = 3.0
                else:
                    threshold = 5.0
                
                if abs(change_pct) >= threshold or volume_ratio >= 2.5:
                    # Check cooldown (don't alert same stock within 30 min)
                    if self._check_cooldown(ticker):
                        alerts.append({
                            'ticker': ticker,
                            'price': current_price,
                            'change_pct': change_pct,
                            'volume_ratio': volume_ratio,
                            'is_holding': is_holding,
                            'timestamp': datetime.now()
                        })
                        self._set_cooldown(ticker)
                        
            except Exception as e:
                print(f"Error scanning {ticker}: {e}")
                continue
                
        return alerts
    
    def _check_cooldown(self, ticker: str) -> bool:
        """Check if we can alert for this ticker"""
        if ticker not in self.alert_cooldown:
            return True
        return (datetime.now() - self.alert_cooldown[ticker]).seconds > 1800
    
    def _set_cooldown(self, ticker: str):
        """Set cooldown for ticker"""
        self.alert_cooldown[ticker] = datetime.now()

    def run(self, interval_seconds: int = 60):
        """Main monitoring loop"""
        print("🐺 FENRIR MARKET MONITOR ACTIVE")
        print(f"Watching {len(self.watchlist)} stocks")
        print(f"Holdings: {self.holdings}")
        print("-" * 50)
        
        while True:
            if self.is_market_open():
                alerts = self.scan_for_moves()
                
                for alert in alerts:
                    # This triggers the full investigation pipeline
                    self.process_alert(alert)
            else:
                print("Market closed. Sleeping...")
                time.sleep(300)  # Check every 5 min when closed
                continue
                
            time.sleep(interval_seconds)
    
    def process_alert(self, alert: dict):
        """Full alert processing pipeline"""
        # 1. Fetch catalysts
        news = fetch_news(alert['ticker'])
        sec_filings = fetch_sec_filings(alert['ticker'])
        sector_data = get_sector_performance(alert['ticker'])
        
        # 2. Build context for Ollama
        context = {
            'ticker': alert['ticker'],
            'move_pct': alert['change_pct'],
            'volume_ratio': alert['volume_ratio'],
            'sector': sector_data['sector'],
            'sector_performance': sector_data['performance'],
            'news': news,
            'sec_filings': sec_filings,
            'is_holding': alert['is_holding']
        }
        
        # 3. Get Fenrir's opinion
        opinion = get_fenrir_opinion(context)
        
        # 4. Store catalyst in database
        store_catalyst(context, opinion)
        
        # 5. Display alert
        display_alert(alert, context, opinion)
        
        # 6. Send notification
        send_notification(alert, opinion)
```

---

## CATALYST FETCHERS

### news_fetcher.py (Finnhub)
```python
import finnhub
from datetime import datetime, timedelta

# Free API key from finnhub.io
finnhub_client = finnhub.Client(api_key="YOUR_API_KEY")

def fetch_news(ticker: str, days_back: int = 2) -> list:
    """Fetch recent news for a ticker"""
    
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days_back)
    
    news = finnhub_client.company_news(
        ticker,
        _from=start_date.strftime('%Y-%m-%d'),
        to=end_date.strftime('%Y-%m-%d')
    )
    
    # Return top 5 most recent
    return [
        {
            'headline': article['headline'],
            'source': article['source'],
            'url': article['url'],
            'datetime': article['datetime'],
            'summary': article.get('summary', '')[:200]
        }
        for article in news[:5]
    ]
```

### sec_fetcher.py (EDGAR)
```python
import requests
from datetime import datetime, timedelta

SEC_BASE_URL = "https://data.sec.gov"
HEADERS = {'User-Agent': 'WolfPack Trading Bot contact@email.com'}

def fetch_sec_filings(ticker: str, days_back: int = 7) -> list:
    """Fetch recent SEC filings for a ticker"""
    
    # Get CIK from ticker
    cik = get_cik_for_ticker(ticker)
    if not cik:
        return []
    
    # Fetch recent filings
    url = f"{SEC_BASE_URL}/submissions/CIK{cik.zfill(10)}.json"
    response = requests.get(url, headers=HEADERS)
    
    if response.status_code != 200:
        return []
    
    data = response.json()
    recent_filings = data.get('filings', {}).get('recent', {})
    
    filings = []
    cutoff_date = datetime.now() - timedelta(days=days_back)
    
    for i in range(min(20, len(recent_filings.get('form', [])))):
        filing_date = datetime.strptime(recent_filings['filingDate'][i], '%Y-%m-%d')
        
        if filing_date >= cutoff_date:
            form_type = recent_filings['form'][i]
            
            # Focus on material filings
            if form_type in ['8-K', '4', '10-Q', '10-K', 'S-1', '13F']:
                filings.append({
                    'form': form_type,
                    'date': recent_filings['filingDate'][i],
                    'description': recent_filings.get('primaryDocDescription', [''])[i],
                    'url': f"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK={cik}&type={form_type}"
                })
    
    return filings

def get_cik_for_ticker(ticker: str) -> str:
    """Get CIK number for a ticker symbol"""
    url = "https://www.sec.gov/files/company_tickers.json"
    response = requests.get(url, headers=HEADERS)
    
    if response.status_code == 200:
        data = response.json()
        for entry in data.values():
            if entry['ticker'] == ticker.upper():
                return str(entry['cik_str'])
    return None
```

---

## DECISION LOGGER

### decision_logger.py
```python
class DecisionLogger:
    def __init__(self, db_connection):
        self.db = db_connection
    
    def log_decision(self):
        """Interactive decision logging"""
        
        print("\n🐺 LOG DECISION")
        print("-" * 30)
        
        ticker = input("Ticker: ").upper()
        action = input("Action (buy/sell/hold): ").lower()
        
        if action in ['buy', 'sell']:
            shares = float(input("Shares: "))
            price = float(input("Price: "))
        else:
            shares = None
            price = None
            
        reason = input("Why? (brief): ")
        
        # Get current Fenrir opinion for context
        fenrir_opinion = input("What did Fenrir say? (or 'none'): ")
        
        # Store in database
        cursor = self.db.cursor()
        cursor.execute("""
            INSERT INTO decisions 
            (ticker, action, shares, price, reason, fenrir_opinion, decision_time)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (ticker, action, shares, price, reason, fenrir_opinion, datetime.now()))
        
        self.db.commit()
        
        print(f"✅ Logged: {action.upper()} {shares} {ticker} @ ${price}")
        print("   Will track Day 2 and Day 5 outcomes.")
        
    def update_outcomes(self):
        """Update Day 2 and Day 5 results for pending decisions"""
        
        cursor = self.db.cursor()
        
        # Find decisions needing Day 2 update
        cursor.execute("""
            SELECT id, ticker, price, action, decision_time
            FROM decisions
            WHERE day2_price IS NULL
            AND decision_time < datetime('now', '-1 day')
        """)
        
        for row in cursor.fetchall():
            decision_id, ticker, entry_price, action, decision_time = row
            
            # Get current price
            current_price = yf.Ticker(ticker).fast_info.last_price
            
            if action == 'buy':
                result_pct = ((current_price - entry_price) / entry_price) * 100
            else:  # sell
                result_pct = ((entry_price - current_price) / entry_price) * 100
            
            cursor.execute("""
                UPDATE decisions
                SET day2_price = ?, day2_result_pct = ?
                WHERE id = ?
            """, (current_price, result_pct, decision_id))
        
        self.db.commit()
```

---

## LEARNING ENGINE

### pattern_learner.py
```python
class PatternLearner:
    def __init__(self, db_connection):
        self.db = db_connection
    
    def analyze_patterns(self):
        """Analyze user's trading patterns"""
        
        cursor = self.db.cursor()
        
        # Overall stats
        cursor.execute("""
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN day5_result_pct > 0 THEN 1 ELSE 0 END) as wins,
                AVG(CASE WHEN day5_result_pct > 0 THEN day5_result_pct END) as avg_win,
                AVG(CASE WHEN day5_result_pct < 0 THEN day5_result_pct END) as avg_loss
            FROM decisions
            WHERE action = 'buy' AND day5_result_pct IS NOT NULL
        """)
        
        overall = cursor.fetchone()
        
        # By catalyst type
        cursor.execute("""
            SELECT 
                c.catalyst_type,
                COUNT(*) as trades,
                SUM(CASE WHEN d.day5_result_pct > 0 THEN 1 ELSE 0 END) as wins,
                AVG(d.day5_result_pct) as avg_result
            FROM decisions d
            JOIN catalysts c ON d.catalyst_id = c.id
            WHERE d.action = 'buy' AND d.day5_result_pct IS NOT NULL
            GROUP BY c.catalyst_type
            ORDER BY wins DESC
        """)
        
        by_catalyst = cursor.fetchall()
        
        return {
            'overall': {
                'total_trades': overall[0],
                'wins': overall[1],
                'win_rate': (overall[1] / overall[0] * 100) if overall[0] > 0 else 0,
                'avg_win': overall[2],
                'avg_loss': overall[3]
            },
            'by_catalyst': by_catalyst
        }
    
    def get_suggestion_context(self, ticker: str, catalyst_type: str) -> str:
        """Get context for Ollama based on user's patterns"""
        
        patterns = self.analyze_patterns()
        
        context = f"""
        USER'S TRADING PATTERNS:
        - Overall win rate: {patterns['overall']['win_rate']:.1f}%
        - Average win: +{patterns['overall']['avg_win']:.1f}%
        - Average loss: {patterns['overall']['avg_loss']:.1f}%
        
        For {catalyst_type} plays specifically:
        """
        
        for catalyst in patterns['by_catalyst']:
            if catalyst[0] == catalyst_type:
                win_rate = (catalyst[2] / catalyst[1] * 100) if catalyst[1] > 0 else 0
                context += f"- {catalyst[1]} trades, {win_rate:.0f}% win rate, avg {catalyst[3]:.1f}%"
        
        return context
```

---

## MAIN ENTRY POINT

### main.py
```python
#!/usr/bin/env python3
"""
🐺 FENRIR V2 - AI Trading Companion
"""

import argparse
from monitor import MarketMonitor
from decision_logger import DecisionLogger
from pattern_learner import PatternLearner
from database import init_db

# Load from continuation file
HOLDINGS = ['MU', 'UEC', 'KTOS', 'SLV', 'SRTA', 'BBAI']

WATCHLIST = [
    # Holdings
    'MU', 'UEC', 'KTOS', 'SLV', 'SRTA', 'BBAI',
    # Defense
    'AVAV', 'RCAT', 'LMT', 'NOC', 'RTX', 'GD', 'PLTR', 'LDOS', 'BAH', 'HII', 'LHX', 'MRCY',
    # Space
    'LUNR', 'RKLB', 'RDW', 'ASTS', 'BKSY', 'SPCE', 'IRDM', 'GSAT',
    # Nuclear
    'UUUU', 'LEU', 'CCJ', 'NNE', 'OKLO', 'SMR', 'DNN', 'URG',
    # Semis
    'AMD', 'NVDA', 'INTC', 'MRVL', 'QCOM', 'AVGO', 'TSM', 'AMAT', 'LRCX', 'KLAC', 'ASML', 'ON',
    # AI/Tech
    'AAPL', 'MSFT', 'GOOGL', 'META', 'AMZN', 'TSLA', 'SNOW', 'AI', 'SOUN', 'UPST', 'PATH',
    # Quantum
    'QUBT', 'QBTS', 'RGTI', 'IONQ'
]

def main():
    parser = argparse.ArgumentParser(description='🐺 FENRIR V2')
    parser.add_argument('command', choices=['monitor', 'log', 'patterns', 'update'])
    args = parser.parse_args()
    
    db = init_db()
    
    if args.command == 'monitor':
        # Real-time market monitoring
        monitor = MarketMonitor(WATCHLIST, HOLDINGS)
        monitor.run(interval_seconds=60)
        
    elif args.command == 'log':
        # Log a decision
        logger = DecisionLogger(db)
        logger.log_decision()
        
    elif args.command == 'patterns':
        # Show learned patterns
        learner = PatternLearner(db)
        patterns = learner.analyze_patterns()
        print("\n🐺 YOUR TRADING PATTERNS")
        print("-" * 40)
        print(f"Total Trades: {patterns['overall']['total_trades']}")
        print(f"Win Rate: {patterns['overall']['win_rate']:.1f}%")
        print(f"Average Win: +{patterns['overall']['avg_win']:.1f}%")
        print(f"Average Loss: {patterns['overall']['avg_loss']:.1f}%")
        
    elif args.command == 'update':
        # Update Day 2/5 outcomes
        logger = DecisionLogger(db)
        logger.update_outcomes()
        print("✅ Outcomes updated")

if __name__ == '__main__':
    main()
```

---

## USAGE

```bash
# Start real-time monitoring
python main.py monitor

# Log a trade decision
python main.py log

# View your patterns
python main.py patterns

# Update pending outcomes
python main.py update
```

---

## REQUIREMENTS.TXT

```
yfinance>=0.2.28
finnhub-python>=2.4.18
ollama>=0.1.0
requests>=2.31.0
pandas>=2.0.0
pytz>=2023.3
schedule>=1.2.0
```

---

## WHAT THIS BUILDS

1. **REAL-TIME ALERTS** - During market hours, catches moves as they happen
2. **AUTO-FETCHES CATALYSTS** - News and SEC filings linked to moves
3. **AI OPINIONS** - Ollama provides context-aware suggestions
4. **DECISION TRACKING** - Log YOUR trades, track outcomes
5. **PATTERN LEARNING** - System learns what works for YOU

---

🐺 **LLHR - Long Live the Hunt, Rise**

*This is the real deal. Not a logger - a partner.*
