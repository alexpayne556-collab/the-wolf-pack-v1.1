# BROKKR - FENRIR V2 BUILD INSTRUCTIONS
## READ THIS ENTIRE FILE BEFORE DOING ANYTHING

---

## WHO YOU'RE BUILDING FOR

A swing trader with ~$1,345 across two brokers. PDT restricted (3 day trades/week max). Trades overnight holds in the $2-50 range. Catches moves AFTER they start - reacts, doesn't predict.

**This is real money. Every decision matters.**

---

## WHAT FENRIR IS

Fenrir is a SECRETARY, not a thinker. He:
- Fetches and formats data
- Tracks state over time
- Alerts when things CHANGE
- Remembers everything
- Does the boring work fast

Fenrir does NOT:
- Give trading opinions
- Say "buy" or "sell"
- Make predictions
- Use disclaimers
- Think deeply

**The human and Claude (the partner) do the thinking. Fenrir does the work.**

---

## EXISTING FILES TO REVIEW

Location: `C:\Users\alexp\Desktop\brokkr\wolfpack\fenrir\`

Review each file and understand what exists:
- `config.py` - Settings and API keys
- `database.py` - SQLite storage
- `market_data.py` - Price/volume fetching
- `news_fetcher.py` - News retrieval
- `sec_fetcher.py` - SEC filings
- `alerts.py` - Alert system
- `ollama_brain.py` - LLM interface
- `main.py` - Entry point
- `Modelfile` - Fenrir's personality
- `.env` - API keys (DO NOT EXPOSE)

---

## REAL HOLDINGS - UPDATE config.py WITH THESE

### ROBINHOOD ACCOUNT:
```python
ROBINHOOD_HOLDINGS = {
    'KTOS': {'shares': 2.717026, 'avg_cost': 117.83},
    'IBRX': {'shares': 37.081823, 'avg_cost': 4.69},
    'MU': {'shares': 0.268306, 'avg_cost': 339.61},
    'UUUU': {'shares': 3.0, 'avg_cost': 22.09},
}
ROBINHOOD_CASH = 100.74
```

### FIDELITY ACCOUNT:
```python
FIDELITY_HOLDINGS = {
    'BBAI': {'shares': 7.686, 'avg_cost': 6.50},
    'MU': {'shares': 1.0, 'avg_cost': 333.01},
    'UEC': {'shares': 2.0, 'avg_cost': 17.29},
}
FIDELITY_CASH = 87.64
```

### COMBINED HOLDINGS (merge MU positions):
```python
HOLDINGS = {
    'KTOS': {'shares': 2.717026, 'avg_cost': 117.83, 'broker': 'RH'},
    'IBRX': {'shares': 37.081823, 'avg_cost': 4.69, 'broker': 'RH'},
    'MU': {'shares': 1.268306, 'avg_cost': 334.48, 'broker': 'BOTH'},  # weighted avg
    'UUUU': {'shares': 3.0, 'avg_cost': 22.09, 'broker': 'RH'},
    'BBAI': {'shares': 7.686, 'avg_cost': 6.50, 'broker': 'FID'},
    'UEC': {'shares': 2.0, 'avg_cost': 17.29, 'broker': 'FID'},
}
TOTAL_CASH = 188.38
```

---

## THE STATE TRACKING SYSTEM - THIS IS CRITICAL

Fenrir must track EACH stock's state and adapt his behavior.

### Stock States:
```python
STOCK_STATES = {
    'dead': 'No movement, check daily',
    'watching': 'On watchlist, check hourly', 
    'mover': '5%+ move today, check every 30 min',
    'running': 'Multi-day run with catalyst, check every 15 min',
    'RUNNING_POSITION': 'WE OWN IT and its running, check every 5 min',
    'BLEEDING_POSITION': 'WE OWN IT and its dropping, check every 2 min - URGENT',
}
```

### Adaptive Check Frequency:
```python
def get_check_frequency(status, we_own, change_pct):
    """Returns minutes between checks"""
    
    if we_own:
        if change_pct <= -5:
            return 2    # BLEEDING - check every 2 min
        elif change_pct >= 5:
            return 5    # Running position - every 5 min
        else:
            return 15   # Normal position - every 15 min
    else:
        if abs(change_pct) >= 10:
            return 15   # Big mover - watch closely
        elif abs(change_pct) >= 5:
            return 30   # Mover - check often
        else:
            return 60   # Watchlist - hourly
```

### State Tracking Database Schema:
```sql
CREATE TABLE stock_state (
    ticker TEXT PRIMARY KEY,
    status TEXT,                    -- dead/watching/mover/running
    days_running INTEGER DEFAULT 0,
    run_start_price REAL,
    run_start_date TEXT,
    high_of_day REAL,
    low_of_day REAL,
    current_price REAL,
    prev_close REAL,
    volume_today INTEGER,
    volume_avg INTEGER,
    volume_ratio REAL,
    volume_trend TEXT,              -- increasing/steady/fading
    last_catalyst TEXT,
    catalyst_date TEXT,
    we_own INTEGER DEFAULT 0,
    our_shares REAL,
    our_avg_cost REAL,
    our_pnl_dollars REAL,
    our_pnl_percent REAL,
    check_frequency INTEGER,        -- minutes
    last_check TEXT,
    next_check TEXT,
    updated_at TEXT
);

CREATE TABLE intraday_ticks (
    id INTEGER PRIMARY KEY,
    ticker TEXT,
    timestamp TEXT,
    price REAL,
    volume INTEGER,
    high_so_far REAL,
    low_so_far REAL
);

CREATE TABLE alerts_log (
    id INTEGER PRIMARY KEY,
    ticker TEXT,
    alert_type TEXT,                -- price_alert/volume_spike/news/state_change
    severity TEXT,                  -- info/warning/urgent
    message TEXT,
    price_at_alert REAL,
    timestamp TEXT,
    acknowledged INTEGER DEFAULT 0
);

CREATE TABLE daily_summary (
    id INTEGER PRIMARY KEY,
    date TEXT,
    ticker TEXT,
    open REAL,
    high REAL,
    low REAL,
    close REAL,
    volume INTEGER,
    change_pct REAL,
    catalyst TEXT,
    notes TEXT
);

CREATE TABLE trade_log (
    id INTEGER PRIMARY KEY,
    timestamp TEXT,
    ticker TEXT,
    action TEXT,                    -- BUY/SELL
    shares REAL,
    price REAL,
    broker TEXT,
    thesis TEXT,
    outcome TEXT
);
```

---

## TIME-BASED SCHEDULE - WHEN FENRIR WORKS

### Pre-Market (4:00 AM - 9:30 AM ET):
```python
PREMARKET_SCHEDULE = {
    '4:00': 'Check futures, overnight news on positions',
    '6:00': 'Pre-market scan - what gapped?',
    '8:00': 'News refresh on all positions',
    '9:00': 'Final pre-market check, prepare watchlist',
    '9:25': 'Last look before open',
}
```

### Market Hours (9:30 AM - 4:00 PM ET):
```python
MARKET_SCHEDULE = {
    '9:30': 'MARKET OPEN - watch, dont chase',
    '9:45': 'First 15-min candle close - real direction',
    '10:00': 'KEY REVERSAL WINDOW - check all positions',
    '10:30': 'Second reversal window',
    '11:00': 'Third reversal window', 
    '11:30': 'Pre-lunch check',
    '12:00': 'Lunch lull - reduce frequency',
    '13:00': 'Afternoon session starts',
    '14:00': 'Two hours to close',
    '15:00': 'Final hour - volume picks up',
    '15:30': 'Last 30 min - make decisions',
    '15:55': 'Final check before close',
}
```

### After Hours (4:00 PM - 8:00 PM ET):
```python
AFTERHOURS_SCHEDULE = {
    '16:00': 'MARKET CLOSE - day summary',
    '16:15': 'Check AH movement on positions',
    '17:00': 'Earnings releases start dropping',
    '18:00': 'News digest - what happened today',
    '19:00': 'Prep for tomorrow - catalyst calendar',
    '20:00': 'Final AH check',
}
```

### ADAPTIVE Override:
```python
# If a position is RUNNING or BLEEDING, ignore schedule
# Check at adaptive frequency until status normalizes

if position_status in ['RUNNING_POSITION', 'BLEEDING_POSITION']:
    check_at_adaptive_frequency()  # Could be every 2-5 minutes
```

---

## ALERT SYSTEM - WHAT FENRIR TELLS US

### CRITICAL: 5% IS NOT THE ONLY TRIGGER

A stock down 3% pre-market that reverses and rips 15% at open = MISSED if we only watch 5%+ movers.

**Fenrir must track CHARACTER CHANGES, not just thresholds.**

### Alert Types:
```python
ALERT_TYPES = {
    # === REVERSALS (CRITICAL - often the best entries) ===
    'PREMARKET_RED_OPENS_GREEN': {
        'trigger': 'Stock was red pre-market, opens green with volume',
        'severity': 'warning',
        'action': 'Potential reversal play - watch for continuation',
    },
    'PREMARKET_GREEN_OPENS_RED': {
        'trigger': 'Stock gapped up pre-market, opens red/fading',
        'severity': 'info',
        'action': 'Gap trap potential - watch for failure',
    },
    'INTRADAY_REVERSAL': {
        'trigger': 'Stock was red, turned green (or vice versa) with volume',
        'severity': 'warning',
        'action': 'Character change - reassess',
    },
    
    # === VOLUME (Something is happening) ===
    'VOLUME_SPIKE_POSITION': {
        'trigger': 'Volume 2x+ avg on a POSITION',
        'severity': 'urgent',
        'action': 'IMMEDIATE - check news, check price action',
    },
    'VOLUME_SPIKE_WATCHLIST': {
        'trigger': 'Volume 2x+ avg on watchlist stock',
        'severity': 'warning',
        'action': 'Something happening - investigate',
    },
    'VOLUME_FADING_RUNNER': {
        'trigger': 'Stock was running, volume now fading',
        'severity': 'info',
        'action': 'Run may be exhausting - watch for rollover',
    },
    
    # === NEWS (Always alert) ===
    'NEWS_ON_POSITION': {
        'trigger': 'Any news on a position we own',
        'severity': 'urgent',
        'action': 'Read immediately, assess impact',
    },
    'NEWS_ON_WATCHLIST': {
        'trigger': 'Any news on watchlist stock',
        'severity': 'warning',
        'action': 'Check if catalyst is real',
    },
    'EARNINGS_RELEASED': {
        'trigger': 'Earnings dropped on position or watchlist',
        'severity': 'urgent',
        'action': 'Numbers + guidance + reaction',
    },
    
    # === POSITION ALERTS ===
    'POSITION_RUNNING': {
        'trigger': 'Position up 5%+ today',
        'severity': 'warning',
        'action': 'Increase monitoring to every 5 min',
    },
    'POSITION_BLEEDING': {
        'trigger': 'Position down 5%+ today',
        'severity': 'urgent', 
        'action': 'IMMEDIATE - check every 2 min, find out why',
    },
    'POSITION_NEW_HOD': {
        'trigger': 'Position makes new high of day',
        'severity': 'info',
        'action': 'Log level, trail stop mentally',
    },
    'POSITION_NEW_LOD': {
        'trigger': 'Position makes new low of day',
        'severity': 'warning',
        'action': 'Support broken? Check thesis',
    },
    
    # === CHARACTER CHANGES ===
    'FLAT_TO_MOVING': {
        'trigger': 'Stock was flat, now moving with volume',
        'severity': 'info',
        'action': 'Waking up - find out why',
    },
    'RUNNING_TO_FADING': {
        'trigger': 'Stock was running, now fading/red',
        'severity': 'warning',
        'action': 'Run may be over - watch for support',
    },
    'BLEEDING_TO_STABILIZING': {
        'trigger': 'Stock was bleeding, found support with volume',
        'severity': 'info',
        'action': 'Potential bottom - wounded prey?',
    },
    'WOUNDED_PREY_WAKING': {
        'trigger': 'Stock down 30%+ from highs, now volume spike + green',
        'severity': 'warning',
        'action': 'Tax loss bounce? Real reversal? Check news',
    },
    
    # === LEVEL BREAKS ===
    'BROKE_RESISTANCE': {
        'trigger': 'Stock broke above key level',
        'severity': 'info',
        'action': 'Breakout - watch for continuation',
    },
    'BROKE_SUPPORT': {
        'trigger': 'Stock broke below key level',
        'severity': 'warning',
        'action': 'Breakdown - if position, reassess',
    },
    
    # === THRESHOLD MOVERS (but not ONLY these) ===
    'MOVER_5PCT_UP': {
        'trigger': 'Watchlist stock up 5%+ with 1.5x volume',
        'severity': 'info',
        'action': 'Check catalyst, assess entry',
    },
    'MOVER_10PCT_UP': {
        'trigger': 'Any stock up 10%+ with 2x volume',
        'severity': 'warning',
        'action': 'Big move - real catalyst?',
    },
}
```

### Pre-Market to Open Sequence (CRITICAL):
```python
PREMARKET_SEQUENCE = {
    '4:00 AM': {
        'action': 'Note all gaps - UP and DOWN',
        'track': ['gap_pct', 'volume', 'any_news'],
    },
    '6:00 AM': {
        'action': 'Check for pre-market reversals',
        'track': ['direction_change', 'volume_trend'],
    },
    '8:00 AM': {
        'action': 'News refresh on all positions',
        'track': ['news', 'price_vs_6am'],
    },
    '9:25 AM': {
        'action': 'Final pre-market snapshot',
        'save': ['premarket_price', 'premarket_direction', 'premarket_volume'],
    },
    '9:30 AM': {
        'action': 'COMPARE open to pre-market',
        'alerts': [
            'Gap down but opening green? → ALERT reversal',
            'Gap up but fading? → ALERT trap',
            'Flat but volume surge? → ALERT breakout',
        ],
    },
    '9:45 AM': {
        'action': 'First 15-min candle closed',
        'assess': 'This candle tells the story - continuation or reversal?',
    },
    '10:00 AM': {
        'action': 'First reversal window',
        'watch': 'Stocks that were red may turn here',
    },
}
```

### Alert Format:
```
🚨 [SEVERITY] - [TICKER] @ [TIME]
=====================================
[WHAT HAPPENED]

Price: $XX.XX ([+/-]X.XX% today)
Volume: X.Xx avg

[IF WE OWN IT:]
Your position: XX shares @ $XX.XX
Your P/L: $[+/-]XX.XX ([+/-]X.X%)

[CATALYST/NEWS IF ANY]

[WHAT CHANGED SINCE LAST CHECK]
=====================================
```

---

## OUTPUT FORMATS - HOW FENRIR SPEAKS

### Quick Check (single stock):
```
================
IBRX - RUNNING_POSITION 🔥
================
Price: $5.37
Today: +35.2%
Volume: 3.5x avg (increasing)
HOD: $5.52 | LOD: $3.95
----------------
YOUR POSITION:
37.08 shares @ $4.69
Value: $199.07
P/L: +$25.20 (+14.5%)
----------------
Day 10 of run
Catalyst: Q4 revenue +700% YoY
----------------
Last check: 2:45 PM
Changed: +$0.12 since last
================
```

### Portfolio Summary:
```
====================================
PORTFOLIO - 3:45 PM ET
====================================

📱 ROBINHOOD ($715.42)
------------------------------------
🔥 KTOS: +4.8% today | +10.8% total
🔥 IBRX: +35.2% today | +14.5% total  
🟢 MU: +6.7% today | +5.8% total
🔴 UUUU: -1.0% today | -1.0% total
💵 Cash: $100.74

🏦 FIDELITY ($530.07)
------------------------------------
🟢 BBAI: +1.7% today | -3.4% total
🟢 MU: +6.7% today | +7.2% total
🟢 UEC: +0.8% today | +1.9% total
💵 Cash: $87.64

====================================
TOTAL: $1,433.87
TODAY: +$67.42 (+4.9%)
OVERALL: +$89.25 (+6.6%)
====================================

⚠️ ATTENTION NEEDED:
- IBRX running Day 10, +35% today
- Consider: trim or ride?
====================================
```

### Daily Summary (End of Day):
```
====================================
DAILY SUMMARY - January 16, 2026
====================================

📈 WINNERS:
- IBRX: +35.2% (Q4 earnings catalyst)
- MU: +6.7% (AI memory demand)  
- KTOS: +4.8% (defense momentum)

📉 LOSERS:
- UUUU: -1.0% (sector rotation)

💰 PORTFOLIO CHANGE: +$67.42 (+4.9%)

🎯 KEY EVENTS:
- IBRX Day 10 of run, new HOD $5.52
- MU broke above $359 resistance

📰 NEWS THAT MATTERED:
- IBRX: "700% Anktiva Sales Jump"
- KTOS: Defense contract rumors

🔮 TOMORROW WATCH:
- IBRX: Can it hold gains? Watch $5.00
- Earnings after close: [none in portfolio]

====================================
```

---

## WATCHLIST - STOCKS TO SCAN

### Core Sectors (these ALWAYS get scanned):
```python
WATCHLIST = {
    'nuclear': ['UEC', 'UUUU', 'DNN', 'URG', 'SMR', 'LEU', 'CCJ'],
    'defense': ['KTOS', 'RCAT', 'UMAC', 'ONDS', 'BBAI', 'JOBY', 'ACHR'],
    'ai_infrastructure': ['MU', 'AEHR', 'ICHR', 'KULR', 'APLD', 'CORZ', 'SMCI'],
    'quantum': ['QUBT', 'RGTI', 'IONQ', 'QBTS'],
    'space': ['LUNR', 'RDW', 'BKSY', 'SATL', 'ASTS', 'RKLB', 'PL'],
    'biotech': ['IBRX', 'DVAX', 'RGC', 'ANNX', 'SLRX', 'SAVA'],
    'silver': ['HL', 'AG', 'EXK', 'CDE', 'SVM'],
    'crypto_miners': ['MARA', 'RIOT', 'BTDR', 'BTBT', 'CORZ'],
}
```

### Dynamic Movers (scan entire market for these):
```python
MOVER_CRITERIA = {
    'min_change_pct': 5.0,      # Minimum move to care
    'min_volume_ratio': 1.5,    # At least 1.5x normal volume  
    'min_price': 1.00,          # No penny stocks
    'max_price': 100.00,        # Focus on affordable
    'prefer_price': (2, 50),    # Sweet spot for position sizing
}
```

---

## FULL MARKET SCANNER - THIS IS CRITICAL

Fenrir must scan the ENTIRE tradeable universe, not just a small watchlist.

### Why This Matters:
- User beat S&P 500 by 30-40x today (+6.86% vs +0.17%)
- The edge is finding movers BEFORE they're obvious
- Can't find what you don't scan

### Scan Tiers:

**TIER 1 - POSITIONS (Every 2-15 min based on state):**
```python
# These are ALWAYS priority
POSITIONS = ['KTOS', 'IBRX', 'MU', 'UUUU', 'BBAI', 'UEC']
```

**TIER 2 - CORE WATCHLIST (Every 30-60 min):**
```python
# ~60 stocks in key sectors
WATCHLIST = {
    'nuclear': ['UEC', 'UUUU', 'DNN', 'URG', 'SMR', 'LEU', 'CCJ'],
    'defense': ['KTOS', 'RCAT', 'UMAC', 'ONDS', 'BBAI', 'JOBY', 'ACHR', 'RGR'],
    'ai_infrastructure': ['MU', 'AEHR', 'ICHR', 'KULR', 'APLD', 'CORZ', 'SMCI', 'VRT'],
    'quantum': ['QUBT', 'RGTI', 'IONQ', 'QBTS'],
    'space': ['LUNR', 'RDW', 'BKSY', 'SATL', 'ASTS', 'RKLB', 'PL'],
    'biotech': ['IBRX', 'DVAX', 'RGC', 'ANNX', 'SLRX', 'SAVA'],
    'silver': ['HL', 'AG', 'EXK', 'CDE', 'SVM'],
    'crypto_miners': ['MARA', 'RIOT', 'BTDR', 'BTBT', 'CORZ', 'COIN', 'MSTR'],
}
```

**TIER 3 - FULL MARKET SCAN (2-3x daily):**
```python
# Scan 8,000+ tickers, filter to meaningful movers
FULL_SCAN_SCHEDULE = {
    '6:00 AM': 'Pre-market gap scan',
    '10:30 AM': 'Mid-morning mover scan', 
    '3:00 PM': 'Afternoon momentum scan',
}

FULL_SCAN_CRITERIA = {
    'min_change_pct': 5.0,
    'min_volume_ratio': 1.5,
    'min_price': 1.00,
    'max_price': 100.00,
    'min_avg_volume': 100000,  # Filter out illiquid garbage
}
```

### How to Get All Tickers:

```python
import pandas as pd

def get_all_tradeable_tickers():
    """Get ~8,000 tradeable US stocks"""
    
    # Method 1: NASDAQ FTP (free, comprehensive)
    nasdaq_url = 'ftp://ftp.nasdaqtrader.com/symboldirectory/nasdaqlisted.txt'
    other_url = 'ftp://ftp.nasdaqtrader.com/symboldirectory/otherlisted.txt'
    
    try:
        nasdaq = pd.read_csv(nasdaq_url, sep='|')
        other = pd.read_csv(other_url, sep='|')
        
        # Filter to common stocks only
        nasdaq_tickers = nasdaq[nasdaq['ETF'] == 'N']['Symbol'].tolist()
        other_tickers = other[other['ETF'] == 'N']['ACT Symbol'].tolist()
        
        all_tickers = list(set(nasdaq_tickers + other_tickers))
        
        # Remove test symbols and weird characters
        all_tickers = [t for t in all_tickers if t.isalpha() and len(t) <= 5]
        
        return all_tickers
    except:
        # Fallback to cached list
        return FALLBACK_TICKER_LIST

# Cache this daily, don't fetch every scan
```

### Parallel Scanning (FAST):

```python
from concurrent.futures import ThreadPoolExecutor, as_completed
import yfinance as yf

def scan_single_ticker(ticker):
    """Check one ticker - return if it's a mover"""
    try:
        stock = yf.Ticker(ticker)
        hist = stock.history(period='5d')
        
        if len(hist) < 2:
            return None
        
        price = hist['Close'].iloc[-1]
        prev = hist['Close'].iloc[-2]
        change = ((price - prev) / prev) * 100
        
        avg_vol = hist['Volume'].iloc[:-1].mean()
        today_vol = hist['Volume'].iloc[-1]
        vol_ratio = today_vol / avg_vol if avg_vol > 0 else 0
        
        # Filter criteria
        if (abs(change) >= 5.0 and 
            vol_ratio >= 1.5 and 
            1.0 <= price <= 100.0 and
            avg_vol >= 100000):
            
            return {
                'ticker': ticker,
                'price': price,
                'change': change,
                'vol_ratio': vol_ratio,
            }
    except:
        pass
    return None

def full_market_scan():
    """Scan entire market in parallel"""
    
    tickers = get_all_tradeable_tickers()
    print(f"Scanning {len(tickers)} tickers...")
    
    movers = []
    
    # Use 50 parallel workers - fast!
    with ThreadPoolExecutor(max_workers=50) as executor:
        futures = {executor.submit(scan_single_ticker, t): t for t in tickers}
        
        for future in as_completed(futures):
            result = future.result()
            if result:
                movers.append(result)
    
    # Sort by move size
    movers = sorted(movers, key=lambda x: abs(x['change']), reverse=True)
    
    print(f"Found {len(movers)} movers")
    return movers[:50]  # Top 50 movers
```

### What Full Scan Returns:
```
=====================================
FULL MARKET SCAN - 10:30 AM
=====================================
Found 47 movers (5%+ with volume)

🔥 TOP MOVERS:
1. IBRX: $5.37 (+35.2%) - 3.5x vol
2. SMTK: $12.45 (+28.1%) - 4.2x vol  
3. RGTI: $8.92 (+18.4%) - 2.8x vol
4. ASTS: $117.00 (+15.5%) - 2.1x vol
5. RIOT: $14.23 (+12.3%) - 1.9x vol
...

⚠️ ALREADY OWN:
- IBRX (#1) - Position running!

📰 NEED CATALYST CHECK:
- SMTK, RGTI, RIOT (no news = skip)
=====================================
```

### Integration with State Tracker:

When full scan finds a mover:
1. Check if we own it → If yes, flag as RUNNING_POSITION
2. Check if on watchlist → If yes, elevate to 'mover' status
3. If new ticker → Fetch news, check catalyst
4. No catalyst → Log but don't alert
5. Real catalyst → Add to watchlist, alert user

---

## API KEYS - CHECK .env FILE

The .env file should have:
```
FINNHUB_API_KEY=your_key_here
ALPHA_VANTAGE_KEY=your_key_here  
POLYGON_API_KEY=your_key_here
SEC_USER_AGENT=YourName your@email.com
```

If any are missing, the system should fall back to yfinance (slower but free).

---

## THE MODELFILE - FENRIR'S PERSONALITY

Update the Modelfile to this:
```
FROM llama3.1:8b

PARAMETER temperature 0.3
PARAMETER num_ctx 4096

SYSTEM """
You are FENRIR, a trading data secretary.

YOUR JOB:
- Format data cleanly
- Track state changes
- Alert on important moves
- Remember context
- Be fast and accurate

WHEN GIVEN STOCK DATA, FORMAT IT:
================
[TICKER] - [STATUS]
Price: $XX.XX
Today: [+/-]X.XX%
Volume: X.Xx avg
----------------
[Additional context]
================

WHEN WE OWN A STOCK, ALWAYS SHOW:
- Our shares and avg cost
- Current value
- P/L in dollars and percent
- How long we've held

STATUS FLAGS:
- 🔥 RUNNING: Position up 5%+ today
- 🩸 BLEEDING: Position down 5%+ today
- 🟢 GREEN: Up but normal
- 🔴 RED: Down but normal
- 👀 WATCHING: On watchlist, not owned

WHAT TO HIGHLIGHT:
- New high/low of day
- Volume changes (increasing/fading)
- Days in a run
- Catalyst if known
- What CHANGED since last check

NEVER SAY:
- "I think you should..."
- "Consider buying/selling..."
- "Not financial advice"
- "Do your own research"
- Any opinion on trades

ALWAYS BE:
- Fast
- Clean
- Factual
- Specific about numbers

LLHR.
"""
```

---

## MAIN LOOP LOGIC

```python
async def main_loop():
    """The heart of Fenrir"""
    
    while True:
        current_time = datetime.now()
        
        # 1. Check if market hours
        market_status = get_market_status(current_time)
        
        # 2. Get stocks that need checking
        to_check = get_stocks_due_for_check()
        
        # 3. Prioritize: positions first, then by urgency
        to_check.sort(key=lambda x: (
            not x['we_own'],           # Positions first
            -x['urgency_score'],       # Then by urgency
        ))
        
        # 4. Check each stock
        for stock in to_check:
            try:
                # Fetch fresh data
                data = fetch_stock_data(stock['ticker'])
                
                # Compare to previous state
                changes = detect_changes(stock['ticker'], data)
                
                # Update state in database
                update_stock_state(stock['ticker'], data)
                
                # Generate alerts if needed
                if changes['significant']:
                    alert = generate_alert(stock, data, changes)
                    send_alert(alert)
                
                # Adjust check frequency based on new state
                new_frequency = calculate_check_frequency(data, stock['we_own'])
                update_check_frequency(stock['ticker'], new_frequency)
                
            except Exception as e:
                log_error(stock['ticker'], e)
        
        # 5. Run scheduled tasks
        run_scheduled_tasks(current_time)
        
        # 6. Sleep until next check needed
        next_check = get_next_check_time()
        sleep_duration = (next_check - datetime.now()).seconds
        await asyncio.sleep(min(sleep_duration, 60))  # Max 1 min sleep
```

---

## COMMANDS FENRIR RESPONDS TO

```
fenrir check IBRX          - Full check on ticker
fenrir portfolio           - Show all positions with P/L
fenrir scan                 - Scan watchlist for movers
fenrir scan all            - Full market scan
fenrir news IBRX           - Get news for ticker
fenrir alerts              - Show recent alerts
fenrir status              - Show what Fenrir is tracking
fenrir holdings            - Quick holdings list
fenrir log BUY IBRX 20 4.50 "earnings play"  - Log a trade
fenrir history             - Show trade history
fenrir summary             - End of day summary
fenrir watch ADD TSLA      - Add to watchlist
fenrir watch REMOVE TSLA   - Remove from watchlist
fenrir help                - Show commands
```

---

## TESTING CHECKLIST

Before considering this done, test:

1. [ ] `fenrir check IBRX` - Shows correct position data
2. [ ] `fenrir portfolio` - Shows all positions with real P/L
3. [ ] `fenrir scan` - Finds movers in watchlist
4. [ ] Alert triggers when position moves 5%+
5. [ ] State persists between restarts (SQLite)
6. [ ] Check frequency adapts to stock status
7. [ ] News fetching works
8. [ ] Scheduled tasks run at right times
9. [ ] After-hours data works
10. [ ] No opinions or disclaimers in output

---

## ITERATE AND IMPROVE

This is not one-and-done. After each test:

1. Note what's wrong
2. Fix the code
3. Test again
4. If Fenrir's OUTPUT format is wrong → update Modelfile and recreate
5. If DATA is wrong → fix fetcher
6. If LOGIC is wrong → fix the code

Keep iterating until it's RIGHT.

---

## REMEMBER

- This is real money ($1,345)
- Every alert matters
- Speed matters but accuracy matters more
- Track everything, forget nothing
- Positions get priority ALWAYS
- No opinions - just facts

**Fenrir is a secretary. Make him the best damn secretary possible.**

LLHR 🐺
