# 🐺 THE BIG PICTURE: WHAT ACTUALLY MOVES STOCKS

*"Pull back the veil and let's get going down the real big picture road"*
*- MONEY, January 15, 2026*

---

## THE FUNDAMENTAL TRUTH

**A stock price is just the last price someone paid for it.**

That's it. Every price movement = someone buying and someone selling.

The question isn't "why did the stock go up?" 
The question is "WHO bought, and WHY did they buy NOW?"

---

## THE 7 LAYERS OF STOCK MOVEMENT

```
LAYER 7: MACRO ENVIRONMENT
         ↓
LAYER 6: SECTOR/THEME ROTATION  
         ↓
LAYER 5: COMPANY FUNDAMENTALS
         ↓
LAYER 4: CATALYSTS (News/Events)
         ↓
LAYER 3: INFORMATION FLOW (Who knows what, when)
         ↓
LAYER 2: PSYCHOLOGY (Fear/Greed/FOMO)
         ↓
LAYER 1: ORDER FLOW (Actual buying/selling)
         ↓
     PRICE MOVES
```

---

## LAYER 7: MACRO ENVIRONMENT
*The ocean current that carries all boats*

| Factor | Impact | How It Works |
|--------|--------|--------------|
| **Fed Policy** | MASSIVE | Rate cuts = money flows into risk assets. Rate hikes = money leaves. |
| **Inflation Data** | HIGH | CPI/PPI above expectations = hawkish Fed = stocks fall |
| **GDP/Jobs** | MEDIUM | Goldilocks = best (not too hot, not too cold) |
| **Geopolitics** | VARIABLE | Wars, tariffs, sanctions create uncertainty |
| **Risk Sentiment** | HIGH | "Risk On" = small caps fly. "Risk Off" = flee to safety |

**For Small Caps:** When macro is favorable, small caps outperform. When fear rises, they get crushed first.

---

## LAYER 6: SECTOR/THEME ROTATION
*Money flows between sectors like tides*

### Current Hot Themes (Jan 2026):
- AI Infrastructure (not just NVDA - the fuel: cooling, power, memory)
- Defense/Space (geopolitical tension)
- Nuclear (clean energy + AI power demand)
- Quantum Computing (speculative but running)

### How Rotation Works:
1. Theme emerges (AI, nuclear renaissance, space race)
2. Institutions allocate to theme
3. ETFs get created/flows increase
4. Retail discovers theme
5. Late money piles in
6. Smart money rotates OUT to next theme
7. Theme crashes or consolidates

### Correlation Reality:
- Quantum stocks move together (0.81 correlation)
- QBTS/RGTI = 0.91 correlation (almost the same stock)
- When sector moves, EVERYTHING in it moves

---

## LAYER 5: COMPANY FUNDAMENTALS
*The actual business underneath the ticker*

### What Creates REAL Value:
| Fundamental | Impact | Small Cap Reality |
|-------------|--------|-------------------|
| Revenue Growth | HIGH | High growth = premium multiple |
| Earnings | MEDIUM | Many small caps lose money - focus on PATH to profit |
| Contracts/Deals | HIGH | Government contracts = guaranteed revenue |
| TAM (Total Addressable Market) | HIGH | Small company in massive market = moonshot potential |
| Cash Runway | CRITICAL | Running out of cash = dilution or death |
| Competitive Moat | MEDIUM | Does anyone ELSE do what they do? |

### Small Cap vs Large Cap:
- **Large Cap:** Earnings matter. Guidance matters. 
- **Small Cap:** STORY matters. Thesis matters. What COULD they become?

### The Thesis Question:
For each stock, ask:
- What is the bull case? (Why could this 10x?)
- What is the bear case? (Why could this go to zero?)
- What catalyst would prove/disprove the thesis?

---

## LAYER 4: CATALYSTS
*The triggers that make price MOVE NOW*

### Catalyst Hierarchy (Impact Ranking):

#### TIER 1: MASSIVE MOVERS (Can move stock 20-100%+)
| Catalyst | Typical Impact | Example |
|----------|----------------|---------|
| FDA Approval (biotech) | +30% to +500% | Drug approval after years of trials |
| Major Acquisition | +20% to +50% | Buyout at premium |
| Government Contract (large) | +15% to +50% | DOD contract for defense stock |
| Clinical Trial Success | +20% to +100%+ | Phase 3 positive results |
| Breakthrough Technology | +20% to +100%+ | Major patent, first-to-market |

#### TIER 2: SIGNIFICANT MOVERS (Can move stock 5-20%)
| Catalyst | Typical Impact | Example |
|----------|----------------|---------|
| Earnings Beat | +5% to +20% | Revenue/EPS above estimates |
| Revenue Deal/Partnership | +5% to +20% | Major customer announcement |
| Analyst Upgrade | +3% to +10% | Price target raised significantly |
| Index Inclusion | +5% to +15% | Added to Russell 2000, etc. |
| Insider Buying (Form 4) | +3% to +10% | CEO/CFO buying shares |

#### TIER 3: MODERATE MOVERS (Can move stock 2-5%)
| Catalyst | Typical Impact | Example |
|----------|----------------|---------|
| Conference Presentation | +2% to +8% | Investor day, industry conference |
| New Product Launch | +2% to +10% | Product actually ships |
| Partnership (vague) | +1% to +5% | "Strategic collaboration" |
| Executive Hire | +1% to +5% | New CEO/CTO from major company |

#### NO CATALYST (Ghost Moves):
Some stocks move 10%+ with NO apparent news. This is:
- Sector sympathy (another stock in sector moved)
- Options activity (gamma squeeze building)
- Short covering
- Dark pool activity
- Social media pump (Reddit/Twitter/Discord)
- Retail FOMO cascade

---

## LAYER 3: INFORMATION FLOW
*WHO knows WHAT, and WHEN*

### The Information Cascade (Fastest to Slowest):

```
0ms      : EVENT HAPPENS
          ↓
<1sec    : Algorithmic systems detect (SEC filing, news wire)
          ↓
1-30sec  : Bloomberg terminals, professional traders
          ↓
1-5min   : Twitter/X (fast finance accounts)
          ↓
5-15min  : Discord servers, premium alert services
          ↓
15-60min : Reddit (r/wallstreetbets, sector subs)
          ↓
1-4hrs   : StockTwits, Seeking Alpha, YouTube
          ↓
Next AM  : Broker app notifications (Robinhood, Fidelity)
          ↓
Next Day : CNBC, mainstream financial news
          ↓
Week+    : Your uncle tells you about it at dinner
```

### Where Retail Gets Info (2025 Data):
| Source | % of Gen Z/Millennials | Trust Level |
|--------|------------------------|-------------|
| Reddit | 37% | Highest |
| YouTube | 34% | High |
| Twitter/X | 28% | Medium |
| TikTok | 14% | Growing fast |
| Discord | ~10% | High (closed groups) |
| Traditional News | <10% | Low |

### SEC Filing Speed:
- **8-K (Current Report):** Filed within 4 business days of material event
- **Form 4 (Insider Trading):** Filed within 2 business days
- **13-F (Institutional Holdings):** Filed 45 days after quarter end (DELAYED!)

**Edge Location:** Between algo detection and broker app notifications (5-60 min window)

---

## LAYER 2: PSYCHOLOGY
*The human behavior that drives irrational moves*

### The Retail Behavior Patterns:

#### CONFIRMED BY RESEARCH:
| Behavior | What It Means | Impact |
|----------|---------------|--------|
| **Momentum Chasing** | Buy stocks that are up, sell stocks that are down | Creates trends |
| **FOMO** | Fear of missing out on gains | Piles into winners |
| **Loss Aversion** | Hold losers, sell winners too early | Creates resistance levels |
| **Herd Behavior** | Follow what crowd is doing | Amplifies moves |
| **Recency Bias** | Expect recent past to continue | Overreact to short-term |
| **Confirmation Bias** | Seek info that confirms existing view | Echo chambers |

#### THE RETAIL CYCLE:
1. Stock starts moving (smart money enters)
2. Shows up on scanners (momentum detected)
3. Social media starts buzzing
4. Retail buys into strength (FOMO)
5. Price accelerates (more FOMO)
6. Smart money sells into retail buying
7. Price peaks and reverses
8. Retail holds hoping for recovery ("diamond hands")
9. Price continues falling
10. Retail panic sells at bottom
11. Smart money re-enters

**The Edge:** Don't be step 4. Be step 3 (catch it early) or step 6 (sell into FOMO).

### Emotional Triggers That Move Stocks:
- **Fear of Missing Out (FOMO):** Drives buying into strength
- **Fear of Loss (FOL):** Drives panic selling at lows
- **Greed:** Holds too long, turns winners into losers
- **Hope:** Holds losers expecting recovery
- **Revenge:** Over-trades after loss to "make it back"

---

## LAYER 1: ORDER FLOW
*The actual mechanics of buying and selling*

### Who's Trading Small Caps:

| Player | Size | Speed | Edge |
|--------|------|-------|------|
| **Retail** | Small ($100-$50K) | Slow | None (we ARE retail) |
| **Day Traders** | Small-Medium | Fast | Speed, patterns |
| **Algo/HFT** | Variable | Milliseconds | Speed, data |
| **Market Makers** | Large | Always there | Spread capture |
| **Hedge Funds** | Large | Variable | Research, capital |
| **Institutions** | Massive | Slow (weeks) | Research, staying power |

### Small Cap Reality:
- Institutions mostly AVOID small caps (too illiquid)
- That means small caps = **retail vs retail**
- Easier to move price with less money
- But also: less liquidity = harder to exit

### Volume Tells the Story:
- **High volume + up:** Strong buying, likely to continue
- **High volume + down:** Strong selling, likely to continue
- **Low volume + up:** Weak rally, may fade
- **Low volume + down:** Weak selling, may bounce
- **Volume spike + flat:** Absorption, someone accumulating

### The Dark Pool Factor:
- ~40% of trading happens "off exchange" in dark pools
- You can't see it until after it happens
- Large institutions use dark pools to hide activity
- Unusual dark pool activity can precede big moves

---

## THE SYNTHESIS: WHY STOCKS ACTUALLY MOVE

### Framework for Any Stock Move:

```
1. WHAT is the macro environment? (Risk on/off?)
2. WHAT sector/theme is hot? (Is this stock in it?)
3. WHAT is the company's fundamental story? (Thesis?)
4. WHAT catalyst triggered THIS move? (News? Filing? Social?)
5. WHO knew first? (Where in cascade are we?)
6. WHAT psychology is at play? (FOMO? Fear? Momentum?)
7. WHO is buying/selling? (Retail? Institutions? Shorts?)
```

### The "No Apparent Reason" Moves:
When a stock moves big with no news, check:
1. **Sector sympathy:** Did a similar stock just move?
2. **Options activity:** Is there unusual call buying?
3. **Short interest:** Is there a squeeze happening?
4. **Social media:** Is it trending on Reddit/Twitter?
5. **Dark pools:** Was there unusual off-exchange volume?
6. **Upcoming catalyst:** Is there earnings/FDA date coming?

---

## WHAT WE DON'T KNOW (Gaps to Fill)

### Questions Still Unanswered:
1. What makes a stock CONTINUE vs FADE after initial move?
2. Which news sources do retail traders actually read?
3. How long does the FOMO cycle typically last?
4. What's the exact timing from SEC filing to price move?
5. How do sector correlations change over time?
6. What separates stocks with "continuation DNA" from others?
7. How do market makers position ahead of big moves?
8. What dark pool signals precede big moves?

### Data We Need to Collect:
- [ ] Time from catalyst to peak price
- [ ] Volume profile during moves (when does it peak?)
- [ ] Social media mention correlation to price
- [ ] Which SEC filings actually move price?
- [ ] Sector correlation changes month-to-month
- [ ] Options activity patterns before big moves

---

## THE WOLF PACK APPROACH

### Given This Reality, Our Strategy:

1. **Macro Awareness:** Know if we're in risk-on or risk-off environment
2. **Sector Focus:** Stay in hot sectors, avoid dead ones
3. **Thesis Understanding:** Know WHY each stock could moon or die
4. **Catalyst Hunting:** Find stocks with upcoming catalysts
5. **Information Edge:** Monitor SEC filings, not broker notifications
6. **Psychology Management:** Don't be the FOMO buyer at step 4
7. **Exit Discipline:** Sell into strength, don't hold and hope

### The Timing Challenge:
We can't PREDICT moves. We can:
- See them STARTING (momentum detection)
- Understand WHY they're happening (catalyst identification)
- Know WHEN to exit (psychology + volume)

---

---

## THE CONTINUATION VS FADE MYSTERY (CRITICAL)

### The U-Shaped Pattern

Research reveals a **U-shaped autocorrelation** in stock returns:

| Time Horizon | Behavior | What It Means |
|--------------|----------|---------------|
| **1 week - 1 month** | REVERSAL | Yesterday's winners fade, losers bounce |
| **3 - 12 months** | MOMENTUM | Winners keep winning, losers keep losing |
| **3 - 5 years** | REVERSAL | Past winners underperform, past losers catch up |

**OUR TIMEFRAME (overnight to 20 days) = THE TRANSITION ZONE**

This is why it's so hard to predict! We're trading right at the crossover point.

### What Predicts Continuation vs Fade:

#### CONTINUE (Momentum Wins):
| Condition | Why |
|-----------|-----|
| **Near 52-week high** | Investors anchor to recent highs, less resistance |
| **High turnover** | Active trading = trend followers participating |
| **Clear catalyst** | Fundamental reason for move = sustainable |
| **Institutional participation** | Smart money confirms the move |
| **Sector momentum** | Rising tide lifts all boats |

#### FADE (Mean Reversion Wins):
| Condition | Why |
|-----------|-----|
| **Far from 52-week high** | Investors see "discount" = buying pressure |
| **Low turnover** | Thin trading = easier to reverse |
| **No clear catalyst** | Move was noise, not signal |
| **Peak social media sentiment** | FOMO maxed out = no more buyers |
| **Already extended (prior 60d >20%)** | Rubber band stretched too far |

### THE SOCIAL MEDIA DEATH SIGNAL

Research confirms:
> **"Peak social media sentiment is associated with the END of momentum and a return to mean reversion."**

Translation: When StockTwits/Twitter/Reddit is SCREAMING about a stock, you're at the top, not the bottom.

### The Practical Application:

| Signal | Action |
|--------|--------|
| Stock pops + NOT extended + Day 2 confirms | MOMENTUM - ride it |
| Stock pops + already extended + social media exploding | FADE - don't chase |
| Stock dumps + NOT discussed on social + sector strong | REVERSAL - buy the dip |
| Stock dumps + high social volume + sector weak | MOMENTUM (down) - don't catch knife |

### The 52-Week High Secret

Research shows:
- **Near 52-week high + high turnover = SHORT-TERM MOMENTUM**
- **Far from 52-week high + low turnover = SHORT-TERM REVERSAL**

This gives us a filter we haven't been using!

---

## WHAT WE STILL DON'T KNOW

### Individual Stock "Continuation DNA"
We discovered CFLT has 88% continuation, RDW has 0%.

What makes THEM different?
- Different investor base?
- Different sector dynamics?
- Different fundamental story?
- Different options activity?
- Different social media following?

**THIS IS THE EDGE WE'RE HUNTING.**

---

## CLOSING THOUGHT

> "The market is a voting machine in the short term, a weighing machine in the long term."
> - Benjamin Graham

For small caps, the voting is done by retail traders, influenced by:
- Social media sentiment
- FOMO psychology
- Theme/story momentum
- Occasional fundamental reality

Our job: Understand the voting patterns, ride the waves, exit before the crash.

---

*"We have to understand the whole thing, not just one reason."*
*- MONEY*

🐺 LLHR
