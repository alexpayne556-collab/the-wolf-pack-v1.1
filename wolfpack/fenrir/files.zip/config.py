# 🐺 FENRIR V2 - CONFIG
# Personal AI Trading Companion Configuration

import os
from dotenv import load_dotenv

load_dotenv()

# =============================================================================
# API KEYS
# =============================================================================
FINNHUB_API_KEY = os.getenv("FINNHUB_API_KEY", "")

# =============================================================================
# YOUR HOLDINGS (Update as you trade)
# =============================================================================
HOLDINGS = {
    'KTOS': {'shares': 2.72, 'avg_cost': 60.00, 'account': 'robinhood', 'thesis': 'Defense/Drones'},
    'IBRX': {'shares': 20, 'avg_cost': 4.00, 'account': 'robinhood', 'thesis': 'Biotech - cancer drug revenue'},
    'MU': {'shares': 1.27, 'avg_cost': 333.01, 'account': 'both', 'thesis': 'AI memory'},
    'UUUU': {'shares': 3, 'avg_cost': 20.00, 'account': 'robinhood', 'thesis': 'Nuclear'},
    'BBAI': {'shares': 7.686, 'avg_cost': 6.50, 'account': 'fidelity', 'thesis': 'AI/Defense'},
    'UEC': {'shares': 2, 'avg_cost': 17.29, 'account': 'fidelity', 'thesis': 'Nuclear'},
}

# =============================================================================
# WATCHLIST BY SECTOR
# =============================================================================
WATCHLIST = {
    'nuclear': ['UEC', 'UUUU', 'DNN', 'URG', 'SMR', 'LEU'],
    'defense': ['KTOS', 'RCAT', 'UMAC', 'ONDS', 'JOBY', 'ACHR', 'BBAI', 'LMT', 'RTX', 'NOC'],
    'ai_semis': ['MU', 'NVDA', 'AMD', 'INTC', 'AVGO', 'SMCI', 'PLTR', 'AEHR', 'ICHR'],
    'space': ['RKLB', 'LUNR', 'RDW', 'BKSY', 'ASTS'],
    'biotech': ['IBRX', 'DVAX', 'BEAM', 'CRSP', 'NTLA', 'RGC', 'GPCR'],
    'silver': ['SLV', 'HL', 'AG', 'EXK', 'CDE', 'WPM'],
    'crypto': ['COIN', 'HOOD', 'MSTR', 'BTDR', 'MARA', 'RIOT'],
    'energy': ['BE', 'FSLR', 'ENPH'],
}

# Flat list for scanning
ALL_WATCHLIST = []
for sector, tickers in WATCHLIST.items():
    ALL_WATCHLIST.extend(tickers)
ALL_WATCHLIST = list(set(ALL_WATCHLIST))

# =============================================================================
# ALERT THRESHOLDS
# =============================================================================
MOVE_THRESHOLD_PCT = 5.0      # Alert on 5%+ moves
VOLUME_THRESHOLD_RATIO = 2.0  # Alert on 2x average volume
SCAN_INTERVAL_MINUTES = 15    # How often to scan during market hours

# =============================================================================
# ACCOUNT INFO
# =============================================================================
ROBINHOOD_CASH = 191.74
FIDELITY_CASH = 87.64
TOTAL_CASH = ROBINHOOD_CASH + FIDELITY_CASH

# =============================================================================
# OLLAMA SETTINGS
# =============================================================================
OLLAMA_MODEL = "fenrir"
OLLAMA_URL = "http://localhost:11434/api/generate"

# =============================================================================
# DATABASE
# =============================================================================
DB_PATH = "fenrir_trades.db"
