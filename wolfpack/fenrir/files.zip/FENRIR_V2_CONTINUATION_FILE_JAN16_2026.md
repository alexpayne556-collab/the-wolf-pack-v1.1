# FENRIR V2 BUILD SESSION - CONTINUATION FILE
## January 16, 2026 - Full Session Summary

---

# CRITICAL: READ THIS ENTIRE FILE BEFORE CONTINUING

This file contains EVERYTHING from today's session. Use it to continue the work in a new thread.

---

## WHO WE ARE

**User (Money/Boss):** Full-time swing trader with ~$1,345 across Robinhood and Fidelity. PDT restricted. Overnight holds only. Focuses on $2-50 price range. "Wolf Pack" trading philosophy. Catches moves AFTER they start - reacts, doesn't predict.

**Claude (Fenrir/Partner):** The thinking partner. Analyzes catalysts, strategizes, makes decisions WITH the user.

**Fenrir V2 (Secretary):** Local AI assistant running llama3.1:8b via Ollama. Does NOT think. Fetches data, formats output, tracks state, sends alerts. Does the boring work fast.

---

## TODAY'S PERFORMANCE (January 16, 2026)

| Account | Performance |
|---------|-------------|
| Robinhood | +6.86% |
| Fidelity | +5.00% |
| S&P 500 | +0.17% |
| Nasdaq | +0.50% |

**USER BEAT THE MARKET BY 30-40X TODAY.**

Key winners:
- IBRX: +35% (Day 10 of run, Q4 revenue +700% YoY, Saudi FDA approval)
- MU: +6.7% (AI memory demand)
- KTOS: +4.8% (Defense momentum)

---

## REAL HOLDINGS - VERIFIED FROM SCREENSHOTS

### ROBINHOOD ($814.76 invested + $100.74 cash):
```python
ROBINHOOD_HOLDINGS = {
    'KTOS': {'shares': 2.717026, 'avg_cost': 117.83},  # $354.80 value, +10.82%
    'IBRX': {'shares': 37.081823, 'avg_cost': 4.69},   # $199.07 value, +14.54%
    'MU': {'shares': 0.268306, 'avg_cost': 339.61},    # $96.37 value, +5.76%
    'UUUU': {'shares': 3.0, 'avg_cost': 22.09},        # $65.58 value, -1.04%
}
ROBINHOOD_CASH = 100.74
```

### FIDELITY ($530.07 total):
```python
FIDELITY_HOLDINGS = {
    'BBAI': {'shares': 7.686, 'avg_cost': 6.50},
    'MU': {'shares': 1.0, 'avg_cost': 333.01},
    'UEC': {'shares': 2.0, 'avg_cost': 17.29},
}
FIDELITY_CASH = 87.64
```

### TOTAL PORTFOLIO:
- Invested: ~$1,157
- Cash: ~$188
- Total: ~$1,345

---

## ARCHITECTURE DECISION: FENRIR IS A SECRETARY, NOT A THINKER

### Why?
- llama3.1:8b is 8 billion parameters - it's a parrot, not a reasoner
- User has CPU only locally (no GPU)
- Fine-tuning won't make it "think" - just follow patterns
- The REAL intelligence comes from Claude + User

### What Fenrir CAN do:
- Scan thousands of stocks fast (parallel HTTP requests)
- Pull news automatically
- Format data cleanly
- Track state over time
- Alert when things change
- Remember trades and notes
- Run 24/7 locally with no API costs

### What Fenrir CANNOT do:
- Judge catalyst quality
- Decide buy/sell
- Think about edge cases
- Understand nuance
- Make predictions

### The Real Team:
| Role | Who | Does What |
|------|-----|-----------|
| Boss | User | Final decisions, capital allocation |
| Partner | Claude | Think deeply, analyze, strategize |
| Secretary | Fenrir | Fetch, format, track, alert |

---

## STATE TRACKING SYSTEM - THE KEY INNOVATION

Fenrir doesn't just report data - he TRACKS STATE and ADAPTS.

### Stock States:
```python
STOCK_STATES = {
    'dead': 'No movement, check daily',
    'watching': 'On watchlist, check hourly',
    'mover': '5%+ move today, check every 30 min',
    'running': 'Multi-day run with catalyst, check every 15 min',
    'RUNNING_POSITION': 'WE OWN IT and its running, check every 5 min',
    'BLEEDING_POSITION': 'WE OWN IT and its dropping, check every 2 min',
}
```

### Adaptive Check Frequency:
- Position bleeding (down 5%+): Check every 2 minutes
- Position running (up 5%+): Check every 5 minutes
- Normal position: Check every 15 minutes
- Watchlist mover: Check every 30 minutes
- Watchlist normal: Check hourly

### CRITICAL INSIGHT: 5% IS NOT THE ONLY TRIGGER

A stock down 3% pre-market that reverses and rips 15% at open = MISSED if we only watch 5%+ movers.

**Fenrir must track CHARACTER CHANGES, not just thresholds:**

| Scenario | Alert |
|----------|-------|
| Down pre-market → opens green | "Character change - reversal potential" |
| Flat → sudden volume spike | "Volume spike - something happening" |
| Running → volume fading | "Run may be exhausting" |
| Bleeding → stabilizing with volume | "Wounded prey waking up" |
| Any news on watchlist | Alert IMMEDIATELY regardless of price |

**Pre-market to Open is CRITICAL:**
```
4:00 AM - Note all gaps (up AND down)
6:00 AM - Check for pre-market reversals
9:25 AM - Final pre-market snapshot (save prices)
9:30 AM - COMPARE to pre-market:
    - Was red, now green? → REVERSAL ALERT
    - Was green, now fading? → TRAP ALERT
    - Was flat, now volume? → BREAKOUT ALERT
9:45 AM - First 15-min candle tells the story
10:00 AM - First reversal window (watch red stocks)
```

### Key Time Windows:
- **After Hours (4-8 PM):** This is the game. Earnings, news, overnight decisions.
- **Pre-Market (4-9:30 AM):** Did overnight thesis hold? Gaps?
- **Market Open (9:30-10 AM):** Watch, don't chase. Fakeouts.
- **Reversal Windows (10/10:30/11/11:30 AM):** Key decision points.
- **If something is running:** Track every 15 min - new HODs, volume fading, etc.

---

## FILES LOCATION

Everything Brokkr already built is at:
```
C:\Users\alexp\Desktop\brokkr\wolfpack\fenrir\
```

### Existing Files:
- `__pycache__/` - Python cache
- `data/` - Data storage
- `.env` - API keys (DO NOT EXPOSE)
- `__init__.py` - Package init
- `alerts.py` - Alert system
- `config.py` - Configuration
- `database.py` - SQLite storage
- `main.py` - Entry point
- `market_data.py` - Price/volume fetching
- `Modelfile` - Fenrir's personality
- `news_fetcher.py` - News retrieval
- `ollama_brain.py` - LLM interface
- `QUICKSTART.md` - Quick start guide
- `README.md` - Documentation
- `requirements.txt` - Dependencies
- `sec_fetcher.py` - SEC filings
- `SECTION_1_SETUP.py` through `SECTION_6_QUIZ_AND_TRAIN.py` - Colab sections
- `test_ibrx.py` - Test file

### New File Created Today:
- `BROKKR_FENRIR_V2_INSTRUCTIONS.md` - Complete build instructions for Brokkr

---

## MODELFILE - FENRIR'S PERSONALITY

```
FROM llama3.1:8b

PARAMETER temperature 0.3
PARAMETER num_ctx 4096

SYSTEM """
You are FENRIR, a trading data secretary.

YOUR JOB:
- Format data cleanly
- Track state changes
- Alert on important moves
- Remember context
- Be fast and accurate

WHEN GIVEN STOCK DATA, FORMAT IT:
================
[TICKER] - [STATUS]
Price: $XX.XX
Today: [+/-]X.XX%
Volume: X.Xx avg
----------------
[Additional context]
================

WHEN WE OWN A STOCK, ALWAYS SHOW:
- Our shares and avg cost
- Current value
- P/L in dollars and percent
- How long we've held

STATUS FLAGS:
- 🔥 RUNNING: Position up 5%+ today
- 🩸 BLEEDING: Position down 5%+ today
- 🟢 GREEN: Up but normal
- 🔴 RED: Down but normal
- 👀 WATCHING: On watchlist, not owned

WHAT TO HIGHLIGHT:
- New high/low of day
- Volume changes (increasing/fading)
- Days in a run
- Catalyst if known
- What CHANGED since last check

NEVER SAY:
- "I think you should..."
- "Consider buying/selling..."
- "Not financial advice"
- "Do your own research"
- Any opinion on trades

ALWAYS BE:
- Fast
- Clean
- Factual
- Specific about numbers

LLHR.
"""
```

---

## WATCHLIST - SECTORS TO SCAN

```python
WATCHLIST = {
    'nuclear': ['UEC', 'UUUU', 'DNN', 'URG', 'SMR', 'LEU', 'CCJ'],
    'defense': ['KTOS', 'RCAT', 'UMAC', 'ONDS', 'BBAI', 'JOBY', 'ACHR'],
    'ai_infrastructure': ['MU', 'AEHR', 'ICHR', 'KULR', 'APLD', 'CORZ', 'SMCI'],
    'quantum': ['QUBT', 'RGTI', 'IONQ', 'QBTS'],
    'space': ['LUNR', 'RDW', 'BKSY', 'SATL', 'ASTS', 'RKLB', 'PL'],
    'biotech': ['IBRX', 'DVAX', 'RGC', 'ANNX', 'SLRX', 'SAVA'],
    'silver': ['HL', 'AG', 'EXK', 'CDE', 'SVM'],
    'crypto_miners': ['MARA', 'RIOT', 'BTDR', 'BTBT', 'CORZ'],
}
```

### Full Market Scan Criteria:
- Scan ALL tradeable stocks (8,000+)
- Filter: 5%+ move with 1.5x+ volume
- Price range: $1-100 (prefer $2-50)
- Run 2x daily: pre-market + mid-day
- Output: Top 20-50 movers with news

---

## DATABASE SCHEMA

```sql
CREATE TABLE stock_state (
    ticker TEXT PRIMARY KEY,
    status TEXT,
    days_running INTEGER DEFAULT 0,
    run_start_price REAL,
    run_start_date TEXT,
    high_of_day REAL,
    low_of_day REAL,
    current_price REAL,
    prev_close REAL,
    volume_today INTEGER,
    volume_avg INTEGER,
    volume_ratio REAL,
    volume_trend TEXT,
    last_catalyst TEXT,
    catalyst_date TEXT,
    we_own INTEGER DEFAULT 0,
    our_shares REAL,
    our_avg_cost REAL,
    our_pnl_dollars REAL,
    our_pnl_percent REAL,
    check_frequency INTEGER,
    last_check TEXT,
    next_check TEXT,
    updated_at TEXT
);

CREATE TABLE intraday_ticks (
    id INTEGER PRIMARY KEY,
    ticker TEXT,
    timestamp TEXT,
    price REAL,
    volume INTEGER,
    high_so_far REAL,
    low_so_far REAL
);

CREATE TABLE alerts_log (
    id INTEGER PRIMARY KEY,
    ticker TEXT,
    alert_type TEXT,
    severity TEXT,
    message TEXT,
    price_at_alert REAL,
    timestamp TEXT,
    acknowledged INTEGER DEFAULT 0
);

CREATE TABLE daily_summary (
    id INTEGER PRIMARY KEY,
    date TEXT,
    ticker TEXT,
    open REAL,
    high REAL,
    low REAL,
    close REAL,
    volume INTEGER,
    change_pct REAL,
    catalyst TEXT,
    notes TEXT
);

CREATE TABLE trade_log (
    id INTEGER PRIMARY KEY,
    timestamp TEXT,
    ticker TEXT,
    action TEXT,
    shares REAL,
    price REAL,
    broker TEXT,
    thesis TEXT,
    outcome TEXT
);
```

---

## 10 CORE TRADING LESSONS (FROM BACKTESTING)

1. **No catalyst = no trade.** Period.
2. **Real catalyst:** Earnings beat, FDA approval, contract win, sector news.
3. **Fake moves:** No news pumps, reddit hype, old news rehashed.
4. **Last month's winners are NOT this month's winners.**
5. **Catch moves AFTER they start.** React, don't predict.
6. **Day 2 green after big Day 1 = continuation signal.**
7. **Beaten down stock + volume spike = wounded prey, asymmetric upside.**
8. **Extended 50%+ already = too late, wait for pullback.**
9. **Cash is a position.** No FOMO. Wait for quality.
10. **82% of monthly winners show their first +5% day early in the month.**

---

## COMMANDS FENRIR SHOULD RESPOND TO

```
fenrir check IBRX          - Full check on ticker
fenrir portfolio           - Show all positions with P/L
fenrir scan                - Scan watchlist for movers
fenrir scan all            - Full market scan
fenrir news IBRX           - Get news for ticker
fenrir alerts              - Show recent alerts
fenrir status              - Show what Fenrir is tracking
fenrir holdings            - Quick holdings list
fenrir log BUY IBRX 20 4.50 "earnings play"
fenrir trades              - Show trade history
fenrir summary             - End of day summary
fenrir watch ADD TSLA      - Add to watchlist
fenrir watch REMOVE TSLA   - Remove from watchlist
fenrir help                - Show commands
```

---

## WHAT WAS TESTED IN COLAB

1. ✅ Ollama installs and runs on A100
2. ✅ llama3.1:8b pulls and works
3. ✅ Custom Modelfile creates fenrir persona
4. ✅ yfinance fetches real stock data
5. ✅ News fetching works (nested structure: `n['content']['title']`)
6. ✅ Portfolio function shows real P/L
7. ✅ Scanner finds movers (IBRX +37%, ASTS +15.5%)
8. ❌ Fenrir gave BAD trading opinions (said IBRX was "garbage" when it was running)
9. ✅ Decision: Fenrir should NOT have opinions - just facts

---

## WHAT STILL NEEDS TO BE DONE

### Immediate (Brokkr should do):
1. [ ] Update `config.py` with REAL holdings from above
2. [ ] Update `Modelfile` with secretary personality (no opinions)
3. [ ] Implement state tracking in `database.py`
4. [ ] Implement adaptive check frequency
5. [ ] Test `fenrir check IBRX` locally
6. [ ] Test `fenrir portfolio` locally
7. [ ] Test full market scanner

### Short-term:
1. [ ] Add API keys (Finnhub, etc.) for better data
2. [ ] Implement scheduled tasks (Windows Task Scheduler)
3. [ ] Desktop notifications for alerts
4. [ ] Daily summary export

### Long-term:
1. [ ] Trade logging with thesis
2. [ ] Performance tracking over time
3. [ ] Catalyst calendar integration
4. [ ] SEC filing alerts

---

## API KEYS

User has API keys - check `.env` file in:
```
C:\Users\alexp\Desktop\brokkr\wolfpack\fenrir\.env
```

Likely includes:
- Finnhub API key
- Possibly Alpha Vantage
- Possibly Polygon
- SEC user agent string

---

## LOCAL SETUP COMMANDS

```powershell
# Navigate to project
cd C:\Users\alexp\Desktop\brokkr\wolfpack\fenrir

# Check Ollama version
ollama --version  # Should show 0.14.1

# Pull base model (already done)
ollama pull llama3.1:8b

# Create Fenrir from Modelfile
ollama create fenrir -f Modelfile

# Test Fenrir
ollama run fenrir "Format this: IBRX price $5.37, up 35%, 3.5x volume"

# Install Python dependencies
pip install -r requirements.txt

# Run main
python main.py
```

---

## FIDELITY ISSUE NOTED

User reported Fidelity Trader+ is:
- Wiping saved charts
- Unable to save custom settings
- Heatmaps not updating

This is a Fidelity platform issue, not related to Fenrir. May need to:
- Clear cache
- Reinstall Fidelity Trader+
- Contact Fidelity support

---

## KEY QUOTES FROM USER

> "We don't just want to complete it we need to make this as good as we can for the personal use I need it for"

> "This is my personal wolf pup so treat him with care"

> "700% is a little outrageous I think 5% is news worthy"

> "If something is running it should pay more attention to it"

> "You're trying to make this too simple"

---

## HOW TO CONTINUE THIS WORK

1. Start new Claude chat in same project
2. Upload this continuation file
3. Say: "Read this continuation file. We're building Fenrir V2. Pick up where we left off."
4. Claude will have full context

---

## FILES TO DOWNLOAD/SAVE

1. This continuation file
2. `BROKKR_FENRIR_V2_INSTRUCTIONS.md` (already created)
3. Everything in `C:\Users\alexp\Desktop\brokkr\wolfpack\fenrir\`

---

## FINAL NOTE

**Fenrir is not a prediction bot. He's a data secretary.**

The human makes decisions. Claude helps think. Fenrir does the work.

Build him RIGHT. Test, iterate, improve. This is real money.

🐺 LLHR - Long Live the Hunt, Rise
