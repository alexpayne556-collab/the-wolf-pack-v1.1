# 🐺 WOLF PACK PORTFOLIO FRAMEWORK
## Capital Allocation & Quality Holdings Strategy
### Created: January 15, 2026

---

## THE PHILOSOPHY

> "We're not chasing movers. We're finding QUALITY HORSES and RIDING them through the waves."

**NOT:** Buy Monday → Sell Friday → Repeat → Stress

**THIS:** Find Quality → Get Good Entry → Hold Through Dips → Catch the Waves → Compound

---

## CAPITAL ALLOCATION (~$1,290 Total)

| Bucket | Amount | Purpose | Style |
|--------|--------|---------|-------|
| **CORE HOLDINGS** | ~$950 | Quality names you RIDE | Hold weeks/months |
| **DIP RESERVE** | ~$200 | New position when quality pulls back | Patient entry |
| **SCREAMER FUND** | ~$100 | 3 PDTs/week, momentum plays | Quick in/out |
| **CASH BUFFER** | ~$40 | Never go to zero | Emergency |

### Rules:
1. **CORE** = Companies that DESERVE to grow (real business, real revenue, real thesis)
2. **DIP RESERVE** = Only deploy on QUALITY names at good prices, not random dips
3. **SCREAMER FUND** = Accept this is gambling, use for learning and fun
4. **NEVER** deplete cash buffer completely

---

## THE THREE-TIER WATCHLIST SYSTEM

```
┌─────────────────────────────────────────────────────────────────┐
│  TIER 1: CORE HOLDINGS                                          │
│  Currently IN these - RIDING the waves                          │
│  Maximum: 6-8 positions                                         │
│  Criteria: Researched intensely, quality thesis                 │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│  TIER 2: BENCH                                                  │
│  Researched, ready to buy on pullback                           │
│  Maximum: 10-15 names                                           │
│  Criteria: Know the thesis, waiting for entry                   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│  TIER 3: SCOUTS                                                 │
│  Watching, researching, not ready yet                           │
│  Unlimited                                                      │
│  Criteria: Interesting, needs more research                     │
└─────────────────────────────────────────────────────────────────┘
```

---

## CURRENT CORE HOLDINGS ANALYSIS

### 1. MU (Micron Technology) - $341.28 (1 share)
**VERDICT: ✅ QUALITY CORE HOLD - RIDE IT**

| Metric | Status |
|--------|--------|
| **Sector** | AI/Memory (HOT) |
| **Revenue Growth** | 57% YoY (Q1 FY26) |
| **Thesis** | AI memory supercycle, HBM demand |
| **Profitability** | EPS $4.78, margins expanding |
| **Moat** | Core NVIDIA HBM supplier |
| **Analyst Rating** | Strong Buy, targets $330-$500 |

**Why HOLD:**
- Entire 2026 HBM supply SOLD OUT
- Revenue expected to nearly DOUBLE in FY26 (~$74B)
- Core supplier to NVIDIA Blackwell GPUs
- Trading at 9x forward P/E (cheap for growth)
- "AI Memory Supercycle" - structural demand, not hype

**Risks:**
- Cyclical industry (but supply constrained now)
- Geopolitical (China/Taiwan)
- If AI spending slows

**Action:** HOLD. Add on any 10%+ pullback.

---

### 2. KTOS (Kratos Defense) - $62.81 (2 shares = $125.62)
**VERDICT: ✅ QUALITY CORE HOLD - RIDE IT**

| Metric | Status |
|--------|--------|
| **Sector** | Defense/Drones (HOT) |
| **Revenue Growth** | 26% YoY, 15-20% guided 2026 |
| **Thesis** | Drone warfare future, Valkyrie |
| **Profitability** | Improving, margins expanding |
| **Moat** | First-to-market affordable drones |
| **Analyst Rating** | Strong Buy, 13/18 analysts |

**Why HOLD:**
- Valkyrie drone = Marine Corps program of record
- $1.5 TRILLION defense budget proposed for 2027
- $1.41B backlog, 37% converts in 2026
- Hypersonic, jet engines, multiple growth drivers
- +196% in 2025, but still executing

**Risks:**
- Expensive at P/E 900 (priced for growth)
- Government contract timing
- Competition from larger primes

**Action:** HOLD. Core defense thesis intact.

---

### 3. UEC (Uranium Energy Corp) - $8.84 (2 shares = $17.67)
**VERDICT: ⚠️ QUALITY THESIS, SPECULATIVE - HOLD SMALL**

| Metric | Status |
|--------|--------|
| **Sector** | Nuclear/Uranium (HOT) |
| **Revenue Growth** | Ramping production 2026 |
| **Thesis** | Nuclear renaissance, AI power demand |
| **Profitability** | Still losing money, pre-revenue |
| **Moat** | Largest US licensed capacity |
| **Analyst Rating** | Buy, limited coverage |

**Why HOLD:**
- Nuclear power renaissance is REAL
- AI data centers need baseload power
- Russian uranium ban Dec 2027 = US supply critical
- Transitioned from developer to producer 2025
- 12.1M lb licensed capacity (largest US)

**Risks:**
- Pre-revenue, still ramping
- Uranium price volatility
- Long timeline to profitability

**Action:** HOLD small position. Thesis is multi-year.

---

### 4. NTLA (Intellia Therapeutics) - $12.14 (20 shares = $242.80)
**VERDICT: ⚠️ HIGH RISK/HIGH REWARD - EVALUATE**

| Metric | Status |
|--------|--------|
| **Sector** | Biotech/Gene Editing (WEAK) |
| **Revenue** | Collaboration only, no product sales |
| **Thesis** | CRISPR gene editing cures |
| **Profitability** | Burning cash, -$4/share loss |
| **Moat** | Strong patent portfolio |
| **Analyst Rating** | Hold/Buy, very speculative |

**Why HOLD (if bullish):**
- Phase 3 HAELO data mid-2026 (lonvo-z for HAE)
- Potential first-mover in vivo gene editing
- $670M cash runway into mid-2027
- Big upside if trials succeed ($5B+ peak sales potential)
- ARK Invest buying shares

**CONCERNS:**
- FDA clinical hold on nex-z (main drug)
- Biotech sector weak overall
- Binary outcomes - could go to zero
- No revenue, just burning cash

**Action:** EVALUATE. This is your riskiest position. 
- If you want to RIDE: Hold, accept binary risk
- If you want to REDUCE RISK: Trim to 10 shares, redeploy $120

---

### 5. SLV (iShares Silver Trust) - $84.21 (1 share)
**VERDICT: ✅ HEDGE POSITION - HOLD**

| Metric | Status |
|--------|--------|
| **Type** | Commodity ETF |
| **Thesis** | Inflation hedge, industrial demand |
| **Correlation** | Low to equities |

**Why HOLD:**
- Diversification from tech/growth
- Industrial demand (solar, electronics)
- Inflation hedge

**Action:** HOLD as portfolio hedge.

---

### 6. SRTA (Strata Critical Medical) - $5.82 (10 shares = $58.20)
**VERDICT: ⚠️ NEEDS RESEARCH - NEW POSITION**

| Metric | Status |
|--------|--------|
| **Sector** | Healthcare/Medical Transport |
| **Revenue Growth** | 37% YoY Q3 |
| **Thesis** | Organ transport, time-critical medical |
| **Profitability** | EBITDA positive, margins improving |
| **Moat** | Niche market leader |

**What It Is:**
- Formerly Blade Air Mobility
- Transports human organs for transplant
- Air and ground medical logistics
- 2026 guidance: $255-270M revenue, $28-32M EBITDA

**Why It's Interesting:**
- Growing revenue 30%+
- Niche healthcare play
- Not correlated to tech
- Small cap with growth

**Risks:**
- Small position, limited liquidity
- Healthcare regulations
- Competition

**Action:** RESEARCH MORE. Interesting diversification play.

---

## PORTFOLIO QUALITY SCORECARD

| Stock | Quality | Growing | Sector Hot | Hold? |
|-------|---------|---------|------------|-------|
| MU | ✅ Dominant | ✅ 57% | ✅ AI/Semis | **CORE** |
| KTOS | ✅ First-mover | ✅ 26% | ✅ Defense | **CORE** |
| UEC | ✅ Largest US | ⚠️ Ramping | ✅ Nuclear | **HOLD SMALL** |
| NTLA | ⚠️ Pre-revenue | ❌ Burning | 🔴 Biotech | **EVALUATE** |
| SLV | ✅ ETF | N/A | ⚠️ Commodities | **HEDGE** |
| SRTA | ⚠️ Small cap | ✅ 37% | ⚠️ Healthcare | **RESEARCH** |

---

## TIER 2: BENCH (Ready to Buy on Dips)

Names to research and add to bench for DIP RESERVE deployment:

### Defense Sector
- **AVAV** (AeroVironment) - Switchblade drones
- **RCAT** (Red Cat Holdings) - Small drone play
- **PLTR** (Palantir) - Defense AI, expensive but growing

### Nuclear
- **LEU** (Centrus Energy) - HALEU enrichment
- **CCJ** (Cameco) - Largest uranium miner
- **OKLO** (Oklo) - SMR nuclear

### Space
- **RKLB** (Rocket Lab) - Launch + spacecraft
- **LUNR** (Intuitive Machines) - Lunar landers

### Semis/AI
- **LRCX** (Lam Research) - Memory equipment
- **AMAT** (Applied Materials) - Chip equipment
- **AMD** - AI chips, memory

### Quantum (Very Speculative)
- **IONQ** - Trapped ion quantum
- **RGTI** - Superconducting quantum

---

## TIER 3: SCOUTS (Watching)

Names in our Wolfpack 100 to monitor:
- BEAM, EDIT, CRSP (gene editing peers)
- MARA, RIOT (crypto miners)
- PLUG, BE (hydrogen/fuel cells)
- RIVN, LCID (EVs - beaten down)

---

## THE QUALITY FILTER

Before adding ANY stock to CORE, answer:

| Question | Must Be |
|----------|---------|
| Is this company actually DOING something? | Real product/service |
| Are they GROWING revenue? | Yes, measurably |
| Do they have a MOAT? | Something hard to copy |
| Is the sector GROWING? | Rising tide |
| Is management BUYING? | Insider confidence |
| Do they have RUNWAY? | 12+ months cash |
| Can I HOLD through a 20% dip? | Must believe thesis |

---

## THE RIDE-THROUGH RULES

**When to HOLD through dips:**
- Thesis unchanged
- Sector still strong
- No fundamental bad news
- Just market noise

**When to SELL:**
- Thesis BREAKS (not just price drop)
- Sector rotation OUT
- Fundamental bad news (missed earnings, lost contract, failed trial)
- Better opportunity with limited capital

---

## SCREAMER FUND RULES (3 PDTs/week)

For the $100 fun money:

1. **Only play momentum** - stock already moving
2. **Quick in/out** - same day or next day
3. **Small position** - max $50 per trade
4. **Accept losses** - this is learning money
5. **Track results** - learn what works

---

## WEEKLY REVIEW CHECKLIST

Every Sunday:
- [ ] Review each CORE position - thesis intact?
- [ ] Check sector rotation - where is money flowing?
- [ ] Update BENCH with any new research
- [ ] Review SCREAMER trades - what worked/failed?
- [ ] Rebalance if needed

---

## THE BIG PICTURE

```
┌─────────────────────────────────────────────────────────────────┐
│                    WHERE HERDS ROAM (2026)                      │
├─────────────────────────────────────────────────────────────────┤
│  HOT SECTORS:                                                   │
│  • AI Infrastructure (memory, power, cooling)                   │
│  • Defense (drones, hypersonics, space)                         │
│  • Nuclear (power demand, clean energy)                         │
│                                                                 │
│  WARMING UP:                                                    │
│  • Quantum (early, speculative)                                 │
│  • Space (contracts flowing)                                    │
│                                                                 │
│  COLD/ROTATING OUT:                                             │
│  • Biotech (except catalysts)                                   │
│  • Clean energy (PLUG, FCEL struggling)                         │
│  • EVs (oversupplied)                                          │
└─────────────────────────────────────────────────────────────────┘
```

---

## CURRENT PORTFOLIO SUMMARY

| Position | Value | % of Portfolio | Quality | Action |
|----------|-------|----------------|---------|--------|
| MU | $341 | 26% | ✅ Core | HOLD |
| KTOS | $126 | 10% | ✅ Core | HOLD |
| NTLA | $243 | 19% | ⚠️ Risk | EVALUATE |
| SLV | $84 | 7% | ✅ Hedge | HOLD |
| SRTA | $58 | 4% | ⚠️ Research | RESEARCH |
| UEC | $18 | 1% | ⚠️ Small | HOLD |
| Cash | ~$420 | 33% | - | RESERVE |

**Observation:** You have good cash reserve (~33%). Could deploy $200 to DIP RESERVE strategy.

---

## NEXT STEPS

1. **DECIDE on NTLA** - Keep or trim?
2. **RESEARCH SRTA more** - Understand the business
3. **BUILD BENCH** - Pick 5-10 names to watch for dips
4. **SET ALERTS** - Price alerts on bench stocks
5. **TRACK DAILY** - Quick sector/holdings check

---

🐺 **LLHR - Long Live the Hunt, Rise**

*This is not financial advice. This is a framework for systematic, research-driven position trading.*
