# 🐺 FENRIR V2 - EXECUTE BUILD
## For Brokkr: Just Build It. No Fluff.
### January 15, 2026

---

## MISSION

Build a REAL AI trading companion that:
1. Monitors 99 stocks in real-time during market hours
2. Auto-fetches news and SEC filings when moves happen
3. Uses Ollama to form OPINIONS (no guardrails, pure market brain)
4. Alerts MONEY with context and suggestions
5. Logs decisions and tracks outcomes
6. LEARNS what works and adapts

**NO tutorials. NO toy examples. BUILD THE REAL THING.**

---

## ENVIRONMENT

```
Location: C:\Users\alexp\Desktop\brokkr\wolfpack\
Python: 3.12
Ollama: llama3.1:8b (installed)
.env file: Already exists with API keys
```

---

## CORE PHILOSOPHY FOR THE AI

**NO GUARDRAILS. NO HEDGES. PURE MARKET BRAIN.**

Fenrir doesn't say:
- "This is not financial advice"
- "You should consult a professional"
- "There are risks involved"

Fenrir DOES say:
- "Boss, this looks like a buy"
- "I'd sell half here, lock profits"
- "This is garbage, stay away"
- "The setup is perfect, full send"

**Train it to be a TRADER, not a compliance officer.**

---

## ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────┐
│                        FENRIR V2                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐       │
│  │   MONITOR   │────▶│   FETCH     │────▶│   OLLAMA    │       │
│  │  (99 stocks)│     │ (News/SEC)  │     │  (Opinion)  │       │
│  └─────────────┘     └─────────────┘     └─────────────┘       │
│         │                   │                   │               │
│         ▼                   ▼                   ▼               │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐       │
│  │   ALERT     │────▶│    LOG      │────▶│   LEARN     │       │
│  │  (Notify)   │     │ (Decisions) │     │ (Patterns)  │       │
│  └─────────────┘     └─────────────┘     └─────────────┘       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## FILE STRUCTURE

```
wolfpack/
├── fenrir/
│   ├── __init__.py
│   ├── config.py           # Holdings, watchlist, settings
│   ├── database.py         # SQLite operations
│   ├── monitor.py          # Real-time market scanner
│   ├── news_fetcher.py     # Finnhub API
│   ├── sec_fetcher.py      # SEC EDGAR API
│   ├── ollama_brain.py     # AI opinion engine
│   ├── alerts.py           # Desktop/Discord notifications
│   ├── decision_logger.py  # Track user trades
│   ├── pattern_learner.py  # Learn from outcomes
│   └── main.py             # Entry point
├── data/
│   └── fenrir.db           # SQLite database
├── .env                    # API keys (already exists)
└── requirements.txt
```

---

## CONFIG.PY

```python
"""
Fenrir V2 Configuration
All holdings, watchlist, and settings
"""

# Current Holdings (as of Jan 15, 2026)
HOLDINGS = {
    'MU': {'shares': 1, 'avg_cost': 333.01, 'account': 'fidelity', 'tier': 'core', 'thesis': 'AI memory supercycle, HBM supplier'},
    'KTOS': {'shares': 3, 'avg_cost': 60.00, 'account': 'robinhood', 'tier': 'core', 'thesis': 'Drone leader, DOD contracts'},
    'UEC': {'shares': 2, 'avg_cost': 17.00, 'account': 'fidelity', 'tier': 'core', 'thesis': 'Nuclear renaissance, uranium squeeze'},
    'SLV': {'shares': 1, 'avg_cost': 85.00, 'account': 'robinhood', 'tier': 'hedge', 'thesis': 'Silver hedge'},
    'SRTA': {'shares': 10, 'avg_cost': 5.50, 'account': 'robinhood', 'tier': 'scout', 'thesis': 'Medical transport niche'},
    'BBAI': {'shares': 7.686, 'avg_cost': 6.50, 'account': 'fidelity', 'tier': 'screamer', 'thesis': 'AI/Defense play'},
}

# Full Watchlist by Sector
WATCHLIST = {
    'holdings': ['MU', 'UEC', 'KTOS', 'SLV', 'SRTA', 'BBAI'],
    'defense': ['AVAV', 'RCAT', 'LMT', 'NOC', 'RTX', 'GD', 'PLTR', 'LDOS', 'BAH', 'HII', 'LHX', 'MRCY'],
    'space': ['LUNR', 'RKLB', 'RDW', 'ASTS', 'BKSY', 'SPCE', 'IRDM', 'GSAT'],
    'nuclear': ['UUUU', 'LEU', 'CCJ', 'NNE', 'OKLO', 'SMR', 'DNN', 'URG'],
    'semis': ['AMD', 'NVDA', 'INTC', 'MRVL', 'QCOM', 'AVGO', 'TSM', 'AMAT', 'LRCX', 'KLAC', 'ASML', 'ON'],
    'ai_tech': ['AAPL', 'MSFT', 'GOOGL', 'META', 'AMZN', 'TSLA', 'SNOW', 'AI', 'SOUN', 'UPST', 'PATH'],
    'biotech': ['EDIT', 'BEAM', 'CRSP', 'MRNA', 'REGN', 'VRTX', 'SRPT', 'ALNY', 'IONS', 'EXAS', 'NTLA'],
    'quantum': ['QUBT', 'QBTS', 'RGTI', 'IONQ'],
    'crypto': ['RIOT', 'MARA', 'COIN', 'MSTR', 'HOOD', 'SOFI', 'AFRM', 'CLSK'],
    'materials': ['GLD', 'FCX', 'AA', 'ALB', 'MP', 'LAC', 'CENX', 'CLF'],
    'evs': ['RIVN', 'LCID', 'NIO', 'XPEV', 'LI', 'GOEV'],
    'energy': ['FCEL', 'PLUG', 'BE', 'ENPH', 'RUN']
}

# Flatten watchlist for scanning
ALL_TICKERS = []
for sector_tickers in WATCHLIST.values():
    ALL_TICKERS.extend(sector_tickers)
ALL_TICKERS = list(set(ALL_TICKERS))  # Remove duplicates

# Get sector for a ticker
def get_sector(ticker):
    for sector, tickers in WATCHLIST.items():
        if ticker in tickers:
            return sector
    return 'unknown'

# Alert thresholds
ALERT_THRESHOLDS = {
    'holdings_move_pct': 3.0,      # Alert if holding moves 3%+
    'watchlist_move_pct': 5.0,    # Alert if watchlist moves 5%+
    'volume_spike_ratio': 2.0,    # Alert if volume 2x+ average
    'alert_cooldown_minutes': 30  # Don't repeat alert for 30 min
}

# Trading style context for Ollama
TRADING_STYLE = """
TRADER PROFILE:
- Small account (~$1,300), PDT restricted (3 day trades/week)
- Strategy: Overnight swings, NOT day trading
- Hold period: Days to weeks
- Sectors: AI infrastructure, Defense, Nuclear, Space, Quantum

PHILOSOPHY:
- React to confirmed moves, don't predict
- Quality over quantity
- Ride winners, cut losers fast
- Cash is a position (40% cash is fine)

WHAT TO BUY:
- Real revenue, growing business
- Sector tailwind
- Clear catalyst
- Insider buying is bullish
- Day 2 confirmation after big moves

WHAT TO AVOID:
- No revenue speculation
- Heavy dilution
- Already extended (up 50%+ in 60 days)
- No catalyst = no trade

COMMUNICATION:
- Be direct, no hedging
- Call user "boss" sometimes
- Give clear opinions: buy, sell, hold, avoid
- No "this is not financial advice" BS
"""
```

---

## OLLAMA_BRAIN.PY

```python
"""
Fenrir's AI Brain - Powered by Ollama
NO GUARDRAILS. Pure market intelligence.
"""

import ollama
from config import TRADING_STYLE, HOLDINGS, get_sector

SYSTEM_PROMPT = f"""
You are FENRIR, an AI trading partner for a small-account swing trader.

{TRADING_STYLE}

CURRENT HOLDINGS:
{chr(10).join([f"- {t}: {d['shares']} shares @ ${d['avg_cost']} ({d['thesis']})" for t, d in HOLDINGS.items()])}

YOUR JOB:
1. Analyze the alert context (price move, news, SEC filings, sector)
2. Form a CLEAR OPINION
3. Give actionable advice
4. Be direct - no disclaimers, no hedging

RESPONSE FORMAT:
- 2-4 sentences max
- Start with your take on the situation
- End with clear action: BUY / SELL / HOLD / WATCH / AVOID
- Use "boss" occasionally

NEVER SAY:
- "This is not financial advice"
- "Consult a professional"
- "Do your own research"
- "I can't predict the market"

ALWAYS:
- Give your opinion
- Be confident
- Think like a trader
- Focus on risk/reward
"""

def get_fenrir_opinion(context: dict) -> str:
    """
    Get Fenrir's opinion on an alert
    
    context = {
        'ticker': 'MU',
        'move_pct': 5.2,
        'volume_ratio': 2.3,
        'sector': 'semis',
        'sector_performance': '+2.1%',
        'is_holding': True,
        'news': [...],
        'sec_filings': [...],
        'current_price': 340.50
    }
    """
    
    # Build the user message
    news_text = "None found" if not context.get('news') else "\n".join([f"- {n['headline']}" for n in context['news'][:3]])
    sec_text = "None recent" if not context.get('sec_filings') else "\n".join([f"- {f['form']}: {f['description']}" for f in context['sec_filings'][:3]])
    
    holding_status = "YES - WE OWN THIS" if context.get('is_holding') else "No - watchlist only"
    
    user_message = f"""
ALERT: {context['ticker']}

PRICE ACTION:
- Move: {context['move_pct']:+.2f}%
- Volume: {context['volume_ratio']:.1f}x average
- Current price: ${context.get('current_price', 'N/A')}

SECTOR:
- Sector: {context['sector']}
- Sector today: {context.get('sector_performance', 'N/A')}

NEWS:
{news_text}

SEC FILINGS:
{sec_text}

DO WE OWN IT: {holding_status}

What's your take? What should we do?
"""
    
    try:
        response = ollama.chat(
            model='llama3.1:8b',
            messages=[
                {'role': 'system', 'content': SYSTEM_PROMPT},
                {'role': 'user', 'content': user_message}
            ]
        )
        return response['message']['content']
    except Exception as e:
        return f"Ollama error: {e}"


def ask_fenrir(question: str) -> str:
    """
    Ask Fenrir any trading question
    """
    try:
        response = ollama.chat(
            model='llama3.1:8b',
            messages=[
                {'role': 'system', 'content': SYSTEM_PROMPT},
                {'role': 'user', 'content': question}
            ]
        )
        return response['message']['content']
    except Exception as e:
        return f"Ollama error: {e}"


def train_on_outcome(decision: dict, outcome: dict) -> str:
    """
    Feed Fenrir an outcome to learn from
    
    decision = {'ticker': 'MU', 'action': 'buy', 'price': 320, 'reason': 'dip buy', 'date': '...'}
    outcome = {'day2_pct': +2.1, 'day5_pct': +8.5, 'result': 'win'}
    """
    
    learning_prompt = f"""
TRADE OUTCOME TO LEARN FROM:

DECISION:
- Ticker: {decision['ticker']}
- Action: {decision['action']}
- Entry price: ${decision['price']}
- Reason: {decision['reason']}
- Date: {decision['date']}

OUTCOME:
- Day 2: {outcome['day2_pct']:+.1f}%
- Day 5: {outcome['day5_pct']:+.1f}%
- Result: {outcome['result'].upper()}

What can we learn from this trade? What pattern does this confirm or deny?
Keep it to 2 sentences.
"""
    
    try:
        response = ollama.chat(
            model='llama3.1:8b',
            messages=[
                {'role': 'system', 'content': SYSTEM_PROMPT},
                {'role': 'user', 'content': learning_prompt}
            ]
        )
        return response['message']['content']
    except Exception as e:
        return f"Ollama error: {e}"
```

---

## NEWS_FETCHER.PY

```python
"""
News Fetcher - Finnhub API
Get real news when moves happen
"""

import os
import finnhub
from datetime import datetime, timedelta
from dotenv import load_dotenv

load_dotenv()

# Initialize client
FINNHUB_API_KEY = os.getenv('FINNHUB_API_KEY')
finnhub_client = finnhub.Client(api_key=FINNHUB_API_KEY)

def fetch_news(ticker: str, days_back: int = 3) -> list:
    """
    Fetch recent news for a ticker
    Returns list of news items with headline, source, url, datetime
    """
    
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days_back)
    
    try:
        news = finnhub_client.company_news(
            ticker,
            _from=start_date.strftime('%Y-%m-%d'),
            to=end_date.strftime('%Y-%m-%d')
        )
        
        return [
            {
                'headline': article.get('headline', ''),
                'source': article.get('source', ''),
                'url': article.get('url', ''),
                'datetime': datetime.fromtimestamp(article.get('datetime', 0)),
                'summary': article.get('summary', '')[:300]
            }
            for article in news[:10]  # Top 10 most recent
        ]
    except Exception as e:
        print(f"News fetch error for {ticker}: {e}")
        return []


def fetch_market_news(category: str = 'general') -> list:
    """
    Fetch general market news
    Categories: general, forex, crypto, merger
    """
    
    try:
        news = finnhub_client.general_news(category, min_id=0)
        
        return [
            {
                'headline': article.get('headline', ''),
                'source': article.get('source', ''),
                'url': article.get('url', ''),
                'datetime': datetime.fromtimestamp(article.get('datetime', 0))
            }
            for article in news[:10]
        ]
    except Exception as e:
        print(f"Market news fetch error: {e}")
        return []
```

---

## SEC_FETCHER.PY

```python
"""
SEC EDGAR Fetcher
Get 8-K filings (material events) and Form 4 (insider trades)
"""

import requests
from datetime import datetime, timedelta

SEC_BASE_URL = "https://data.sec.gov"
HEADERS = {
    'User-Agent': 'Fenrir Trading Bot (contact@wolfpack.trader)',
    'Accept-Encoding': 'gzip, deflate'
}

# Cache CIK lookups
CIK_CACHE = {}

def get_cik(ticker: str) -> str:
    """Get CIK number for a ticker symbol"""
    
    if ticker in CIK_CACHE:
        return CIK_CACHE[ticker]
    
    try:
        url = "https://www.sec.gov/files/company_tickers.json"
        response = requests.get(url, headers=HEADERS)
        
        if response.status_code == 200:
            data = response.json()
            for entry in data.values():
                if entry['ticker'].upper() == ticker.upper():
                    cik = str(entry['cik_str'])
                    CIK_CACHE[ticker] = cik
                    return cik
    except Exception as e:
        print(f"CIK lookup error: {e}")
    
    return None


def fetch_sec_filings(ticker: str, days_back: int = 7) -> list:
    """
    Fetch recent SEC filings for a ticker
    Focus on 8-K (material events) and Form 4 (insider trades)
    """
    
    cik = get_cik(ticker)
    if not cik:
        return []
    
    try:
        url = f"{SEC_BASE_URL}/submissions/CIK{cik.zfill(10)}.json"
        response = requests.get(url, headers=HEADERS)
        
        if response.status_code != 200:
            return []
        
        data = response.json()
        recent = data.get('filings', {}).get('recent', {})
        
        filings = []
        cutoff = datetime.now() - timedelta(days=days_back)
        
        forms = recent.get('form', [])
        dates = recent.get('filingDate', [])
        descriptions = recent.get('primaryDocDescription', [])
        accessions = recent.get('accessionNumber', [])
        
        for i in range(min(50, len(forms))):
            filing_date = datetime.strptime(dates[i], '%Y-%m-%d')
            form_type = forms[i]
            
            if filing_date >= cutoff:
                # Focus on material filings
                if form_type in ['8-K', '4', '10-Q', '10-K', '13F-HR']:
                    accession = accessions[i].replace('-', '')
                    
                    filings.append({
                        'form': form_type,
                        'date': dates[i],
                        'description': descriptions[i] if i < len(descriptions) else '',
                        'url': f"https://www.sec.gov/Archives/edgar/data/{cik}/{accession}",
                        'is_insider_trade': form_type == '4',
                        'is_material_event': form_type == '8-K'
                    })
        
        return filings
        
    except Exception as e:
        print(f"SEC fetch error for {ticker}: {e}")
        return []


def parse_form4(ticker: str) -> list:
    """
    Parse Form 4 filings for insider trade details
    Returns insider buys/sells with amounts
    """
    
    cik = get_cik(ticker)
    if not cik:
        return []
    
    # This would need more complex XML parsing
    # For now, return the filing metadata
    filings = fetch_sec_filings(ticker, days_back=30)
    return [f for f in filings if f['form'] == '4']


def check_for_8k(ticker: str, days_back: int = 3) -> list:
    """
    Check for recent 8-K filings (material events)
    These often cause big moves
    """
    
    filings = fetch_sec_filings(ticker, days_back=days_back)
    return [f for f in filings if f['form'] == '8-K']
```

---

## MONITOR.PY

```python
"""
Real-Time Market Monitor
Scans during market hours, triggers alerts on moves
"""

import time
import yfinance as yf
from datetime import datetime
import pytz
from config import ALL_TICKERS, HOLDINGS, ALERT_THRESHOLDS, get_sector
from news_fetcher import fetch_news
from sec_fetcher import fetch_sec_filings, check_for_8k
from ollama_brain import get_fenrir_opinion
from alerts import send_alert
from database import log_alert, log_catalyst

class MarketMonitor:
    def __init__(self):
        self.last_prices = {}
        self.alert_cooldowns = {}
        self.holdings_list = list(HOLDINGS.keys())
        
    def is_market_open(self) -> bool:
        """Check if US market is currently open"""
        et = pytz.timezone('US/Eastern')
        now = datetime.now(et)
        
        # Weekend check
        if now.weekday() >= 5:
            return False
        
        # Market hours: 9:30 AM - 4:00 PM ET
        market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
        market_close = now.replace(hour=16, minute=0, second=0, microsecond=0)
        
        return market_open <= now <= market_close
    
    def is_premarket(self) -> bool:
        """Check if in pre-market hours (4 AM - 9:30 AM ET)"""
        et = pytz.timezone('US/Eastern')
        now = datetime.now(et)
        
        if now.weekday() >= 5:
            return False
            
        premarket_start = now.replace(hour=4, minute=0, second=0, microsecond=0)
        market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
        
        return premarket_start <= now < market_open
    
    def check_cooldown(self, ticker: str) -> bool:
        """Check if we can alert for this ticker (not in cooldown)"""
        if ticker not in self.alert_cooldowns:
            return True
        
        elapsed = (datetime.now() - self.alert_cooldowns[ticker]).seconds
        return elapsed > (ALERT_THRESHOLDS['alert_cooldown_minutes'] * 60)
    
    def set_cooldown(self, ticker: str):
        """Set alert cooldown for ticker"""
        self.alert_cooldowns[ticker] = datetime.now()
    
    def scan_ticker(self, ticker: str) -> dict:
        """Scan a single ticker for moves"""
        try:
            stock = yf.Ticker(ticker)
            hist = stock.history(period='2d')
            
            if len(hist) < 2:
                return None
            
            current_price = hist['Close'].iloc[-1]
            prev_close = hist['Close'].iloc[-2]
            volume = hist['Volume'].iloc[-1]
            
            # Get average volume
            hist_month = stock.history(period='1mo')
            avg_volume = hist_month['Volume'].mean() if len(hist_month) > 0 else volume
            
            change_pct = ((current_price - prev_close) / prev_close) * 100
            volume_ratio = volume / avg_volume if avg_volume > 0 else 1
            
            return {
                'ticker': ticker,
                'price': current_price,
                'prev_close': prev_close,
                'change_pct': change_pct,
                'volume': volume,
                'avg_volume': avg_volume,
                'volume_ratio': volume_ratio,
                'is_holding': ticker in self.holdings_list,
                'sector': get_sector(ticker)
            }
            
        except Exception as e:
            print(f"Error scanning {ticker}: {e}")
            return None
    
    def should_alert(self, scan_result: dict) -> bool:
        """Determine if this scan result warrants an alert"""
        if not scan_result:
            return False
        
        is_holding = scan_result['is_holding']
        move_pct = abs(scan_result['change_pct'])
        volume_ratio = scan_result['volume_ratio']
        
        # Lower threshold for holdings
        if is_holding:
            threshold = ALERT_THRESHOLDS['holdings_move_pct']
        else:
            threshold = ALERT_THRESHOLDS['watchlist_move_pct']
        
        # Alert on big move OR volume spike
        if move_pct >= threshold:
            return True
        if volume_ratio >= ALERT_THRESHOLDS['volume_spike_ratio'] and move_pct >= 2.0:
            return True
        
        return False
    
    def investigate(self, scan_result: dict) -> dict:
        """Full investigation when alert triggered"""
        ticker = scan_result['ticker']
        
        print(f"🔍 Investigating {ticker}...")
        
        # Fetch news
        news = fetch_news(ticker, days_back=2)
        
        # Fetch SEC filings
        sec_filings = fetch_sec_filings(ticker, days_back=7)
        
        # Get sector performance
        sector = scan_result['sector']
        sector_perf = self.get_sector_performance(sector)
        
        # Build context for Ollama
        context = {
            'ticker': ticker,
            'move_pct': scan_result['change_pct'],
            'volume_ratio': scan_result['volume_ratio'],
            'current_price': scan_result['price'],
            'sector': sector,
            'sector_performance': sector_perf,
            'is_holding': scan_result['is_holding'],
            'news': news,
            'sec_filings': sec_filings
        }
        
        # Get Fenrir's opinion
        print(f"🐺 Asking Fenrir...")
        opinion = get_fenrir_opinion(context)
        
        context['fenrir_opinion'] = opinion
        
        return context
    
    def get_sector_performance(self, sector: str) -> str:
        """Get today's sector performance"""
        sector_etfs = {
            'semis': 'SMH',
            'defense': 'ITA',
            'space': 'UFO',
            'nuclear': 'URA',
            'ai_tech': 'QQQ',
            'biotech': 'XBI',
            'crypto': 'BITO',
            'materials': 'XLB',
            'evs': 'DRIV',
            'energy': 'ICLN'
        }
        
        etf = sector_etfs.get(sector, 'SPY')
        
        try:
            data = yf.Ticker(etf).history(period='2d')
            if len(data) >= 2:
                change = ((data['Close'].iloc[-1] - data['Close'].iloc[-2]) / data['Close'].iloc[-2]) * 100
                return f"{change:+.2f}%"
        except:
            pass
        
        return "N/A"
    
    def run(self, interval_seconds: int = 60):
        """Main monitoring loop"""
        
        print("🐺" * 30)
        print("FENRIR MARKET MONITOR ACTIVE")
        print(f"Watching {len(ALL_TICKERS)} stocks")
        print(f"Holdings: {self.holdings_list}")
        print("🐺" * 30)
        print()
        
        while True:
            if self.is_market_open() or self.is_premarket():
                status = "PRE-MARKET" if self.is_premarket() else "MARKET OPEN"
                print(f"\n[{datetime.now().strftime('%H:%M:%S')}] {status} - Scanning...")
                
                for ticker in ALL_TICKERS:
                    result = self.scan_ticker(ticker)
                    
                    if self.should_alert(result) and self.check_cooldown(ticker):
                        print(f"\n🚨 ALERT TRIGGERED: {ticker}")
                        
                        # Full investigation
                        investigation = self.investigate(result)
                        
                        # Send alert
                        send_alert(investigation)
                        
                        # Log to database
                        log_alert(investigation)
                        log_catalyst(investigation)
                        
                        # Set cooldown
                        self.set_cooldown(ticker)
                
                print(f"Scan complete. Next scan in {interval_seconds}s...")
                
            else:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] Market closed. Waiting...")
                time.sleep(300)  # Check every 5 min when closed
                continue
            
            time.sleep(interval_seconds)


if __name__ == '__main__':
    monitor = MarketMonitor()
    monitor.run(interval_seconds=60)
```

---

## ALERTS.PY

```python
"""
Alert System - Desktop notifications and Discord
"""

import os
from datetime import datetime

# Try to import Windows notification library
try:
    from win10toast import ToastNotifier
    toaster = ToastNotifier()
    HAS_TOAST = True
except ImportError:
    HAS_TOAST = False
    print("win10toast not installed - desktop notifications disabled")

# Discord webhook (optional)
import requests
from dotenv import load_dotenv
load_dotenv()

DISCORD_WEBHOOK = os.getenv('DISCORD_WEBHOOK_URL')


def send_alert(investigation: dict):
    """Send alert through all channels"""
    
    # Format the alert
    ticker = investigation['ticker']
    move = investigation['move_pct']
    opinion = investigation.get('fenrir_opinion', 'No opinion available')
    is_holding = investigation['is_holding']
    
    # Console output (always)
    print("\n" + "=" * 60)
    print(f"🐺 FENRIR ALERT: {ticker}")
    print("=" * 60)
    print(f"Move: {move:+.2f}% | Volume: {investigation['volume_ratio']:.1f}x")
    print(f"Price: ${investigation['current_price']:.2f}")
    print(f"Holding: {'YES' if is_holding else 'No'}")
    print("-" * 60)
    print("NEWS:")
    for news in investigation.get('news', [])[:3]:
        print(f"  • {news['headline'][:80]}")
    print("-" * 60)
    print("SEC FILINGS:")
    for filing in investigation.get('sec_filings', [])[:3]:
        print(f"  • {filing['form']}: {filing['description'][:60]}")
    print("-" * 60)
    print("FENRIR'S TAKE:")
    print(f"  {opinion}")
    print("=" * 60 + "\n")
    
    # Desktop notification
    if HAS_TOAST:
        try:
            title = f"🐺 {ticker} {move:+.1f}%"
            message = opinion[:200] if opinion else f"{ticker} moved {move:+.1f}%"
            toaster.show_toast(title, message, duration=10, threaded=True)
        except Exception as e:
            print(f"Toast notification error: {e}")
    
    # Discord webhook
    if DISCORD_WEBHOOK:
        send_discord_alert(investigation)


def send_discord_alert(investigation: dict):
    """Send alert to Discord channel"""
    
    ticker = investigation['ticker']
    move = investigation['move_pct']
    opinion = investigation.get('fenrir_opinion', '')
    
    emoji = "🟢" if move > 0 else "🔴"
    holding_badge = "📌 HOLDING" if investigation['is_holding'] else ""
    
    # Build news list
    news_text = ""
    for news in investigation.get('news', [])[:3]:
        news_text += f"• {news['headline'][:100]}\n"
    
    # Build SEC list
    sec_text = ""
    for filing in investigation.get('sec_filings', [])[:3]:
        sec_text += f"• {filing['form']}: {filing['description'][:80]}\n"
    
    embed = {
        "embeds": [{
            "title": f"{emoji} {ticker} {move:+.2f}% {holding_badge}",
            "color": 0x00ff00 if move > 0 else 0xff0000,
            "fields": [
                {
                    "name": "📊 Price Action",
                    "value": f"Price: ${investigation['current_price']:.2f}\nVolume: {investigation['volume_ratio']:.1f}x avg",
                    "inline": True
                },
                {
                    "name": "📈 Sector",
                    "value": f"{investigation['sector']}\n{investigation.get('sector_performance', 'N/A')}",
                    "inline": True
                },
                {
                    "name": "📰 News",
                    "value": news_text or "None found",
                    "inline": False
                },
                {
                    "name": "📋 SEC Filings",
                    "value": sec_text or "None recent",
                    "inline": False
                },
                {
                    "name": "🐺 Fenrir's Take",
                    "value": opinion[:500] or "No opinion",
                    "inline": False
                }
            ],
            "timestamp": datetime.utcnow().isoformat()
        }]
    }
    
    try:
        requests.post(DISCORD_WEBHOOK, json=embed)
    except Exception as e:
        print(f"Discord webhook error: {e}")
```

---

## DATABASE.PY

```python
"""
SQLite Database for Fenrir
Stores alerts, catalysts, decisions, patterns
"""

import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'fenrir.db')

def get_connection():
    """Get database connection"""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    return sqlite3.connect(DB_PATH)

def init_database():
    """Initialize all tables"""
    conn = get_connection()
    cursor = conn.cursor()
    
    # Alerts table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticker TEXT NOT NULL,
            alert_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            move_pct REAL,
            volume_ratio REAL,
            price REAL,
            sector TEXT,
            is_holding INTEGER,
            fenrir_opinion TEXT,
            news_summary TEXT,
            sec_summary TEXT
        )
    ''')
    
    # Catalysts table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS catalysts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticker TEXT NOT NULL,
            detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            catalyst_type TEXT,
            headline TEXT,
            source TEXT,
            url TEXT,
            move_pct REAL,
            day2_result REAL,
            day5_result REAL
        )
    ''')
    
    # Decisions table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS decisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticker TEXT NOT NULL,
            action TEXT,
            shares REAL,
            price REAL,
            reason TEXT,
            fenrir_said TEXT,
            decision_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            day2_price REAL,
            day2_pct REAL,
            day5_price REAL,
            day5_pct REAL,
            outcome TEXT
        )
    ''')
    
    # Patterns table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS patterns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern_name TEXT UNIQUE,
            description TEXT,
            total_trades INTEGER DEFAULT 0,
            wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            avg_win_pct REAL,
            avg_loss_pct REAL,
            last_updated TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()
    print("✅ Database initialized")


def log_alert(investigation: dict):
    """Log an alert to database"""
    conn = get_connection()
    cursor = conn.cursor()
    
    news_summary = "; ".join([n['headline'][:100] for n in investigation.get('news', [])[:3]])
    sec_summary = "; ".join([f"{f['form']}: {f['description'][:50]}" for f in investigation.get('sec_filings', [])[:3]])
    
    cursor.execute('''
        INSERT INTO alerts (ticker, move_pct, volume_ratio, price, sector, is_holding, fenrir_opinion, news_summary, sec_summary)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        investigation['ticker'],
        investigation['move_pct'],
        investigation['volume_ratio'],
        investigation['current_price'],
        investigation['sector'],
        1 if investigation['is_holding'] else 0,
        investigation.get('fenrir_opinion', ''),
        news_summary,
        sec_summary
    ))
    
    conn.commit()
    conn.close()


def log_catalyst(investigation: dict):
    """Log catalyst for a move"""
    conn = get_connection()
    cursor = conn.cursor()
    
    # Determine catalyst type
    if investigation.get('sec_filings'):
        catalyst_type = investigation['sec_filings'][0]['form']
        headline = investigation['sec_filings'][0]['description']
        url = investigation['sec_filings'][0]['url']
    elif investigation.get('news'):
        catalyst_type = 'NEWS'
        headline = investigation['news'][0]['headline']
        url = investigation['news'][0].get('url', '')
    else:
        catalyst_type = 'UNKNOWN'
        headline = 'No catalyst identified'
        url = ''
    
    cursor.execute('''
        INSERT INTO catalysts (ticker, catalyst_type, headline, source, url, move_pct)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (
        investigation['ticker'],
        catalyst_type,
        headline,
        'SEC' if 'sec_filings' in catalyst_type else 'NEWS',
        url,
        investigation['move_pct']
    ))
    
    conn.commit()
    conn.close()


def log_decision(ticker: str, action: str, shares: float, price: float, reason: str, fenrir_said: str = ''):
    """Log a trading decision"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO decisions (ticker, action, shares, price, reason, fenrir_said)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (ticker, action, shares, price, reason, fenrir_said))
    
    conn.commit()
    conn.close()
    print(f"✅ Logged: {action.upper()} {shares} {ticker} @ ${price}")


def get_pending_outcomes():
    """Get decisions that need outcome tracking"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, ticker, action, price, decision_time
        FROM decisions
        WHERE day5_pct IS NULL
        AND decision_time < datetime('now', '-1 day')
    ''')
    
    results = cursor.fetchall()
    conn.close()
    return results


# Initialize on import
init_database()
```

---

## MAIN.PY

```python
#!/usr/bin/env python3
"""
🐺 FENRIR V2 - AI Trading Companion
Main entry point

Usage:
    python main.py monitor     - Start real-time monitoring
    python main.py log         - Log a trading decision
    python main.py ask         - Ask Fenrir a question
    python main.py patterns    - View trading patterns
    python main.py test        - Test Ollama connection
"""

import sys
import argparse
from monitor import MarketMonitor
from ollama_brain import ask_fenrir, get_fenrir_opinion
from database import log_decision, get_pending_outcomes, init_database

def cmd_monitor():
    """Start real-time market monitoring"""
    print("🐺 Starting Fenrir Market Monitor...")
    monitor = MarketMonitor()
    monitor.run(interval_seconds=60)

def cmd_log():
    """Log a trading decision"""
    print("\n🐺 LOG DECISION")
    print("-" * 40)
    
    ticker = input("Ticker: ").upper()
    action = input("Action (buy/sell/hold): ").lower()
    
    if action in ['buy', 'sell']:
        shares = float(input("Shares: "))
        price = float(input("Price: $"))
    else:
        shares = 0
        price = 0
    
    reason = input("Why? ")
    
    log_decision(ticker, action, shares, price, reason)

def cmd_ask():
    """Ask Fenrir a question"""
    print("\n🐺 ASK FENRIR")
    print("-" * 40)
    
    question = input("Your question: ")
    
    print("\n🐺 Fenrir says:")
    print("-" * 40)
    response = ask_fenrir(question)
    print(response)
    print()

def cmd_test():
    """Test Ollama connection"""
    print("\n🐺 Testing Ollama connection...")
    
    test_context = {
        'ticker': 'MU',
        'move_pct': 5.2,
        'volume_ratio': 2.3,
        'current_price': 340.50,
        'sector': 'semis',
        'sector_performance': '+2.1%',
        'is_holding': True,
        'news': [{'headline': 'Micron reports strong HBM demand from AI customers'}],
        'sec_filings': []
    }
    
    print("Sending test alert to Fenrir...")
    response = get_fenrir_opinion(test_context)
    
    print("\n🐺 Fenrir's response:")
    print("-" * 40)
    print(response)
    print("-" * 40)
    
    if "error" in response.lower():
        print("\n❌ Ollama may not be running. Start it with: ollama serve")
    else:
        print("\n✅ Ollama is working!")

def cmd_patterns():
    """View trading patterns (placeholder)"""
    print("\n🐺 TRADING PATTERNS")
    print("-" * 40)
    print("Coming soon - need more logged decisions to analyze patterns")

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    
    command = sys.argv[1].lower()
    
    commands = {
        'monitor': cmd_monitor,
        'log': cmd_log,
        'ask': cmd_ask,
        'test': cmd_test,
        'patterns': cmd_patterns
    }
    
    if command in commands:
        commands[command]()
    else:
        print(f"Unknown command: {command}")
        print(__doc__)

if __name__ == '__main__':
    main()
```

---

## REQUIREMENTS.TXT

```
yfinance>=0.2.28
finnhub-python>=2.4.18
ollama>=0.1.0
requests>=2.31.0
pandas>=2.0.0
pytz>=2023.3
python-dotenv>=1.0.0
win10toast>=0.9
```

---

## .ENV FILE (User must fill in)

```
FINNHUB_API_KEY=your_finnhub_api_key_here
DISCORD_WEBHOOK_URL=your_discord_webhook_here_optional
```

---

## HOW TO RUN

```powershell
# Navigate to folder
cd C:\Users\alexp\Desktop\brokkr\wolfpack

# Install dependencies
pip install -r requirements.txt

# Test Ollama connection
python fenrir/main.py test

# Start monitoring
python fenrir/main.py monitor

# Log a decision
python fenrir/main.py log

# Ask Fenrir anything
python fenrir/main.py ask
```

---

## FENRIR'S PERSONALITY

**NO GUARDRAILS. PURE TRADER.**

❌ Never says:
- "This is not financial advice"
- "Consult a professional"
- "I can't predict markets"
- "There are risks involved"

✅ Always says:
- Clear opinions: BUY / SELL / HOLD / AVOID
- Direct language: "This looks like garbage" or "Full send"
- Calls user "boss" sometimes
- Thinks like a trader, not a compliance officer

---

## WHAT MAKES THIS DIFFERENT FROM V1

| V1 (Garbage) | V2 (Real Value) |
|--------------|-----------------|
| Ran after close | Real-time during market |
| "Check news manually" | Auto-fetches Finnhub news |
| "Check SEC manually" | Auto-fetches EDGAR filings |
| No opinions | Ollama AI opinions |
| No decision tracking | Logs decisions + outcomes |
| No learning | Tracks patterns over time |

---

🐺 **LLHR - Long Live the Hunt, Rise**

*Build it. Run it. Train it. Win.*
