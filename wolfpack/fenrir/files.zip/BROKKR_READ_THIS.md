# 🐺 BROKKR - YOUR JOB (READ THIS)

## THE PLAN - TWO PARTS

### PART 1: YOU (BROKKR IN VS CODE)
Build the LOCAL Fenrir system. These are the Python files that run on my Windows PC.

**Your files to create in `wolfpack/fenrir/`:**
```
config.py           ← Settings, holdings, watchlist (ALREADY PROVIDED)
market_data.py      ← yfinance price fetching (ALREADY PROVIDED)
news_fetcher.py     ← Finnhub API (ALREADY PROVIDED)
sec_fetcher.py      ← SEC filings (ALREADY PROVIDED)
database.py         ← SQLite logging (ALREADY PROVIDED)
ollama_brain.py     ← Talks to Ollama (ALREADY PROVIDED)
alerts.py           ← Windows notifications (ALREADY PROVIDED)
main.py             ← CLI entry point (ALREADY PROVIDED)
Modelfile           ← Fenrir personality (ALREADY PROVIDED)
requirements.txt    ← Dependencies (ALREADY PROVIDED)
.env.example        ← API key template (ALREADY PROVIDED)
```

**ALL THESE FILES ARE IN THE `fenrir_files/` FOLDER I GAVE YOU.**

Just copy them to `C:\Users\alexp\Desktop\brokkr\wolfpack\fenrir\`

Then:
1. `pip install -r requirements.txt`
2. `ollama pull llama3.1:8b`
3. `ollama create fenrir -f Modelfile`
4. `python main.py test`

That's it. You're done. The local system will work.

---

### PART 2: COLAB PRO (NOT YOUR JOB)
Training, testing, and fine-tuning happens in Colab with A100 GPU.

**Colab does:**
- Scan entire market (needs GPU power)
- Test Fenrir's personality
- Collect training data
- Eventually fine-tune the model
- Export trained weights

**When fine-tuning is done:**
- We export the trained model from Colab
- We load it into Ollama locally
- We update the Modelfile to use the trained model
- Your local system automatically uses the better brain

---

## WHAT YOU SHOULD NOT DO

❌ Don't ask about fine-tuning - that's Colab's job
❌ Don't try to train anything locally - no GPU
❌ Don't wait for training - the system works NOW with base llama3.1

---

## WHAT YOU SHOULD DO

✅ Copy the files I gave you to `wolfpack/fenrir/`
✅ Install requirements
✅ Create the Fenrir model in Ollama
✅ Test it works: `python main.py test`
✅ Tell me when it's running

---

## THE WORKFLOW

```
YOU BUILD LOCAL SYSTEM (files I gave you)
        ↓
I TRAIN IN COLAB (separate)
        ↓
TRAINED MODEL COMES BACK TO LOCAL
        ↓
YOUR SYSTEM USES SMARTER BRAIN
```

You don't need to do anything for training. Just build what I gave you.

---

## TL;DR

1. Take the `fenrir_files/` folder
2. Put contents in `wolfpack/fenrir/`
3. Run setup commands
4. Done

The "fine-tuning" question you asked - ignore it. That happens in Colab later. Your system works right now with the base model.

🐺 LLHR
