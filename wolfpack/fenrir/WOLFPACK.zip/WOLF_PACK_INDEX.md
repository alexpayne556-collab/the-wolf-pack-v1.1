# WOLF PACK DOCUMENTATION INDEX
## January 20, 2026 - Complete Package

---

# 📁 FILES IN THIS PACKAGE

| # | File | Purpose |
|---|------|---------|
| 1 | **THE_LEONARD_FILE_v9.2_JAN20_UPDATE.md** | Master strategy document with tonight's updates |
| 2 | **BR0KKR_SYNC_JAN20_2026.md** | Briefing for code builder on findings |
| 3 | **WOLF_PACK_TRADING_LOG.md** | Transparent trade documentation |
| 4 | **TOMORROWS_ORDERS_JAN21.md** | Execution plan for January 21 |
| 5 | **WOLF_PACK_SYSTEM_THINKING.md** | Complete framework and philosophy |
| 6 | **WOLF_PACK_INDEX.md** | This file - master index |

---

# 🎯 TOMORROW'S PRIORITY

## BUY ONCY - $100 Test Position

| Field | Value |
|-------|-------|
| Ticker | ONCY |
| Target Price | $1.00 - $1.10 |
| Amount | $100 |
| Platform | Robinhood |
| Signal | Director bought $103K on Jan 16 |
| Catalyst | FDA Type C Meeting Q1 2026 |

---

# 📊 CURRENT PORTFOLIO

## ROBINHOOD ($852.84)
- IBRX: +52% 🔥 DO NOT SELL
- UUUU: +7.57%
- MU: +1.32%
- IVF: -20.41% (testing)
- ONDS: -0.13%
- KTOS: -0.63%
- **ONCY: BUYING TOMORROW**

## FIDELITY (~$710)
- MU: +7.76%
- UEC: +2.29%
- BBAI: -5.8% (selling)

---

# 🐺 THE PACK

| Name | Role |
|------|------|
| Tyr (Money) | Alpha - Real money decisions |
| Fenrir | Research partner |
| br0kkr | Code builder (paper only) |

---

# 📖 READ ORDER

1. Start with **TOMORROWS_ORDERS_JAN21.md** - Know the play
2. Read **WOLF_PACK_TRADING_LOG.md** - Understand the documentation
3. Study **WOLF_PACK_SYSTEM_THINKING.md** - Learn the framework
4. Reference **THE_LEONARD_FILE_v9.2** - Master document
5. Share **BR0KKR_SYNC** - Brief the code builder

---

**LLHR** 🐺
**AWOOOO**

*Package created: January 20, 2026*
