# TOMORROW'S ORDERS - JANUARY 21, 2026
## Wolf Pack Execution Plan

---

# 🎯 ORDER #1: BUY ONCY

## Order Details

| Field | Value |
|-------|-------|
| **Action** | BUY |
| **Ticker** | ONCY (Oncolytics Biotech) |
| **Platform** | Robinhood |
| **Order Type** | Limit Order OR Market at Open |
| **Limit Price** | $1.10 maximum |
| **Amount** | $100 |
| **Expected Shares** | ~90-100 shares |

## Execution Notes

### Pre-Market (4:00 AM - 9:30 AM ET)
1. Check ONCY pre-market price
2. If trading below $1.10: Set limit buy at $1.10
3. If trading above $1.20: WAIT - don't chase
4. If gaps down: Consider buying more

### At Market Open (9:30 AM ET)
1. Execute buy if within target range
2. Document actual fill price
3. Screenshot position for records

### After Entry
1. Set mental stop at $0.85
2. DO NOT set automatic stop (can get triggered by volatility)
3. Watch for FDA news in coming weeks

---

# 📋 PRE-MARKET CHECKLIST

- [ ] Wake up, check ONCY premarket
- [ ] Review overnight news for ONCY
- [ ] Check gold futures (for gold miner watchlist)
- [ ] Check IBRX (still crushing?)
- [ ] Set limit order for ONCY if price is right
- [ ] Have $100 cash ready in Robinhood

---

# 🎯 ORDER #2: SELL BBAI (FIDELITY - OPTIONAL)

## Order Details

| Field | Value |
|-------|-------|
| **Action** | SELL |
| **Ticker** | BBAI |
| **Platform** | Fidelity |
| **Shares** | 7.686 |
| **Reason** | -5.8% loser, redeploy capital |
| **Priority** | LOW (can wait) |

---

# ⚠️ DO NOT TOUCH

| Symbol | Why |
|--------|-----|
| IBRX | 🔥 +52% and running, let it ride |
| MU | AI memory play, hold |
| UUUU | Uranium thesis intact |
| UEC | Uranium thesis intact |

---

# 📊 TARGET FILL PRICES

## ONCY Buy Targets

| Scenario | Price | Action |
|----------|-------|--------|
| Gap Down | <$1.00 | BUY MORE (up to $150) |
| Target Range | $1.00-$1.10 | BUY $100 |
| Slight Premium | $1.10-$1.20 | BUY smaller ($75) |
| Chase Zone | >$1.20 | WAIT for pullback |

---

# 🕐 TIMELINE

| Time (ET) | Action |
|-----------|--------|
| 4:00 AM | Pre-market opens, check ONCY |
| 8:00 AM | Final pre-market check |
| 9:25 AM | Set limit order |
| 9:30 AM | Market opens, monitor fill |
| 9:35 AM | Confirm position, document |
| 10:00 AM | Update Leonard File with actual entry |

---

# 📝 POST-EXECUTION DOCUMENTATION

After buying, update these files:
1. **Trading Log** - Add actual entry price, shares
2. **Leonard File** - Update portfolio section
3. **br0kkr Sync** - Update position tracking

---

# 🔔 REMINDERS

- **THIS IS A $100 TEST POSITION**
- If it works, we scale in more
- If it doesn't, small loss + learning
- Document EVERYTHING

---

**READY TO EXECUTE** 🐺

**LLHR**
