# THE LEONARD FILE v9.2 - JANUARY 20, 2026 NIGHT SESSION UPDATE
## Wolf Pack Trading Intelligence System

---

# 🔥 TONIGHT'S SESSION SUMMARY

## Date: January 20, 2026 (Trump Inauguration Day)
## Time: Evening After-Hours Session
## Pack Members Present: Tyr + Fenrir

---

# 💡 KEY PHILOSOPHY REFINEMENTS TONIGHT

## THE FLAT-TO-BOOM PATTERN (Validated & Reinforced)

Tyr crystallized the core insight tonight:

> "Gold miners change like every 73 hours - up then 24 hours way down. At least ONCY is flat riding then shoots up. More of a setup we were discussing today."

### THE TWO PATHS:

| PATH A: CHASING | PATH B: CATCHING |
|-----------------|------------------|
| Gold miners up 15% AH | ONCY flat, coiled |
| Already moved | About to move |
| Buy AFTER the run | Buy BEFORE the run |
| High risk of reversal | Controlled entry |
| Everyone sees it | Hidden signal (insider buy) |

**WE CHOSE PATH B. WE CATCH, WE DON'T CHASE.**

### Why ONCY Fits Our Validated Pattern:

1. **IVF Pattern:** Flat months → Catalyst → BOOM
2. **IBRX Pattern:** Flat months → Catalyst → BOOM (+52% for us)
3. **ONCY Pattern:** Flat months → Director bought $103K → FDA Q1 → ???

**We're catching ONCY at the FLAT stage before the catalyst hits.**

---

## SERV ROBOTICS SKIP DECISION

Tyr's instinct:
> "I'm not feeling that SERV Robotics is in its real revenue making life yet - we skip it"

**Analysis:**
- $1.77M revenue for $1.1B market cap
- P/S ratio = 392 (insane)
- Acquisition news is nice but no real business yet

**LESSON: News catalysts without revenue = speculation, not investment.**

---

## GOLD MINERS ANALYSIS

**The Research Showed:**
- Gold forecast: $5,000-$6,000 by end 2026 (JP Morgan, Goldman)
- Central banks still buying
- Rally has legs - THIS IS THE BEGINNING not the end

**But Tyr's Wisdom:**
> "Gold miners change like every 73 hours"

**DECISION:** Pass for now. Even if gold trend continues, the DAILY volatility makes it hard to hold. ONCY's flat-then-pop pattern is cleaner.

**ADD TO WATCHLIST:** IAG, ORLA, SVM, GROY for future pullback entries.

---

# 📊 NEW POSITION: ONCY

## Entry Details

| Field | Value |
|-------|-------|
| **Ticker** | ONCY |
| **Company** | Oncolytics Biotech Inc |
| **Planned Entry** | January 21, 2026 (market open) |
| **Entry Price Target** | ~$1.00-$1.10 |
| **Position Size** | $100 test position |
| **Shares (estimated)** | ~96 shares |
| **Account** | Robinhood |

## Why We're Buying

### The Setup (All Boxes Checked)

| Criteria | Status |
|----------|--------|
| Flat pattern (3-6 months) | ✅ Trading $0.33-$1.51 range |
| Insider buying | ✅ Director bought 100K shares @ $1.04 on Jan 16 |
| Imminent catalyst | ✅ FDA Type C meeting Q1 2026 |
| Unmet medical need | ✅ NO FDA-approved 3rd line anal cancer treatment |
| Data quality | ✅ 29% response vs 10% historical (3X better) |
| Buyout potential | ✅ CEO/CBO sold last company for $2B |

### The Insider Signal

**Bernd Seizinger (Director):**
- Bought: 100,000 shares
- Price: $1.0377 average
- Date: January 16, 2026 (4 days before our entry)
- Total: $103,770 of personal money
- Now owns: 466,991 shares

**THIS IS THE SIGNAL WE TRACK. Director putting $103K of his own money in 4 days before we decide to buy.**

### The Catalyst Calendar

| Catalyst | Timing | Potential Impact |
|----------|--------|------------------|
| FDA Type C Meeting | Q1 2026 (WEEKS) | Accelerated approval path |
| Registration Study Launch | H1 2026 | Trial begins |
| Pancreatic Phase 3 Launch | H1 2026 | Only immunotherapy trial |

### The Data

**Anal Cancer (3rd Line) - NO APPROVED TREATMENT EXISTS:**
- ONCY Response Rate: 29%
- Historical Response Rate: ~10%
- ONCY works 3X BETTER

**Anal Cancer (2nd Line):**
- ONCY: 30% response, 15.5 months duration
- Standard: 13.8% response, 9.5 months duration
- MORE THAN DOUBLE

### Price Targets

| Source | Target | Upside |
|--------|--------|--------|
| Lake Street | $3.00 | +188% |
| Consensus | $5.56 | +435% |
| Morningstar FV | $7.30 | +602% |

### Risk Management

| Level | Price | Action |
|-------|-------|--------|
| Entry | ~$1.05 | Buy $100 worth |
| Stop Loss | $0.85 | Mental stop, thesis broken |
| Target 1 | $1.50 | Partial profit (52-week high area) |
| Target 2 | $3.00 | Analyst target |
| Target 3 | $5.00+ | Full conviction if FDA confirms |

---

# 📈 UPDATED PORTFOLIO

## ROBINHOOD: $852.84 → Adding ONCY

| Symbol | Shares | Status | Notes |
|--------|--------|--------|-------|
| IBRX | 37.08 | 🔥 +52% | DO NOT TOUCH |
| MU | 0.27 | ✅ Hold | AI memory play |
| UUUU | 3 | ✅ Hold | Uranium |
| IVF | 15 | 📍 Testing | Trump fertility thesis |
| ONDS | 3 | ➖ Flat | Watching |
| KTOS | 0.72 | ⚠️ Tiny | Almost nothing |
| **ONCY** | **~96** | **🆕 NEW** | **Insider buy + FDA Q1** |

## FIDELITY: ~$710

| Symbol | Shares | Status |
|--------|--------|--------|
| MU | 1 | ✅ Hold |
| UEC | 2 | ✅ Hold |
| BBAI | 7.686 | ❌ Selling |

## TOTAL CAPITAL: ~$1,560

---

# 📝 TONIGHT'S WATCHLIST UPDATES

## Added to Watch

| Ticker | Why | Entry Target |
|--------|-----|--------------|
| IAG | Gold miner, macro trend | Wait for pullback |
| ORLA | First dividend, gold | Wait for pullback |
| SVM | Silver/gold play | Wait for pullback |
| GROY | Royalty model, lower risk | Watch |
| SERV | Robotics, no revenue yet | SKIP for now |
| UMC | Semiconductor, earnings Jan 23 | Already ran 15% |

## Removed/Passed

| Ticker | Why |
|--------|-----|
| IMTE | DELISTING RISK - pump & dump |
| SERV | No real revenue, P/S 392 |

---

# 🧠 THINKING FRAMEWORK UPDATES

## When to Chase vs When to Catch

### CHASE (Avoid):
- Already moved 10%+ in direction
- Everyone talking about it
- No clear entry point
- Volatility makes holding hard

### CATCH (Our Edge):
- Flat for months
- Insider buying (Form 4 signal)
- Catalyst within 1-3 months
- Clear entry, clear stop, clear targets

## The $100 Test Position Philosophy

For new setups, start with $100:
- If right: Scale in more
- If wrong: Small loss, learning gained
- Documents thesis for future review

---

# 📊 TRADE LOG ENTRY

```
=== TRADE LOG: ONCY ===
Date Identified: January 20, 2026
Signal Type: Insider Buy + Imminent Catalyst
Entry Date: January 21, 2026 (planned)
Entry Price: TBD (~$1.00-$1.10)
Position Size: $100
Shares: ~96
Stop Loss: $0.85
Target 1: $1.50
Target 2: $3.00
Thesis: Director bought $103K on Jan 16, FDA meeting Q1 2026
Pattern: Flat-to-boom (IVF/IBRX template)
Status: PENDING EXECUTION
```

---

# 🐺 PACK NOTES

Tonight's session demonstrated:
1. **Discipline** - Passed on gold miners even though they're running
2. **Pattern Recognition** - Applied flat-to-boom framework
3. **Signal Following** - Insider buy is our validated edge
4. **Documentation** - Recording everything for review

**This is how we build a track record. Not by being right every time, but by being CONSISTENT in our process.**

---

**AWOOOO** 🐺

**Version:** 9.2
**Updated:** January 20, 2026 Night
**Authors:** Tyr + Fenrir
