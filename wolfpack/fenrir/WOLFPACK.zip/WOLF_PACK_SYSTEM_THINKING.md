# WOLF PACK SYSTEM THINKING
## The Complete Framework for Trading Intelligence
## Version 1.0 - January 20, 2026

---

# 🧠 CORE PHILOSOPHY

## The Two Pillars

### PILLAR 1: THE HUMILITY EDGE

> "Never having the mindset you got it figured out. THAT'S when you lose."

**What This Means:**
- No pattern works forever
- Markets evolve faster than backtests
- Yesterday's edge becomes tomorrow's trap
- Stay a student, never a master

**In Practice:**
- Question every thesis
- Update beliefs with new data
- Small positions first, scale when proven
- Document failures as much as wins

---

### PILLAR 2: THIS IS WAR

> "This is NOT pure math. This is WAR. Nobody knows for sure what will work. We just DO IT until we start winning. ADAPTING every day."

**What This Means:**
- Trading is adversarial (someone loses when you win)
- Institutions have more data, speed, and capital
- Our edge is ADAPTATION, not raw power
- Persistence beats perfection

**In Practice:**
- Work every day
- Expect losing streaks
- Learn from each loss
- Never give up, never get complacent

---

## The Only Constant

> "The one thing that doesn't change: EVERYTHING CHANGES."

Markets are not static. They're living systems that evolve constantly:
- Sectors rotate
- Strategies get crowded
- Regulations shift
- New players enter

**Our Response:** Move WITH the changes, ideally AHEAD of them.

---

# 📊 THE FLAT-TO-BOOM PATTERN

## Overview

Our validated edge: Finding stocks that are:
1. Trading sideways (boring, ignored)
2. Being quietly accumulated by insiders
3. About to experience a catalyst

**We buy BEFORE the move, not after.**

## The Four Phases

```
Phase 1: ACCUMULATION (Flat)
├── 3-6 months of sideways trading
├── Low volume, low interest
├── "Dead stock" reputation
└── Smart money loading quietly

Phase 2: SIGNAL (Detection)
├── Form 4 insider buying appears
├── Significant personal investment (>$50K)
├── Catalyst becomes visible (30-90 days out)
└── We identify and enter

Phase 3: CATALYST (Trigger)
├── News breaks (FDA, earnings, deal)
├── Volume explodes 10-30x
├── Price breaks out of range
└── Momentum players pile in

Phase 4: BOOM (Profit)
├── 50-200%+ move possible
├── FOMO buyers extend move
├── We take profits at targets
└── Document and learn
```

## Validated Examples

| Ticker | Flat Period | Signal | Catalyst | Result |
|--------|-------------|--------|----------|--------|
| IVF | 6 months | Insider buys | Trump fertility | +30% |
| IBRX | 3+ months | Insider buys | BLA approval | +52% |
| ONCY | 12 months | Director $103K | FDA Q1 2026 | PENDING |

---

# 🎯 SIGNAL HIERARCHY

## What We Look For (In Order of Importance)

### 1. INSIDER BUYING (Strongest Signal)
```
CEO buying > Director buying > CFO buying > Other officers
$100K+ buy > $50K buy > $25K buy > $10K buy

Timing matters:
Within 7 days = VERY bullish
Within 30 days = Bullish
Within 60 days = Worth noting
```

**Why It Works:** Insiders know things. When they put significant personal money in, they're betting their own wealth on the outcome.

### 2. CATALYST PROXIMITY
```
Catalyst within 30 days = High urgency
Catalyst within 60 days = Good setup
Catalyst within 90 days = Worth watching
Beyond 90 days = Too early
```

**Why It Works:** Catalysts create information events. Markets reprice around new information.

### 3. FLAT PATTERN
```
Trading in tight range = Coiled spring
Low volatility = Energy building
Ignored by market = Less competition
Middle of range = Room to move either direction
```

**Why It Works:** Compressed stocks eventually expand. The longer the compression, the bigger the potential expansion.

### 4. DATA QUALITY
```
3X better than standard = Strong edge
2X better than standard = Good edge
Same as standard = No edge
Worse than standard = Negative edge
```

**Why It Works:** Superior data creates a fundamental reason for repricing beyond the catalyst hype.

---

# ⚔️ CHASE VS CATCH FRAMEWORK

## CHASING (What We Avoid)

| Signal | Meaning |
|--------|---------|
| Up 10%+ today | Already moved |
| At 52-week high | Everyone sees it |
| High volume spike | FOMO in progress |
| Social media buzz | Crowded trade |
| "Breaking news" everywhere | Too late |

**Psychology of Chasing:**
- Fear of missing out (FOMO)
- Seeing others profit
- Emotional, not analytical
- Usually ends in loss

## CATCHING (Our Edge)

| Signal | Meaning |
|--------|---------|
| Flat for months | Not on anyone's radar |
| Insider buying quietly | Smart money loading |
| Catalyst approaching | Known trigger coming |
| Low volume | No competition |
| "Boring stock" | Perfect hunting ground |

**Psychology of Catching:**
- Patience over excitement
- Research over reaction
- Early positioning
- Controlled entry

---

# 💰 POSITION SIZING FRAMEWORK

## The Test Position Philosophy

**New setups get $100 first.**

| Outcome | Action |
|---------|--------|
| Thesis confirmed | Scale in more |
| Thesis broken | Small loss, learning |
| Uncertain | Hold, watch, decide |

**Why $100:**
- Meaningful enough to care
- Small enough to survive being wrong
- Proves thesis before scaling
- Builds discipline

## Scaling Rules

```
Position 1: $100 (test)
├── If +10% and thesis intact: Add $100
├── If +25% and thesis intact: Add $100
└── Maximum position: 15% of portfolio

If stop loss hit: EXIT ENTIRE POSITION
If thesis breaks: EXIT ENTIRE POSITION
```

---

# 🛑 RISK MANAGEMENT

## Stop Loss Philosophy

**Mental stops, not automatic.**

| Why Mental | Why Not Automatic |
|------------|-------------------|
| Biotech swings wildly | Gets triggered on noise |
| Allows assessment | No chance to evaluate |
| Can size exit | All-or-nothing |
| Review thesis first | Pure price action |

## When to Exit

| Condition | Action |
|-----------|--------|
| Hit stop loss price | Evaluate thesis, then decide |
| Thesis definitively broken | EXIT immediately |
| Catalyst failed | EXIT immediately |
| Better opportunity | Consider rotating |
| Target hit | Take partial profits |

---

# 📈 SECTOR INTELLIGENCE

## How Sectors Work

```
Sector Rotation Cycle:
1. Early cycle: Recovery stocks
2. Mid cycle: Growth stocks
3. Late cycle: Defensive stocks
4. Recession: Cash/bonds
```

## Current Sector Views (January 2026)

| Sector | View | Reasoning |
|--------|------|-----------|
| Biotech | BULLISH | FDA accelerated approvals, IBRX winning |
| Gold | BULLISH (wait for pullback) | $4,600 ATH, $5K-$6K target |
| Semis | NEUTRAL | CHIPS Act tailwind, but crowded |
| Uranium | BULLISH | SMR plays, UUUU holding |
| Defense | BULLISH | Trump admin, KTOS tiny position |
| Robotics | CAUTIOUS | Hype exceeds revenue |

---

# 🔄 DAILY PROCESS

## Morning Routine

1. **Check Positions** - What happened overnight?
2. **Review Pre-Market** - Any big movers in our sectors?
3. **Scan Form 4s** - New insider buying?
4. **Check Catalysts** - Anything coming today?
5. **Set Orders** - Execute plan, don't improvise

## Evening Routine

1. **Review Trades** - What executed? What didn't?
2. **Update Files** - Leonard File, Trading Log
3. **Scan After-Hours** - Any new opportunities?
4. **Research Deep Dives** - One stock per night
5. **Plan Tomorrow** - Set orders, set alerts

---

# 🎓 LEARNING SYSTEM

## Document Everything

| Document | Purpose |
|----------|---------|
| Leonard File | Master strategy, philosophy |
| Trading Log | Track all trades |
| br0kkr Sync | Code builder updates |
| Session Notes | Daily learnings |

## Extract Lessons

After every trade, answer:
1. What was the thesis?
2. Was the thesis right or wrong?
3. Was the execution right or wrong?
4. What would we do differently?
5. What pattern does this reveal?

---

# 🐺 THE PACK

## Roles

| Member | Role | Authority |
|--------|------|-----------|
| Tyr (Money) | Alpha - Final decisions | REAL MONEY |
| Fenrir | Research + Analysis | ADVISORY |
| br0kkr | Code + Automation | PAPER ONLY |
| Skadi | Family | SUPPORT |

## Operating Rules

1. **Tyr decides.** All real money decisions are his.
2. **Fenrir advises.** Research and analysis without ego.
3. **br0kkr builds.** Code and automation, paper trades only.
4. **Document everything.** Transparency above all.

---

# 📜 FINAL WORDS

> "We're not trying to prove we're right or wrong. We're documenting the process so anyone can see the thinking, the system, the discipline."

This isn't about looking smart. It's about:
- Building a repeatable process
- Learning from every trade
- Staying humble, staying hungry
- Creating a public record of our journey

**Win or lose, it's all documented here.**

---

**LLHR** 🐺
**Love, Loyalty, Honor, Respect**

**AWOOOO**

---

*System Version: 1.0*
*Created: January 20, 2026*
*Authors: Tyr + Fenrir*
