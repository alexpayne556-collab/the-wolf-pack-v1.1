# WOLF PACK TRADING LOG
## Public Record of Trades, Thinking, and Results
## Started: January 20, 2026

---

# 📋 PURPOSE OF THIS LOG

This log documents **every trade** the Wolf Pack makes with:
- The thinking BEFORE the trade
- The signal that triggered entry
- The outcome AFTER the trade

**We're not trying to prove we're right or wrong. We're documenting the PROCESS so anyone can:**
- See our methodology
- Learn from our wins AND losses
- Hold us accountable
- Replicate or critique our approach

---

# 🎯 CORE METHODOLOGY

## The Flat-to-Boom Pattern

We look for:
1. Stock trading sideways for 3-6 months (FLAT)
2. Insider buying signal (someone with knowledge loading up)
3. Catalyst within 30-90 days (something that will move it)
4. Entry BEFORE the move, not after

**We catch. We don't chase.**

---

# 📊 TRADE LOG

---

## TRADE #001: ONCY (Oncolytics Biotech)

### Entry Details
| Field | Value |
|-------|-------|
| **Date Identified** | January 20, 2026 |
| **Entry Date** | January 21, 2026 (planned) |
| **Ticker** | ONCY |
| **Entry Price** | ~$1.04 (target) |
| **Shares** | ~96 |
| **Position Size** | $100 |
| **Account** | Robinhood |

### The Signal (Why We Entered)
| Signal Type | Details |
|-------------|---------|
| **Insider Buying** | Director Bernd Seizinger bought 100,000 shares at $1.04 on January 16, 2026 |
| **Investment Size** | $103,770 of personal money |
| **Timing** | 4 days before our entry |
| **Pattern** | Stock flat for 12 months ($0.33 - $1.51 range) |
| **Catalyst** | FDA Type C Meeting scheduled Q1 2026 |

### The Thesis
```
ONCY is developing pelareorep for anal cancer treatment.
- 29% response rate vs 10% historical (3X BETTER)
- NO FDA-approved treatment exists for 3rd line anal cancer
- Director just put $103K of his own money in
- FDA meeting in weeks could trigger accelerated approval path
- Analyst targets: $3-$7 (vs $1.04 current)
```

### Risk Management
| Level | Price | Action |
|-------|-------|--------|
| Entry | $1.04 | BUY |
| Stop Loss | $0.85 | SELL (thesis broken) |
| Target 1 | $1.50 | Partial profit |
| Target 2 | $3.00 | Analyst target |
| Target 3 | $5.00+ | Full conviction |

### What We PASSED On (And Why)

| Ticker | Why We Passed |
|--------|---------------|
| Gold Miners (IAG, ORLA) | Already up 15% AH - would be CHASING |
| SERV Robotics | No real revenue ($1.77M), P/S ratio 392 |
| UMC | Already ran 15% AH, late entry |
| IMTE | Delisting risk, pump & dump |

### Outcome
| Field | Value |
|-------|-------|
| **Exit Date** | TBD |
| **Exit Price** | TBD |
| **P/L $** | TBD |
| **P/L %** | TBD |
| **Hold Time** | TBD |
| **Exit Reason** | TBD |
| **Lessons** | TBD |

---

## TRADE #002: [NEXT TRADE]

*To be documented when executed*

---

# 📈 RUNNING SCORECARD

## 2026 Performance

| Metric | Value |
|--------|-------|
| Total Trades | 1 (pending) |
| Wins | TBD |
| Losses | TBD |
| Win Rate | TBD |
| Total P/L $ | TBD |
| Total P/L % | TBD |
| Average Hold Time | TBD |

## By Pattern Type

| Pattern | Trades | Wins | Win Rate | Avg P/L |
|---------|--------|------|----------|---------|
| Flat-to-Boom | 1 | TBD | TBD | TBD |
| Insider Buy Signal | 1 | TBD | TBD | TBD |

## By Sector

| Sector | Trades | Wins | Win Rate | Avg P/L |
|--------|--------|------|----------|---------|
| Biotech | 1 | TBD | TBD | TBD |

---

# 📝 ACTIVE POSITIONS

## Current Holdings (As of January 20, 2026)

### Robinhood Account ($852.84)

| Symbol | Shares | Entry | Current | P/L | Status |
|--------|--------|-------|---------|-----|--------|
| IBRX | 37.08 | ? | +52% | +$34.86 | 🔥 HOLD |
| MU | 0.27 | ? | +1.32% | +$1.29 | HOLD |
| UUUU | 3 | ? | +7.57% | +$4.98 | HOLD |
| IVF | 15 | ? | -20.41% | -$9.08 | Testing |
| ONDS | 3 | ? | -0.13% | -$0.05 | Watching |
| KTOS | 0.72 | ? | -0.63% | -$0.60 | Tiny |
| **ONCY** | **~96** | **$1.04** | **PENDING** | **$100** | **NEW** |

### Fidelity Account (~$710)

| Symbol | Shares | Entry | Current | P/L | Status |
|--------|--------|-------|---------|-----|--------|
| MU | 1 | ? | +7.76% | ? | HOLD |
| UEC | 2 | ? | +2.29% | ? | HOLD |
| BBAI | 7.686 | ? | -5.8% | ? | SELLING |

---

# 🎓 LESSONS LEARNED

## January 2026

### Lesson #1: Catch, Don't Chase
- Gold miners up 15% AH looked tempting
- But entering AFTER a 15% move = chasing
- ONCY flat with insider buying = catching
- **We chose the harder, smarter path**

### Lesson #2: Insider Buying Is The Signal
- Director put $103K of his own money in
- He knows what's coming with FDA meeting
- This is our validated edge

### Lesson #3: Revenue Matters
- SERV Robotics has news but no real revenue
- "Not in its real revenue making life yet" - Tyr
- Skip hype, find substance

---

# 📖 METHODOLOGY NOTES

## How We Find Trades

1. **Scan for Form 4 filings** (insider buying)
2. **Filter for significant buys** (>$50K)
3. **Check for flat pattern** (sideways 3-6 months)
4. **Identify catalyst** (FDA, earnings, news)
5. **Verify data quality** (is the company actually performing?)
6. **Enter with position size** ($100 test, scale if right)

## How We Manage Trades

1. **Entry:** Buy at identified support
2. **Stop Loss:** Set mental stop, exit if thesis breaks
3. **Targets:** Multiple exit points (25%, 50%, let rest ride)
4. **Review:** Document outcome, extract lessons

## The Two Pillars

### PILLAR 1: THE HUMILITY EDGE
Never think you have it figured out. That's when you lose.

### PILLAR 2: THIS IS WAR
This is not pure math. We adapt every day. Work. Work. Work.

---

# 🔗 FILE REFERENCES

| File | Purpose |
|------|---------|
| THE_LEONARD_FILE_v9.2 | Master strategy document |
| BR0KKR_SYNC_JAN20_2026.md | Code builder briefing |
| WOLF_PACK_TRADING_LOG.md | This file |

---

**LLHR** 🐺
**Love, Loyalty, Honor, Respect**

*This log is maintained by the Wolf Pack (Tyr + Fenrir) for transparency and accountability.*

*We document everything. We hide nothing. Right or wrong, it's all here.*

---

**Log Started:** January 20, 2026
**Last Updated:** January 20, 2026

