# TRADING RULES

## Compiled from Market Wizards, Interrogated by The Wolf Pack

---

## THE 10 COMMANDMENTS

| # | Rule | The Nuance |
|---|------|------------|
| 1 | **Cut losses when THESIS breaks** | Not on daily noise. Thesis broken = cut immediately. Thesis intact but price down = sit or add ONCE. |
| 2 | **Let winners run while THESIS holds** | Don't set arbitrary profit targets. If thesis is intact and trend continues, stay in. |
| 3 | **Risk 1-2% maximum per trade** | Hard rule. No exceptions. Position size = (Account × 0.02) ÷ (Entry - Stop) |
| 4 | **Know exit BEFORE entry** | Write it down: "I will sell if X happens." Before you buy. |
| 5 | **Undertrade** | If uncomfortable, you're too big. Cut position in half. (Kovner) |
| 6 | **Kill ego** | Especially after big wins. "Biggest setbacks come after biggest victories." |
| 7 | **Watch correlations** | 5 biotech stocks = 1 position 5x as large. Diversify across SECTORS, not just tickers. |
| 8 | **The market is impersonal** | It doesn't know you exist. It doesn't care if you win or lose. |
| 9 | **Be willing to be wrong** | Wrong, wrong, wrong, then double your money. Mistakes are part of the process. |
| 10 | **Document everything** | Every trade. Every thesis. Every mistake. Future you will thank present you. |

---

## POSITION SIZING

### The Formula

```
Position Size = (Account Value × Risk Percentage) ÷ (Entry Price - Stop Price)

Example:
- Account: $1,500
- Risk: 2% = $30
- Entry: $5.00
- Stop: $4.50
- Position Size = $30 ÷ $0.50 = 60 shares
```

### Risk/Reward Check (PTJ's 5:1 Rule)

Before ANY trade:
- Calculate potential loss (Entry to Stop)
- Calculate potential gain (Entry to Target)
- Ratio must be at least 3:1, ideally 5:1

If the math doesn't work, **don't take the trade.**

---

## THE THESIS FRAMEWORK

### Before Buying

Write down:
1. **What is the thesis?** (Why will this go up?)
2. **What would BREAK the thesis?** (Specific conditions)
3. **What is the catalyst?** (Why now?)
4. **What is the timeframe?** (Days? Weeks?)

### During the Trade

- Thesis intact + price up = Hold/add
- Thesis intact + price down = Hold/consider adding ONCE
- Thesis broken + any price = EXIT IMMEDIATELY

### The "Fresh Eyes" Test

> "If I didn't own this stock already, would I buy it TODAY at THIS price?" - Kovner

- If YES → Hold (or add)
- If NO → Why are you holding?

---

## AVERAGING DOWN RULES

### When It's SMART

- Thesis 100% intact
- It's a bad DAY, not a bad STOCK
- Adding ONE time only
- Still have cash for other plays
- Sector still strong

### When It's STUPID

- Thesis breaking or broken
- Trend has reversed
- Adding every day as it falls
- All money in one position
- Whole sector dumping

### The Rule

**Average down ONCE, with a PLAN.**

1. Buy 50% of intended position at entry
2. IF drops 10-15% AND thesis intact → Add remaining 50%
3. IF drops further → NO MORE. You were wrong. Cut it.

---

## DAILY P/L (Don't Be Fooled)

### How It Works

| Number | Meaning |
|--------|---------|
| **Total Return** | Price now vs. your cost basis |
| **Today's Return** | Price now vs. yesterday's close |

The daily number RESETS every night. This is called "marking to market."

### The Trap

Apps show daily red/green to make you FEEL something:
- Red day → panic → maybe sell
- Green day → euphoria → maybe buy more

**Both reactions are EMOTIONAL, not logical.**

### What To Watch Instead

1. Is the TREND intact?
2. Is the THESIS intact?
3. Is it above key levels?

If yes to all three → daily red/green is noise.

---

## THE 200-DAY MOVING AVERAGE

### What PTJ Said

> "My metric for everything I look at is the 200-day moving average of closing prices. I've seen too many things go to zero."

### Validation

| Study | Finding |
|-------|---------|
| Meb Faber (2006/2012) | Avoided 2008 crash |
| Jeremy Siegel (Wharton) | 120 years confirms |
| Backtest 1960-2024 | 28% max drawdown vs 55%+ buy-hold |

### How We Use It

- Stock above 200-day MA = Trend intact, stay in
- Stock below 200-day MA = Warning sign, consider exit

**It's a DEFENSE tool, not an entry signal.**

---

## EMOTIONAL RULES

### From Kovner

> "When something happens to disturb my emotional equilibrium and my sense of what the world is like, I close out all positions related to that event."

### Practical Application

- Confused about what market is doing? → Get flat
- Made a big win and feeling invincible? → Size down
- Made a big loss and feeling desperate? → Stop trading for the day
- Saying "I wish" or "I hope"? → You're already wrong

### After a Devastating Loss

> "I always play very small and try to get black ink. I shrink my size to a fifth or a tenth of normal." - Kovner

Get rhythm and confidence back before sizing up again.

---

## THE CORRELATION TRAP

### What It Looks Like

"I'm diversified - I have 5 positions!"

| Position | Sector |
|----------|--------|
| AAPL | Tech |
| MSFT | Tech |
| GOOGL | Tech |
| NVDA | Tech |
| AMD | Tech |

**You have ONE position that's 5x as large.**

### Kovner's Warning

> "If you have eight highly correlated positions, then you are really trading one position that is eight times as large."

### Real Diversification

Spread across DIFFERENT sectors that don't move together:
- Tech + Healthcare + Energy + Financials

Not: Tech + Tech + Tech + Tech + Tech

---

## PATTERN SKEPTICISM

### The Heisenberg Problem

> "The more a price pattern is observed by speculators, the more prone you are to have false signals." - Kovner

### What This Means

- Popular patterns get crowded
- Everyone sees the same breakout
- Market makers know where the stops are
- The pattern fails precisely because it's well-known

### Our Approach

> "Tight congestions in which a breakout occurs for reasons that nobody understands are usually good risk/reward trades." - Kovner

Look for setups that AREN'T obvious. The edge is in what others miss, not what everyone sees.

---

## THE OVERNIGHT RULE (For Us)

We're PDT restricted. Can't day trade.

### This Is Actually An Advantage

- Forces us to have CONVICTION in thesis
- Can't panic sell on intraday noise
- Must think in terms of multi-day moves
- Overnight gaps can work in our favor

### The Strategy

- Buy with multi-day thesis
- Hold overnight
- Don't watch every tick
- Exit when thesis changes, not when scared

---

## SOURCES

These rules compiled from:
- Jesse Livermore (*Reminiscences of a Stock Operator*)
- Bruce Kovner (*Market Wizards*)
- Paul Tudor Jones (*Market Wizards*)
- Marty Schwartz (*Market Wizards*)
- Our own backtesting and experience

**We don't take any of it as gospel. We interrogate everything.**

🐺
