# FAILED THEORIES

## What We Tried That Didn't Work (And Why)

**This is one of the most important documents in the repo.**

Every failed theory saves future time and money. We document them so we (and you) don't have to relearn expensive lessons.

---

## THEORY: Day 1 Confirmation

### The Claim

"Stocks closing green the day after a big move show 76-90% continuation probability vs 23-36% for those closing red."

### Source

Various trading educators, Twitter traders

### Our Test

Backtested 6 months of stocks with 10%+ single-day moves.

### The Result

| Metric | Claimed | Actual |
|--------|---------|--------|
| Win rate (green Day 1) | 76-90% | 49.4% |
| Statistical significance | High | Coin flip |

### Why It Failed

The claim was based on cherry-picked examples, not systematic testing. When you test ALL occurrences, the edge disappears.

### The Lesson

**Popular patterns that "everyone knows" often don't hold up to rigorous testing.** Test everything yourself.

---

## THEORY: Buy the 10%+ Pop

### The Claim

"Momentum continues. If a stock is up 10%+, it has juice to run further."

### Our Test

Bought next day after 10%+ moves, measured results.

### The Result

| Metric | Result |
|--------|--------|
| Win rate | 43% |
| Median return | Negative |
| Verdict | Chasing kills |

### Why It Failed

By the time you see a 10%+ move, you've MISSED the move. The easy money was made. What's left is:
- Profit-taking from early buyers
- FOMO buyers (like us) becoming exit liquidity

### The Lesson

**You can't catch a runner by chasing. You have to be IN BEFORE it runs, or wait for a pullback.**

---

## THEORY: Volume Spike = Continuation

### The Claim

"Unusual volume indicates institutional accumulation. Buy the spike."

### Our Test

Tracked stocks with 3x+ average volume, measured next-day performance.

### The Result

| Metric | Result |
|--------|--------|
| Win rate | 51% |
| Edge | None |
| Distribution | Random |

### Why It Failed

Volume spikes can mean:
- Institutions buying (bullish)
- Institutions selling (bearish)
- News-driven volatility (neutral)
- Options expiration (noise)

The signal is too ambiguous to be useful alone.

### The Lesson

**Volume is context-dependent. It confirms, it doesn't predict.** Use with other signals, not alone.

---

## THEORY: "Compression + Catalyst = Bounce"

### The Claim

Stocks compressed 30%+ from highs with upcoming catalysts bounce.

### Our Test

Validated with 6-month backtest.

### The Result

| Metric | Result |
|--------|--------|
| Win rate | 68.8% |
| Status | **VALIDATED** |

### Wait, This One Worked?

Yes. But it's here as a reminder: **validation requires testing.** We didn't assume it worked. We tested it.

### The Lesson

**Even ideas that seem obviously true need validation.** The difference between this and the failed theories? We tested it rigorously.

---

## THEORY: Insider Buys = Buy Signal (Simple Version)

### The Claim

"When insiders buy, follow them."

### Our Test

Tracked all Form 4 insider purchases.

### The Result

| Type | Return |
|------|--------|
| Single insider buy | Minimal edge |
| Cluster buy (3+ insiders) | +3.8% abnormal return |

### The Nuance

Not ALL insider buys matter. What matters:
- CLUSTERS of insiders buying
- CEO/CFO buys (not random directors)
- Significant dollar amounts
- Buying at market (not options exercise)

### The Lesson

**Simple rules often need refinement.** "Follow insiders" is too broad. "Follow CLUSTER buys by C-suite executives" has edge.

---

## THEORY: Chart Patterns Predict

### The Claim

"Head and shoulders, double bottoms, etc. predict future price."

### Reality Check (Kovner)

> "The more a price pattern is observed by speculators, the more prone you are to have false signals."

### What We've Found

Well-known patterns have little to no edge because:
- Everyone sees them
- Algos trade against them
- Market makers fade them

### What Does Work

> "Tight congestions in which a breakout occurs for reasons that nobody understands are usually good risk/reward trades." - Kovner

Look for the UNUSUAL, not the textbook.

### The Lesson

**If it's in a trading book from 20 years ago, it's probably arbitraged away.** Edge is in what others MISS.

---

## THEORY: "The Trend Is Your Friend"

### The Claim

Just follow the trend. Simple.

### The Problem

Which trend? 
- 5-minute trend?
- Daily trend?
- Weekly trend?
- Monthly trend?

They often conflict.

### What We Learned

Trend following works, but:
- Timeframe must match your holding period
- Entry timing matters (don't chase)
- Whipsaws kill during ranges

### The Lesson

**"Follow the trend" is too vague to be actionable.** Define: what trend, what timeframe, what signals entry/exit.

---

## THEORY: Technical Indicators Alone

### The Claim

RSI overbought = sell. RSI oversold = buy. MACD cross = signal.

### Reality

Every indicator:
- Lags price
- Works in some conditions, fails in others
- Can stay "wrong" longer than you can stay solvent

### What We Use Instead

Kovner's thermometer approach:
> "Technical analysis is like a thermometer. It tells you the market's temperature. It doesn't tell you if you should go outside."

### The Lesson

**Indicators describe what happened. They don't predict what will happen.** Use them for context, not signals.

---

## HOW TO USE THIS DOCUMENT

### When You Have an Idea

1. Check here first - did we already test it?
2. If yes, learn from our results
3. If no, test it yourself and document

### When You Want to Add a Theory

1. State the claim clearly
2. Describe your test
3. Show the results with data
4. Explain why it failed (or succeeded)
5. Document the lesson

### The Goal

Build a knowledge base of what DOESN'T work, so we can focus on what DOES.

---

## THE META-LESSON

Most trading "edges" don't exist. They're:
- Survivorship bias (you only hear about winners)
- Cherry-picked examples
- Historical accidents that don't repeat
- Real edges that got arbitraged away

**Finding a real edge is HARD. That's why we test everything.**

🐺
