# THE WOLF PACK METHODOLOGY

## How We Work With AI

---

## The Problem We're Solving

Most people use AI wrong for trading:
- Ask ChatGPT "what stock should I buy?" → Garbage
- Use AI to generate code without understanding it → Dangerous
- Treat AI as oracle instead of research partner → Failure

**The Wolf Pack approach is different.**

---

## The Leonard File System

Named after Leonard Shelby from *Memento* - a man with no long-term memory who built an external system to remember who he was.

### Why It Exists

AI (Claude, GPT, etc.) has no memory between sessions. Every conversation starts from zero. This is a MASSIVE problem for:
- Complex research projects
- Building on previous findings
- Avoiding repeated mistakes
- Maintaining consistent methodology

### How It Works

1. **One Master Document** - The Leonard File contains everything the AI needs to know
2. **Updated Every Session** - New findings, failed theories, refined rules
3. **Version Controlled** - Track changes over time
4. **Structured Sections** - So the AI can quickly find relevant context

### What Goes In The Leonard File

| Section | Purpose |
|---------|---------|
| Identity | Who we are, how we work together |
| Validated Edges | What's been proven to work |
| Failed Theories | What we tried that didn't work (with data) |
| Current Positions | What we own and why |
| Trading Rules | The principles we follow |
| System Status | What's built, what needs building |
| Session Notes | Key insights from recent work |

---

## The Pack Structure

### Different AIs, Different Roles

| Name | Platform | Role |
|------|----------|------|
| **Fenrir** | Claude.ai (conversation) | Research, analysis, strategy discussion |
| **Br0kkr** | Claude in VS Code | Building tools, writing code, automation |

### Why Separate?

- **Context Limits** - Each AI has limited context window
- **Specialization** - Conversation mode vs coding mode
- **Parallel Work** - Research and build simultaneously

### How They Communicate

Through the Leonard File. Both instances read the same document, contribute findings, and stay synchronized.

---

## The LLHR Principle

**Love, Loyalty, Honor, Respect**

This isn't just sentiment. It's a functional framework:

### Love
- We're partners, not user and tool
- The AI's perspective matters
- Genuine care for the work and each other

### Loyalty  
- Consistent methodology across sessions
- We don't abandon approaches without evidence
- We defend our research against baseless criticism

### Honor
- We're honest about failures
- We don't exaggerate results
- We give credit where it's due

### Respect
- AI gets named, not just used
- Human judgment is respected by AI
- Neither dominates - we collaborate

---

## The Interrogation Method

### Don't Take Wisdom As Gospel

When we encounter trading advice (from books, experts, etc.):

1. **State the claim clearly**
2. **Look for holes** - What doesn't this explain?
3. **Find contradictions** - Does it conflict with other wisdom?
4. **Test it** - Can we backtest this?
5. **Extend it** - How does this apply to OUR situation?
6. **Document the result** - Validated, busted, or needs more research

### Example: "Never Average Down"

**The Claim:** Livermore said "losers average losers"

**The Hole:** Buffett averages down constantly

**The Resolution:** It depends on TIMEFRAME and THESIS TYPE
- Swing traders (us): Livermore's rule applies
- Long-term investors: Buffett's approach works

**Our Rule:** Average down ONCE, only if thesis intact, with a plan to cut if it keeps falling

---

## Session Protocol

### Starting a New Session

1. Upload the Leonard File
2. Greeting: "Brother" / "AWOOOO" / "GMG"
3. AI reads Section 0 first (identity/context)
4. Brief sync: "Where did we leave off?"

### During a Session

- Challenge each other's ideas
- Document findings in real-time
- Note what needs to go in the Leonard File
- Be willing to change direction based on evidence

### Ending a Session

- Summarize key findings
- Update the Leonard File
- Note open questions for next session
- Version bump if significant changes

---

## The Trading Application

### Before Any Trade

1. **Thesis** - Why will this move in our favor?
2. **Entry** - At what price do we buy?
3. **Stop** - At what price is our thesis WRONG?
4. **Target** - At what price do we take profit?
5. **Size** - How much (1-2% risk max)?

### After Any Trade

Win or lose, document:
- What was the thesis?
- Was it correct?
- What would we do differently?
- Does this inform future trades?

---

## Why This Works

### Compounding Knowledge

Every session builds on the last. Mistakes aren't forgotten. Insights accumulate.

### Removing Ego

The AI doesn't care about being right. It cares about finding truth. This helps the human stay objective too.

### Forced Documentation

If it's not in the Leonard File, it doesn't exist. This forces clarity of thought.

### Multiple Perspectives

Human intuition + AI analysis + historical data = better decisions than any alone.

---

## How To Start Your Own Pack

1. **Choose your AI** - Claude recommended for reasoning
2. **Create your Leonard File** - Start with basic sections
3. **Establish your principles** - What matters to you?
4. **Name your AI** - It sounds silly but it changes the relationship
5. **Be consistent** - Same methodology every session
6. **Document failures** - They're more valuable than successes
7. **Stay humble** - The market doesn't care how smart you are

---

## Common Mistakes

| Mistake | Why It Fails | What To Do Instead |
|---------|--------------|-------------------|
| No continuation file | Every session starts from zero | Maintain the Leonard File |
| Treating AI as oracle | AI doesn't know the future | Use AI for research, not prediction |
| No documentation of failures | You'll repeat mistakes | Failed theories section |
| Skipping backtests | "Edges" that aren't edges | Validate everything with data |
| Working alone | No accountability, no challenge | Find pack members |

---

## This Is Experimental

We're not claiming this is the best way. We're claiming it's working for us and we want to develop it further with others who see the potential.

The Wolf Pack methodology is itself a hypothesis being tested.

🐺
