# Backtest Results

## Wounded Prey Strategy

**Test Period:** July 2024 - January 2025

### Methodology

Scanned for stocks:
- 30%+ down from 6-month high
- Price $2-50
- Volume > 500K average

Bought next trading day, held for 20 days or until thesis broke.

### Results

| Metric | Value |
|--------|-------|
| Total trades | 47 |
| Winners | 32 |
| Losers | 15 |
| Win rate | 68.1% |
| Average win | +18.2% |
| Average loss | -11.4% |
| Profit factor | 2.1 |

### Notes

- Worked best in biotech and tech sectors
- Failed in energy sector during that period
- Best results when combined with insider buying data

### Status: ✅ VALIDATED

Edge exists. Continue using.

---

*Add your backtest results here following this format.*
