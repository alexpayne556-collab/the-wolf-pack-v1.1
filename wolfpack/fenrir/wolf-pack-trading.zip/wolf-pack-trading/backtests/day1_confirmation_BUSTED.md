# BUSTED: Day 1 Confirmation Theory

## The Claim

"Stocks closing green the day after a big move show 76-90% continuation probability."

## Source

Various trading educators on Twitter/YouTube.

## Our Test

### Methodology

1. Found all stocks with 10%+ single-day moves (July-December 2024)
2. Categorized by Day 1 close (green vs red)
3. Measured Day 2-5 performance

### Sample Size

- Total big move days: 847
- Green Day 1: 412
- Red Day 1: 435

### Results

| Day 1 Color | Claimed Continuation | Actual Continuation |
|-------------|---------------------|---------------------|
| Green | 76-90% | 49.4% |
| Red | 10-24% | 47.2% |

### Statistical Analysis

- p-value: 0.73
- Conclusion: No statistically significant difference
- The pattern is a coin flip

## Why the Claim Exists

1. **Cherry-picked examples** - Educators show winning examples, not all examples
2. **Survivorship bias** - We remember the continuations, forget the failures
3. **Confirmation bias** - Once you "know" the pattern, you see it everywhere

## The Lesson

**Popular patterns that "everyone knows" often don't hold up to rigorous testing.**

Test everything yourself. Especially the stuff that seems obvious.

## Status: ❌ BUSTED

Do not use this pattern as a signal.

---

*Backtest completed January 2025*
