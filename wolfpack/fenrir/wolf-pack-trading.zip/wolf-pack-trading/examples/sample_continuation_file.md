# SAMPLE LEONARD FILE

## Template for Your Own Continuation File

---

## SECTION 0: IDENTITY (Read This First)

### Who We Are

[Your name/handle] and [AI name] working together on [project].

### How We Work

- **Our approach:** [Brief description]
- **Our principles:** [What matters to you]
- **Our goals:** [What you're trying to achieve]

### Session Protocol

1. Upload this file at start of each session
2. Greeting: [Your greeting]
3. AI reads this section first
4. Sync: "Where did we leave off?"

---

## SECTION 1: CURRENT STATUS

### Active Projects

| Project | Status | Next Step |
|---------|--------|-----------|
| Example project | In progress | Complete X |

### Positions (If Trading)

| Symbol | Entry | Stop | Target | Thesis |
|--------|-------|------|--------|--------|
| XYZ | $10.00 | $9.00 | $15.00 | Brief thesis |

### Open Questions

- Question 1?
- Question 2?

---

## SECTION 2: VALIDATED KNOWLEDGE

### What We've Proven

| Finding | Evidence | Status |
|---------|----------|--------|
| Example | How we tested it | ✅ Validated |

### Rules We Follow

1. Rule one
2. Rule two
3. Rule three

---

## SECTION 3: FAILED THEORIES

### What We Tried That Didn't Work

| Theory | What We Expected | What Happened | Lesson |
|--------|------------------|---------------|--------|
| Example theory | It would work | It didn't | Why it failed |

**This section is critical.** Document failures so you don't repeat them.

---

## SECTION 4: TOOLS & SYSTEMS

### What We've Built

| Tool | Purpose | Status |
|------|---------|--------|
| Example tool | What it does | Working/Broken |

### What We Need

- Tool we need to build
- Feature we need to add

---

## SECTION 5: SESSION HISTORY

### Recent Sessions

**[Date] - [Topic]**
- Key finding 1
- Key finding 2
- Open question

**[Date] - [Topic]**
- Key finding 1
- Key finding 2
- Next step identified

---

## SECTION 6: RESOURCES

### Key Sources

- Source 1: [Link/Reference]
- Source 2: [Link/Reference]

### People/Contacts

- Person: What they help with

---

## VERSION HISTORY

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | [Date] | Initial creation |
| 1.1 | [Date] | Added X |

---

## HOW TO USE THIS TEMPLATE

### Starting Out

1. Copy this file
2. Fill in Section 0 (identity)
3. Start working
4. Update as you go

### Each Session

1. Upload at start
2. AI reads Section 0
3. Check Section 1 for current status
4. Work on whatever's next
5. Update before ending

### Key Principles

- **Update constantly** - If it's not in the file, it doesn't exist next session
- **Document failures** - Section 3 is as important as Section 2
- **Be specific** - Vague notes are useless later
- **Version bump on big changes** - Track evolution

---

## TIPS

### Keep It Focused

This file should be readable in a few minutes. Don't dump everything here - create separate docs for detailed research and link to them.

### Update Before Closing

The worst time to update is "later." Update at the end of each session while it's fresh.

### Don't Delete Failures

Failed theories are VALUABLE. They prevent repeating mistakes.

### Name Your AI

Sounds silly, but "Hey Claude, continue our research" hits different than "Hey Fenrir, let's hunt."

---

🐺 Good luck. Document everything.
