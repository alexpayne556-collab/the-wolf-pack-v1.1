# Market Wizards - Interrogated

## We Don't Take Wisdom as Gospel

The Market Wizards are legends. But legends can be wrong. Here we document what they said, find the holes, resolve contradictions, and adapt for our use.

---

## BRUCE KOVNER

### Background
- Started with $3,000 on a credit card (1977)
- Built Caxton Associates to $14B+ AUM
- 87% average annual return over 10 years
- Only ONE losing year (1994) in 28 years

### His Core Principles

1. **Undertrade, undertrade, undertrade**
2. **Risk 1-2% max per trade**
3. **Watch position correlation**
4. **Predetermined stops on every trade**
5. **Close positions when emotionally disturbed**

### What We Use

| Kovner Said | Our Application |
|-------------|-----------------|
| Undertrade | Our 2% rule (maybe should be 1%) |
| Position correlation | Don't call 5 biotech stocks "diversified" |
| Predetermined stops | Know exit before entry |
| Close on emotional disturbance | If confused, get flat |

### What Doesn't Apply to Us

- Global macro strategy (currencies, commodities) - we trade stocks
- Billions in capital - position sizing changes at scale
- Political connections - we don't have Cheney's number

### Grade: ✅ Highly Applicable

Most of Kovner's wisdom scales down to retail.

---

## JESSE LIVERMORE

### Background
- Made $100M+ in early 1900s
- Called the 1929 crash
- Went bankrupt multiple times
- Died by suicide in 1940

### The Contradiction We Found

**He says:** "Sit tight on winners"
**He also says:** "Cut losses fast"

**Our Resolution:** It's about THESIS, not TIME.

| Situation | Action |
|-----------|--------|
| Price down, thesis intact | Sit tight |
| Price down, thesis broken | Cut immediately |
| Price up, thesis intact | Let it run |
| Price up, thesis broken | Take profit |

### The "Never Average Down" Debate

**Livermore:** "Losers average losers"
**Buffett:** Averages down constantly

**Our Resolution:** Depends on timeframe and strategy.
- Swing traders (us): Livermore's rule applies
- Long-term investors: Buffett's approach can work

### The Big Warning

Livermore wrote all the rules. Then he broke them all and died broke.

**The lesson:** Knowing isn't doing. You need SYSTEMS that force discipline.

### Grade: ⚠️ Use With Caution

Wisdom is real but he couldn't follow his own rules. We need structure he lacked.

---

## PAUL TUDOR JONES

### Background
- Called the 1987 crash
- Made 126% return in 1987 while market crashed
- Consistent returns over decades

### The 200-Day Moving Average

**PTJ says:** "My metric for everything I look at is the 200-day moving average."

**Our validation:**
- Meb Faber studies confirm
- 120 years of data support it
- Avoided 2008 crash

**Our use:** Defense tool. If stock falls below 200-day MA, thesis may be broken.

### The 5:1 Rule

**PTJ says:** Risk $1 to make $5. This lets you be wrong 80% of the time and still break even.

**The math:**
- 20% win rate at 5:1 = break even
- 40% win rate at 5:1 = +160% profit

**Our use:** If risk/reward isn't at least 3:1, don't take the trade.

### Grade: ✅ Highly Applicable

PTJ's rules translate well to any timeframe.

---

## MARTY SCHWARTZ

*To be interrogated*

Key claim: "Divorce your ego from trading"

---

## STANLEY DRUCKENMILLER

*To be interrogated*

Key claim: "Be a pig when you're right"

---

## RICHARD DENNIS

*To be interrogated*

Key claim: "Rules beat intuition" (Turtle Traders)

---

## WILLIAM O'NEIL

*To be interrogated*

Key claim: "Cut losses at 7-8%"

---

## META-LESSONS

### What They All Have in Common

1. **Risk management is #1** - Every single one
2. **Cut losses** - No exceptions
3. **Let winners run** - But define "winner"
4. **Emotional control** - Trading psychology matters
5. **Continuous learning** - Markets change

### What Varies

- Entry signals (everyone has different approaches)
- Position sizing (1% vs 2% vs more)
- Averaging down (some do, some don't)
- Technical vs fundamental emphasis

### The Key Insight

**There is no single "right" way.**

The common thread is RISK MANAGEMENT and DISCIPLINE, not specific entry rules.

---

*This document is continuously updated as we interrogate more Market Wizards.*

🐺
