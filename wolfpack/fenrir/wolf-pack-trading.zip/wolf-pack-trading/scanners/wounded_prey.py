"""
Wounded Prey Scanner
Finds stocks compressed 30%+ from 6-month highs with volume confirmation

Part of The Wolf Pack Trading System
https://github.com/alexpayne556-collab/wolf-pack-trading
"""

import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')


def scan_wounded_prey(symbols: list, compression_threshold: float = 0.30) -> pd.DataFrame:
    """
    Scan for 'wounded prey' - stocks compressed significantly from highs.
    
    Parameters:
    -----------
    symbols : list
        List of stock symbols to scan
    compression_threshold : float
        Minimum compression from high (default 0.30 = 30%)
    
    Returns:
    --------
    DataFrame with wounded prey candidates
    """
    
    results = []
    
    for symbol in symbols:
        try:
            # Get 6 months of data
            stock = yf.Ticker(symbol)
            hist = stock.history(period="6mo")
            
            if len(hist) < 20:
                continue
            
            # Calculate metrics
            current_price = hist['Close'].iloc[-1]
            six_month_high = hist['High'].max()
            compression = (six_month_high - current_price) / six_month_high
            
            # Volume analysis
            avg_volume_20d = hist['Volume'].tail(20).mean()
            current_volume = hist['Volume'].iloc[-1]
            volume_ratio = current_volume / avg_volume_20d if avg_volume_20d > 0 else 0
            
            # Check if meets criteria
            if compression >= compression_threshold:
                results.append({
                    'symbol': symbol,
                    'current_price': round(current_price, 2),
                    'six_month_high': round(six_month_high, 2),
                    'compression': round(compression * 100, 1),
                    'volume_ratio': round(volume_ratio, 2),
                    'avg_volume': int(avg_volume_20d)
                })
                
        except Exception as e:
            # Skip symbols that error
            continue
    
    # Create DataFrame and sort by compression
    df = pd.DataFrame(results)
    if len(df) > 0:
        df = df.sort_values('compression', ascending=False)
    
    return df


def get_watchlist_symbols() -> list:
    """
    Returns our standard watchlist.
    Customize this for your own universe.
    """
    
    # Example sectors we watch
    sectors = {
        'biotech': ['IBRX', 'NTLA', 'CRSP', 'EDIT', 'BEAM', 'VERV'],
        'uranium': ['UEC', 'UUUU', 'CCJ', 'DNN', 'NXE'],
        'semiconductor': ['MU', 'AMAT', 'LRCX', 'KLAC', 'ASML'],
        'defense': ['KTOS', 'PLTR', 'RKLB', 'LUNR'],
        'ai_infra': ['SMCI', 'VRT', 'ANET'],
        'quantum': ['IONQ', 'RGTI', 'QBTS'],
    }
    
    # Flatten to single list
    all_symbols = []
    for sector_symbols in sectors.values():
        all_symbols.extend(sector_symbols)
    
    return list(set(all_symbols))


def main():
    """
    Run the wounded prey scan.
    """
    
    print("🐺 WOLF PACK - Wounded Prey Scanner")
    print("=" * 50)
    print(f"Scan time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Get symbols
    symbols = get_watchlist_symbols()
    print(f"Scanning {len(symbols)} symbols...")
    print()
    
    # Run scan
    results = scan_wounded_prey(symbols, compression_threshold=0.30)
    
    if len(results) == 0:
        print("No wounded prey found at 30%+ compression.")
        return
    
    # Display results
    print(f"Found {len(results)} wounded prey candidates:")
    print()
    print(results.to_string(index=False))
    print()
    
    # Highlight best opportunities
    print("TOP OPPORTUNITIES (compression + volume):")
    print("-" * 50)
    
    for _, row in results.head(5).iterrows():
        volume_signal = "🔥" if row['volume_ratio'] > 1.5 else "  "
        print(f"{volume_signal} {row['symbol']:6} | "
              f"${row['current_price']:7.2f} | "
              f"Down {row['compression']:5.1f}% from ${row['six_month_high']:.2f} | "
              f"Vol: {row['volume_ratio']:.1f}x")
    
    print()
    print("⚠️  This is a SCANNER, not a BUY signal.")
    print("    Each candidate needs thesis validation before entry.")
    print()


if __name__ == "__main__":
    main()
