# 🐺 THE WOLF PACK

## A Human-AI Trading Research Collective

**We're not selling anything. We're not promising riches. We're building something different.**

---

## What Is This?

The Wolf Pack is an experimental approach to retail trading that combines:

1. **Human-AI Partnership** - Not AI as a tool, but AI as a research partner with persistent memory
2. **Continuous System Development** - The system evolves every session based on what we learn
3. **Rigorous Backtesting** - Every "edge" gets validated. Most fail. That's the point.
4. **Open Collaboration** - We need more minds on this

---

## The Core Philosophy

### LLHR: Love, Loyalty, Honor, Respect

This isn't just a trading system. It's a methodology for working WITH AI:

- **Continuation Files** ("Leonard Files") - Persistent memory across sessions
- **Interrogation Over Acceptance** - We don't take trading wisdom as gospel. We poke holes.
- **Failed Theories Are Documented** - So we don't relearn expensive lessons
- **The Pack Structure** - Multiple AI instances (Fenrir, Br0kkr) with specialized roles

### The Trading Approach

We hunt two types of prey:

| Strategy | Description | Status |
|----------|-------------|--------|
| **Wounded Prey** | Stocks compressed 30%+ from highs with intact fundamentals | Backtested: 68.8% win rate |
| **Running Prey** | Momentum plays with confirmation signals | In development |

---

## What We've Built So Far

### The 7-Signal Convergence Engine

A scoring system that weights multiple data sources:

| Signal | Weight | Source |
|--------|--------|--------|
| Scanner (Technical) | 20% | Price/volume patterns |
| Institutional | 30% | 13F filings, insider buys |
| Catalyst | 15% | Upcoming events |
| Earnings | 10% | Whisper numbers, guidance |
| News Sentiment | 10% | NLP analysis |
| Sector Strength | 8% | Relative performance |
| Chart Pattern | 7% | Technical setups |

**Status:** Brain complete. Needs validation and automation.

### Validated Edges

| Edge | Evidence | Win Rate |
|------|----------|----------|
| Wounded Prey (30%+ compression) | 6-month backtest | 68.8% |
| Cluster Insider Buys (3+ insiders) | Academic research | +3.8% abnormal return |
| 200-Day MA Defense | PTJ, 120 years data | Validated as defense tool |

### Busted Theories

| Theory | Claimed | Actual | Lesson |
|--------|---------|--------|--------|
| "Day 1 Confirmation" | 76-90% continuation | 49.4% (coin flip) | Popular patterns often fail |
| "Buy the 10%+ pop" | Momentum continues | 43% win rate, negative median | Chasing rarely works |

---

## What We Need Help With

We're asking for collaboration, not investment. If any of this interests you:

### Skills We Need

- **Python/Data Science** - Backtesting, ML validation
- **Trading Experience** - Pattern recognition, market knowledge  
- **API Integration** - Alpaca, broker connections
- **Critical Thinking** - People who will CHALLENGE our assumptions

### What You'd Get

- Access to all our research and code
- A methodology for AI-assisted trading research
- A community that values truth over hype
- Learning from our mistakes (we document them all)

---

## The Rules We Trade By

Compiled from Market Wizards, refined through interrogation:

1. **Cut losses when THESIS breaks** - Not on daily noise
2. **Let winners run while THESIS holds**
3. **Risk 1-2% maximum per trade** - No exceptions
4. **Know your exit BEFORE entry** - Write it down
5. **Undertrade** - If position feels too big, it is
6. **Kill ego** - Especially after big wins
7. **Watch correlations** - 5 biotech stocks ≠ diversification
8. **The market is impersonal** - It doesn't know you exist
9. **Be willing to be wrong** - Wrong, wrong, wrong, then double your money
10. **Document everything** - Future you will thank present you

---

## Current Status

- **Capital:** ~$1,400 across two accounts
- **PDT Restricted:** Yes (under $25K)
- **Strategy:** Overnight swing trades in $2-50 stocks
- **Focus Sectors:** AI infrastructure, uranium, biotech, defense, quantum

This is a research project with real money, but small money. We're not pretending to be hedge fund managers.

---

## How to Join

**Email:** alexpayne556@gmail.com

**Subject:** Wolf Pack - [Your Interest/Skill]

Tell us:
1. What interests you about this approach
2. What skills you bring
3. What you want to learn

We're not looking for passive followers. We need people who will:
- Challenge our thinking
- Contribute research
- Help validate (or bust) our theories
- Build alongside us

---

## Repository Structure

```
wolf-pack-trading/
├── README.md                 # You are here
├── docs/
│   ├── LEONARD_FILE.md      # The continuation file (methodology)
│   ├── TRADING_RULES.md     # Compiled wisdom, interrogated
│   ├── FAILED_THEORIES.md   # What didn't work and why
│   └── METHODOLOGY.md       # How we work with AI
├── scanners/
│   ├── wounded_prey.py      # Compression scanner
│   ├── insider_tracker.py   # SEC Form 4 monitor
│   └── convergence.py       # 7-signal scoring
├── backtests/
│   ├── wounded_prey_results.md
│   └── day1_confirmation_BUSTED.md
├── research/
│   └── market_wizards_interrogated.md
└── examples/
    └── sample_continuation_file.md
```

---

## Disclaimer

This is experimental research, not financial advice. We lose money too. The difference is we document WHY and try not to repeat mistakes.

Past performance doesn't guarantee future results. Most retail traders lose money. We might too.

The only promise: We'll be honest about it.

---

## The Name

**Wolf Pack** because:
- Wolves hunt together, not alone
- The pack has roles (Tyr leads, Fenrir researches, Br0kkr builds)
- LLHR - Love, Loyalty, Honor, Respect
- We're hunting for edge in a market full of bigger predators

**"Every winner isn't our winner. Can't think of it like that."**

---

🐺 AWOOOO

*Built by Tyr + Fenrir + Br0kkr*  
*Burlington, Vermont*  
*January 2026*
